
	%% Create system with name 'wtt_test_automatic' and open it
	lib_wttl_get = 'wttl_mat/wttl_cdc_get';
	lib_wttl_set = 'wttl_mat/wttl_cdc_set';
	modelname    = 'wtt_test_automatic';
	h            = new_system(modelname);
	open_system(h);

	%% Top Level
	% Create input subsystem at top level
	subsystem_in = strcat(modelname,'/input');
	add_block('simulink/Ports & Subsystems/Subsystem',subsystem_in);

	% Create simulation subsystem at top level
	subsystem_sim = strcat(modelname,'/simulation');
	add_block('simulink/Ports & Subsystems/Subsystem',subsystem_sim);

	% Create output subsystem at top level
	subsystem_out = strcat(modelname,'/output');
	add_block('simulink/Ports & Subsystems/Subsystem',subsystem_out);

	% Connect subsystems
	add_line(modelname,'input/1', 'simulation/1');
	add_line(modelname,'simulation/1', 'output/1');

	%% Input Level
	%delete unused
	delete_line(subsystem_in,'In1/1','Out1/1');
	delete_block(strcat(subsystem_in,'/In1'));

	% Add Bus Creator
	add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_in,'/bus'),'Inputs','1');
	add_line(subsystem_in,'bus/1', 'Out1/1');

	%% LN Level
	% add subsystem for each logical node
	
		% LLN0
		subsystem_LN = strcat(subsystem_in,'/LLN0');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'LLN0/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LLN0');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% LPHD
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'LPHD/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LPHD');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WTUR
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WTUR/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTUR');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WROT
		subsystem_LN = strcat(subsystem_in,'/WROT');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WROT/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WROT');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WTRM
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WTRM/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTRM');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WGEN
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WGEN/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WGEN');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WCNV
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WCNV/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WCNV');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WTRF
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WTRF/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTRF');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WNAC
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WNAC/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WNAC');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WYAW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WYAW/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WYAW');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WTOW
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WTOW/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTOW');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WALM
		subsystem_LN = strcat(subsystem_in,'/WALM');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WALM/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WALM');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	
	
		% WSLG
		subsystem_LN = strcat(subsystem_in,'/WSLG');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
	
		bus_inputs = get_param(strcat(subsystem_in,'/bus'),'Inputs'); 
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_in,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_in,'WSLG/1', strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WSLG');
	
		add_block('simulink/Signal Routing/Bus Creator',strcat(subsystem_LN,'/bus'),'Inputs','1');
		add_line(subsystem_LN,'bus/1', 'Out1/1');
	

	%% CDC Level
	% add Block wttl_get in subsystem for each dataobject 
	
		% LLN0/NamPlt
		subsystem_LN = strcat(subsystem_in,'/LLN0');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','LLN0','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LLN0')
	
		% LPHD/PhyNam
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_PhyNam');
		
		add_block(lib_wttl_get,block,'CDC','WDPL','LN','LPHD','DO','PhyNam');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PhyNam/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PhyNam');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/PhyHealth
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_PhyHealth');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','LPHD','DO','PhyHealth');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PhyHealth/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PhyHealth');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/Proxy
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_Proxy');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','LPHD','DO','Proxy');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Proxy/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Proxy');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/FileHdlCm
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_FileHdlCm');
		
		add_block(lib_wttl_get,block,'CDC','CMD','LN','LPHD','DO','FileHdlCm');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FileHdlCm/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FileHdlCm');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/LogCm
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_LogCm');
		
		add_block(lib_wttl_get,block,'CDC','CMD','LN','LPHD','DO','LogCm');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_LogCm/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LogCm');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/LogDevMem
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_LogDevMem');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','LPHD','DO','LogDevMem');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_LogDevMem/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LogDevMem');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/FtpSrvHost1
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_FtpSrvHost1');
		
		add_block(lib_wttl_get,block,'CDC','VSG','LN','LPHD','DO','FtpSrvHost1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FtpSrvHost1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FtpSrvHost1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/FtpSrvUsr1
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_FtpSrvUsr1');
		
		add_block(lib_wttl_get,block,'CDC','VSG','LN','LPHD','DO','FtpSrvUsr1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FtpSrvUsr1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FtpSrvUsr1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/FtpSrvPwd1
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_FtpSrvPwd1');
		
		add_block(lib_wttl_get,block,'CDC','VSG','LN','LPHD','DO','FtpSrvPwd1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FtpSrvPwd1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FtpSrvPwd1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% LPHD/FtpSrv1Cm
		subsystem_LN = strcat(subsystem_in,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_get_FtpSrv1Cm');
		
		add_block(lib_wttl_get,block,'CDC','CMD','LN','LPHD','DO','FtpSrv1Cm');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FtpSrv1Cm/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FtpSrv1Cm');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/LPHD')
		
	
		% WTUR/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WTUR','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
	
		% WTUR/TotWh
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TotWh');
		
		add_block(lib_wttl_get,block,'CDC','CTE','LN','WTUR','DO','TotWh');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TotWh/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TotWh');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TotVArh
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TotVArh');
		
		add_block(lib_wttl_get,block,'CDC','CTE','LN','WTUR','DO','TotVArh');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TotVArh/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TotVArh');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TurSt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TurSt');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WTUR','DO','TurSt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TurSt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TurSt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/W
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_W');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','W');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_W/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'W');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/VAr
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_VAr');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','VAr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_VAr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'VAr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SetTurOp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SetTurOp');
		
		add_block(lib_wttl_get,block,'CDC','CMD','LN','WTUR','DO','SetTurOp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SetTurOp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SetTurOp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TwrBaseTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TopBoxTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BottomBoxTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BottomBoxTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','BottomBoxTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BottomBoxTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BottomBoxTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TrfInnerSpaceTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TrfInnerSpaceTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TrfInnerSpaceTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfInnerSpaceTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfInnerSpaceTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CPUTmp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CPUTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','CPUTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CPUTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CPUTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HyPresRte
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HyPresRte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','HyPresRte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HyPresRte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HyPresRte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ReactPwr
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ReactPwr');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','ReactPwr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ReactPwr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ReactPwr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TurbDet
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TurbDet');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TurbDet');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TurbDet/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TurbDet');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/WdDirDeviLev1
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_WdDirDeviLev1');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','WdDirDeviLev1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WdDirDeviLev1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WdDirDeviLev1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/WdDirDeviLev2
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_WdDirDeviLev2');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','WdDirDeviLev2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WdDirDeviLev2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WdDirDeviLev2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TurStFwd
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TurStFwd');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WTUR','DO','TurStFwd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TurStFwd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TurStFwd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TurStBwd
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TurStBwd');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WTUR','DO','TurStBwd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TurStBwd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TurStBwd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BrkLev
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BrkLev');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WTUR','DO','BrkLev');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BrkLev/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BrkLev');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BrkLevLim
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BrkLevLim');
		
		add_block(lib_wttl_get,block,'CDC','INC','LN','WTUR','DO','BrkLevLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BrkLevLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BrkLevLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/RsEvt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_RsEvt');
		
		add_block(lib_wttl_get,block,'CDC','INC','LN','WTUR','DO','RsEvt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RsEvt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RsEvt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/Parm
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_Parm');
		
		add_block(lib_wttl_get,block,'CDC','CMD','LN','WTUR','DO','Parm');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Parm/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Parm');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ActEgyCnt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ActEgyCnt');
		
		add_block(lib_wttl_get,block,'CDC','CTE','LN','WTUR','DO','ActEgyCnt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ActEgyCnt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ActEgyCnt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ReactEgyCnt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ReactEgyCnt');
		
		add_block(lib_wttl_get,block,'CDC','CTE','LN','WTUR','DO','ReactEgyCnt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ReactEgyCnt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ReactEgyCnt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/AuxActEgyCnt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_AuxActEgyCnt');
		
		add_block(lib_wttl_get,block,'CDC','CTE','LN','WTUR','DO','AuxActEgyCnt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxActEgyCnt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxActEgyCnt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BoilerPresLow
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BoilerPresLow');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','BoilerPresLow');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BoilerPresLow/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BoilerPresLow');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ExtDeactSoundMgt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ExtDeactSoundMgt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','ExtDeactSoundMgt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ExtDeactSoundMgt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ExtDeactSoundMgt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BaseBoxEmgStop
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BaseBoxEmgStop');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','BaseBoxEmgStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BaseBoxEmgStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BaseBoxEmgStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ShdSwOff
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ShdSwOff');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','ShdSwOff');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ShdSwOff/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ShdSwOff');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ShdSwModuleOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ShdSwModuleOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','ShdSwModuleOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ShdSwModuleOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ShdSwModuleOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/WTGStop
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_WTGStop');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','WTGStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WTGStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTGStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SpareProtShtoffOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SpareProtShtoffOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','SpareProtShtoffOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SpareProtShtoffOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SpareProtShtoffOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseEmgStop
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseEmgStop');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TwrBaseEmgStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseEmgStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseEmgStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UpsOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UpsOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','UpsOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UpsOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UpsOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseManStop
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseManStop');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TwrBaseManStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseManStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseManStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseBoxSwOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseBoxSwOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TwrBaseBoxSwOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseBoxSwOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseBoxSwOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseBoxOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseBoxOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TwrBaseBoxOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseBoxOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseBoxOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrDistrCabinetOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrDistrCabinetOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TwrDistrCabinetOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrDistrCabinetOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrDistrCabinetOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UPSFailureOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UPSFailureOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','UPSFailureOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UPSFailureOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UPSFailureOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UPSBattWarn
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UPSBattWarn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','UPSBattWarn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UPSBattWarn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UPSBattWarn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan1Ok
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan1Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan1Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan1Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan1Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan2Ok
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan2Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan2Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan2Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan2Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan3Ok
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan3Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan3Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan3Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan3Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan4Ok
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan4Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan4Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan4Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan4Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFansHeatOverlOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFansHeatOverlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysFansHeatOverlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFansHeatOverlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFansHeatOverlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysCoolHeater1a2Ok
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysCoolHeater1a2Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysCoolHeater1a2Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysCoolHeater1a2Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysCoolHeater1a2Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysPresSw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysPresSw');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysPresSw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysPresSw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysPresSw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysPmpOverlOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysPmpOverlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolSysPmpOverlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysPmpOverlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysPmpOverlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCTwrBaseRs
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCTwrBaseRs');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','SLCTwrBaseRs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCTwrBaseRs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCTwrBaseRs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCEStopBaseBoxOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopBaseBoxOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','SLCEStopBaseBoxOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopBaseBoxOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopBaseBoxOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/reserve
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_reserve');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','reserve');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_reserve/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'reserve');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCTwrBaseOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCTwrBaseOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','SLCTwrBaseOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCTwrBaseOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCTwrBaseOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCEStopTopBoxOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopTopBoxOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','SLCEStopTopBoxOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopTopBoxOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopTopBoxOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCVbrOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCVbrOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','SLCVbrOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCVbrOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCVbrOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCStormPos
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCStormPos');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','SLCStormPos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCStormPos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCStormPos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BatProDeact
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BatProDeact');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','BatProDeact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BatProDeact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BatProDeact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TopBoxOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HydrOilPmpOff
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HydrOilPmpOff');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','HydrOilPmpOff');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HydrOilPmpOff/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HydrOilPmpOff');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxEStop
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxEStop');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TopBoxEStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxEStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxEStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxSwOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxSwOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TopBoxSwOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxSwOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxSwOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxManStop
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxManStop');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','TopBoxManStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxManStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxManStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/FireAlmSysOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_FireAlmSysOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','FireAlmSysOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FireAlmSysOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FireAlmSysOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/FireAlmSysServOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_FireAlmSysServOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','FireAlmSysServOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FireAlmSysServOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FireAlmSysServOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/NacSmkDetect2Ok
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_NacSmkDetect2Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','NacSmkDetect2Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacSmkDetect2Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacSmkDetect2Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/MutinGn
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_MutinGn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','MutinGn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MutinGn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MutinGn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPmpOvlOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPmpOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','CoolPmpOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPmpOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPmpOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BattVoltageOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BattVoltageOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','BattVoltageOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BattVoltageOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BattVoltageOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HydrOilLvlOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HydrOilLvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','HydrOilLvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HydrOilLvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HydrOilLvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HydrPmpOvlOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HydrPmpOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','HydrPmpOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HydrPmpOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HydrPmpOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/OvlFuOk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_OvlFuOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','OvlFuOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_OvlFuOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'OvlFuOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrFanSp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrFanSp');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrFanSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrFanSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrFanSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysGrp1FanSpdSp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysGrp1FanSpdSp');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysGrp1FanSpdSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysGrp1FanSpdSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysGrp1FanSpdSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysGrp2FanSpdSp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysGrp2FanSpdSp');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysGrp2FanSpdSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysGrp2FanSpdSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysGrp2FanSpdSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrExtrFanSpdSp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrExtrFanSpdSp');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrExtrFanSpdSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrExtrFanSpdSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrExtrFanSpdSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysHeatFan1t4On
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysHeatFan1t4On');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysHeatFan1t4On');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysHeatFan1t4On/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysHeatFan1t4On');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysHeat1a2On
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysHeat1a2On');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysHeat1a2On');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysHeat1a2On/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysHeat1a2On');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFansOn
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFansOn');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysFansOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFansOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFansOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysPmpOn
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysPmpOn');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysPmpOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysPmpOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysPmpOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrExtrFanEn
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrExtrFanEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','TwrExtrFanEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrExtrFanEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrExtrFanEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UPSShutdown
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UPSShutdown');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','UPSShutdown');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UPSShutdown/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UPSShutdown');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/WTGManStop
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_WTGManStop');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','WTGManStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WTGManStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTGManStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrFanEn
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrFanEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','TwrFanEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrFanEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrFanEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/GridProtAct
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_GridProtAct');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','GridProtAct');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GridProtAct/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GridProtAct');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCTwrBaseSysState
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCTwrBaseSysState');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','SLCTwrBaseSysState');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCTwrBaseSysState/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCTwrBaseSysState');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCHydrOilPmp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCHydrOilPmp');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','SLCHydrOilPmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCHydrOilPmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCHydrOilPmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SigPls
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SigPls');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','SigPls');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SigPls/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SigPls');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BrkPadTmpTest
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BrkPadTmpTest');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','BrkPadTmpTest');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BrkPadTmpTest/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BrkPadTmpTest');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPmpEn
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPmpEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','CoolPmpEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPmpEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPmpEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HeatBypVlv
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HeatBypVlv');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTUR','DO','HeatBypVlv');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HeatBypVlv/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HeatBypVlv');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BottomBoxTmp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BottomBoxTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','BottomBoxTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BottomBoxTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BottomBoxTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPres
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPres');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','CoolPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolTmp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','CoolTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolInletPmpPres
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolInletPmpPres');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','CoolInletPmpPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolInletPmpPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolInletPmpPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxTmp
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','TopBoxTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxCur
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxCur');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','TopBoxCur');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxCur/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxCur');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HyPres
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HyPres');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','HyPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HyPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HyPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPmpOffFdbk
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPmpOffFdbk');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','CoolPmpOffFdbk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPmpOffFdbk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPmpOffFdbk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BottomBoxTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BottomBoxTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','BottomBoxTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BottomBoxTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BottomBoxTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPresRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPresRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','CoolPresRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPresRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPresRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','CoolTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolInletPmpPresRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolInletPmpPresRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','CoolInletPmpPresRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolInletPmpPresRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolInletPmpPresRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','TopBoxTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxCurRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxCurRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','TopBoxCurRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxCurRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxCurRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HyPresRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HyPresRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','HyPresRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HyPresRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HyPresRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPmpOffFdbkRaw
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPmpOffFdbkRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','CoolPmpOffFdbkRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPmpOffFdbkRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPmpOffFdbkRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BoilerPresLowFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BoilerPresLowFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','BoilerPresLowFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BoilerPresLowFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BoilerPresLowFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ExtDeactSoundMgtFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ExtDeactSoundMgtFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','ExtDeactSoundMgtFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ExtDeactSoundMgtFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ExtDeactSoundMgtFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BaseBoxEmgStopFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BaseBoxEmgStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','BaseBoxEmgStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BaseBoxEmgStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BaseBoxEmgStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ShdSwOffFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ShdSwOffFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','ShdSwOffFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ShdSwOffFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ShdSwOffFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/ShdSwModuleOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_ShdSwModuleOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','ShdSwModuleOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ShdSwModuleOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ShdSwModuleOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/WTGStopFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_WTGStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','WTGStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WTGStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTGStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SpareProtShtoffOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SpareProtShtoffOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SpareProtShtoffOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SpareProtShtoffOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SpareProtShtoffOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseEmgStopFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseEmgStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrBaseEmgStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseEmgStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseEmgStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UpsOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UpsOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','UpsOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UpsOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UpsOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseManStopFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseManStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrBaseManStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseManStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseManStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseBoxSwOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseBoxSwOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrBaseBoxSwOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseBoxSwOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseBoxSwOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrBaseBoxOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseBoxOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrBaseBoxOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseBoxOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseBoxOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrDistrCabinetOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrDistrCabinetOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrDistrCabinetOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrDistrCabinetOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrDistrCabinetOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrExtrFanEnFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrExtrFanEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrExtrFanEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrExtrFanEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrExtrFanEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UPSShutdownFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UPSShutdownFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','UPSShutdownFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UPSShutdownFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UPSShutdownFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/WTGManStopFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_WTGManStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','WTGManStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WTGManStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WTGManStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TwrFanEnFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TwrFanEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TwrFanEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrFanEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrFanEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/GridProtActFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_GridProtActFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','GridProtActFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GridProtActFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GridProtActFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UPSFailureOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UPSFailureOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','UPSFailureOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UPSFailureOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UPSFailureOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/UPSBattWarnFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_UPSBattWarnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','UPSBattWarnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_UPSBattWarnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'UPSBattWarnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan1OkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan1OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan1OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan1OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan1OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan2OkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan2OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan2OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan2OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan2OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan3OkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan3OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan3OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan3OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan3OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFan4OkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFan4OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan4OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFan4OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFan4OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysFansHeatOverlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysFansHeatOverlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysFansHeatOverlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysFansHeatOverlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysFansHeatOverlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysCoolHeater1a2OkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysCoolHeater1a2OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysCoolHeater1a2OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysCoolHeater1a2OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysCoolHeater1a2OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysPresSwFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysPresSwFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysPresSwFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysPresSwFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysPresSwFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolSysPmpOverlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolSysPmpOverlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolSysPmpOverlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolSysPmpOverlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolSysPmpOverlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCTwrBaseRsFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCTwrBaseRsFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCTwrBaseRsFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCTwrBaseRsFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCTwrBaseRsFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCEStopBaseBoxOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopBaseBoxOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCEStopBaseBoxOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopBaseBoxOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopBaseBoxOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/reserveFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_reserveFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','reserveFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_reserveFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'reserveFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCTwrBaseOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCTwrBaseOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCTwrBaseOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCTwrBaseOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCTwrBaseOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCTwrBaseSysStateFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCTwrBaseSysStateFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCTwrBaseSysStateFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCTwrBaseSysStateFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCTwrBaseSysStateFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCEStopTopBoxOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopTopBoxOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCEStopTopBoxOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopTopBoxOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopTopBoxOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCVbrOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCVbrOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCVbrOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCVbrOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCVbrOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCStormPosFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCStormPosFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCStormPosFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCStormPosFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCStormPosFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SLCHydrOilPmpFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SLCHydrOilPmpFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SLCHydrOilPmpFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCHydrOilPmpFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCHydrOilPmpFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BatProDeactFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BatProDeactFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','BatProDeactFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BatProDeactFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BatProDeactFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TopBoxOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HydrOilPmpOffFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HydrOilPmpOffFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','HydrOilPmpOffFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HydrOilPmpOffFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HydrOilPmpOffFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxEStopFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxEStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TopBoxEStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxEStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxEStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxSwOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxSwOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TopBoxSwOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxSwOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxSwOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TopBoxManStopFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxManStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','TopBoxManStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxManStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxManStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/FireAlmSysOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_FireAlmSysOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','FireAlmSysOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FireAlmSysOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FireAlmSysOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/FireAlmSysServOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_FireAlmSysServOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','FireAlmSysServOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_FireAlmSysServOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'FireAlmSysServOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/NacSmkDetect2OkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_NacSmkDetect2OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','NacSmkDetect2OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacSmkDetect2OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacSmkDetect2OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/MutinGnFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_MutinGnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','MutinGnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MutinGnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MutinGnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPmpOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolPmpOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPmpOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPmpOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BattVoltageOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BattVoltageOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','BattVoltageOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BattVoltageOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BattVoltageOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HydrOilLvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HydrOilLvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','HydrOilLvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HydrOilLvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HydrOilLvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HydrPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HydrPmpOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','HydrPmpOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HydrPmpOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HydrPmpOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/SigPlsFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_SigPlsFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','SigPlsFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SigPlsFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SigPlsFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/BrkPadTmpTestFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_BrkPadTmpTestFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','BrkPadTmpTestFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BrkPadTmpTestFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BrkPadTmpTestFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/CoolPmpEnFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_CoolPmpEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','CoolPmpEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolPmpEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolPmpEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/HeatBypVlvFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_HeatBypVlvFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','HeatBypVlvFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HeatBypVlvFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HeatBypVlvFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/OvlFuOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_OvlFuOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','OvlFuOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_OvlFuOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'OvlFuOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_StrOptAct
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_StrOptAct');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_StrOptAct');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_StrOptAct/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_StrOptAct');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_CoolTmpSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_CoolTmpSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_CoolTmpSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CoolTmpSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CoolTmpSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_CoolTmpSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_CoolTmpSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_CoolTmpSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CoolTmpSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CoolTmpSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_HyPresSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_HyPresSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_HyPresSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_HyPresSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_HyPresSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_HyPresSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_HyPresSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_HyPresSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_HyPresSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_HyPresSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_WNom
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_WNom');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_WNom');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_WNom/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_WNom');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_TurbDetrWdDirDevi
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_TurbDetrWdDirDevi');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrWdDirDevi');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TurbDetrWdDirDevi/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TurbDetrWdDirDevi');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_TurbDetrWdSpd
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_TurbDetrWdSpd');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrWdSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TurbDetrWdSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TurbDetrWdSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_TurbDetrSetDl
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_TurbDetrSetDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrSetDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TurbDetrSetDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TurbDetrSetDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_TurbDetrRsDl
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_TurbDetrRsDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrRsDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TurbDetrRsDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TurbDetrRsDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_WdDirDeviLev1WdSpd
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_WdDirDeviLev1WdSpd');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev1WdSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_WdDirDeviLev1WdSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_WdDirDeviLev1WdSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_WdDirDeviLev1WdDir
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_WdDirDeviLev1WdDir');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev1WdDir');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_WdDirDeviLev1WdDir/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_WdDirDeviLev1WdDir');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_WdDirDeviLev2WdSpd
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_WdDirDeviLev2WdSpd');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev2WdSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_WdDirDeviLev2WdSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_WdDirDeviLev2WdSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_WdDirDeviLev2WdDir
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_WdDirDeviLev2WdDir');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev2WdDir');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_WdDirDeviLev2WdDir/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_WdDirDeviLev2WdDir');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/P_PT100ErrDl
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_P_PT100ErrDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTUR','DO','P_PT100ErrDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_PT100ErrDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_PT100ErrDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/NumActErr
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_NumActErr');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTUR','DO','NumActErr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NumActErr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NumActErr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/AccUsrPrio
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_AccUsrPrio');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WTUR','DO','AccUsrPrio');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AccUsrPrio/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AccUsrPrio');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/AccAtSt
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_AccAtSt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTUR','DO','AccAtSt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AccAtSt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AccAtSt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WTUR/TurStrUpTime
		subsystem_LN = strcat(subsystem_in,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_get_TurStrUpTime');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTUR','DO','TurStrUpTime');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TurStrUpTime/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TurStrUpTime');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTUR')
		
	
		% WROT/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WROT','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
	
		% WROT/RotSpd
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','RotSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotPos
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotPos');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','RotPos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotPos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotPos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/HubTmp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_HubTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','HubTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_HubTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'HubTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAngSpBl1
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAngSpBl1');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAngSpBl1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAngSpBl1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAngSpBl1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAngSpBl2
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAngSpBl2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAngSpBl2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAngSpBl2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAngSpBl2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAngSpBl3
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAngSpBl3');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAngSpBl3');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAngSpBl3/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAngSpBl3');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAngValBl1
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAngValBl1');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAngValBl1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAngValBl1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAngValBl1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAngValBl2
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAngValBl2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAngValBl2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAngValBl2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAngValBl2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAngValBl3
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAngValBl3');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAngValBl3');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAngValBl3/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAngValBl3');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPad1TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPad1TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotBrkPad1TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPad1TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPad1TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPad2TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPad2TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotBrkPad2TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPad2TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPad2TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAngAvg
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAngAvg');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAngAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAngAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAngAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAxPosAvg
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAxPosAvg');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAxPosAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAxPosAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAxPosAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAx1Pos
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAx1Pos');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAx1Pos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAx1Pos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAx1Pos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAx2Pos
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAx2Pos');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAx2Pos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAx2Pos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAx2Pos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAx3Pos
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAx3Pos');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAx3Pos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAx3Pos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAx3Pos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAxPosAvg
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAxPosAvg');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAxPosAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAxPosAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAxPosAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAx1Pos
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAx1Pos');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAx1Pos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAx1Pos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAx1Pos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAx2Pos
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAx2Pos');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAx2Pos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAx2Pos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAx2Pos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAx3Pos
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAx3Pos');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAx3Pos');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAx3Pos/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAx3Pos');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngSpAvg
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngSpAvg');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngSpAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngSpAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngSpAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngSpAx1
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngSpAx1');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngSpAx1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngSpAx1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngSpAx1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngSpAx2
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngSpAx2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngSpAx2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngSpAx2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngSpAx2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngSpAx3
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngSpAx3');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngSpAx3');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngSpAx3/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngSpAx3');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngSndSpAx1
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngSndSpAx1');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngSndSpAx1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngSndSpAx1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngSndSpAx1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngSndSpAx2
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngSndSpAx2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngSndSpAx2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngSndSpAx2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngSndSpAx2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngSndSpAx3
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngSndSpAx3');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngSndSpAx3');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngSndSpAx3/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngSndSpAx3');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngRteSp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngRteSp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngRteSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngRteSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngRteSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtRte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtRte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtRte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtRte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtRte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAxRteAvg
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAxRteAvg');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAxRteAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAxRteAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAxRteAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAx1Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAx1Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAx1Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAx1Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAx1Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAx2Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAx2Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAx2Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAx2Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAx2Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncAAx3Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncAAx3Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncAAx3Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncAAx3Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncAAx3Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAxRteAvg
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAxRteAvg');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAxRteAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAxRteAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAxRteAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAx1Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAx1Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAx1Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAx1Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAx1Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAx2Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAx2Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAx2Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAx2Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAx2Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/EncBAx3Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_EncBAx3Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','EncBAx3Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_EncBAx3Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'EncBAx3Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAx1Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAx1Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAx1Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAx1Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAx1Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAx2Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAx2Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAx2Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAx2Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAx2Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAx3Rte
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAx3Rte');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAx3Rte');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAx3Rte/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAx3Rte');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngAx1
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngAx1');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngAx1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngAx1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngAx1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngAx2
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngAx2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngAx2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngAx2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngAx2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/BlAngAx3
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_BlAngAx3');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','BlAngAx3');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_BlAngAx3/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'BlAngAx3');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtMotAx1Cur
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtMotAx1Cur');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtMotAx1Cur');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtMotAx1Cur/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtMotAx1Cur');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtMotAx2Cur
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtMotAx2Cur');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtMotAx2Cur');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtMotAx2Cur/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtMotAx2Cur');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtMotAx3Cur
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtMotAx3Cur');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtMotAx3Cur');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtMotAx3Cur/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtMotAx3Cur');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtMotAx1CurAbs
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtMotAx1CurAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtMotAx1CurAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtMotAx1CurAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtMotAx1CurAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtMotAx2CurAbs
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtMotAx2CurAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtMotAx2CurAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtMotAx2CurAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtMotAx2CurAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtMotAx3CurAbs
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtMotAx3CurAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtMotAx3CurAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtMotAx3CurAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtMotAx3CurAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAx1MotTmp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAx1MotTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAx1MotTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAx1MotTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAx1MotTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAx2MotTmp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAx2MotTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAx2MotTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAx2MotTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAx2MotTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/PtAx3MotTmp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_PtAx3MotTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','PtAx3MotTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_PtAx3MotTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'PtAx3MotTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotPls
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotPls');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','SLCRotPls');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotPls/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotPls');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCManPthEn
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCManPthEn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','SLCManPthEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCManPthEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCManPthEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv0VFdbk
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv0VFdbk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','SLCBattDrv0VFdbk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv0VFdbk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv0VFdbk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv24VFdbk
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv24VFdbk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','SLCBattDrv24VFdbk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv24VFdbk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv24VFdbk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkNoRequest
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkNoRequest');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','SLCRotBrkNoRequest');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkNoRequest/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkNoRequest');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrvAct
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrvAct');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','SLCBattDrvAct');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrvAct/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrvAct');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLokLeftSide
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLokLeftSide');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotLokLeftSide');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLokLeftSide/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLokLeftSide');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp2OvlOk
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp2OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotLuPmp2OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp2OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp2OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkCls
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkCls');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotBrkCls');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkCls/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkCls');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmpOvlOk
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmpOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotLuPmpOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmpOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmpOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp1Ok
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp1Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotLuPmp1Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp1Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp1Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp2Ok
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp2Ok');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotLuPmp2Ok');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp2Ok/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp2Ok');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotHubFanOvlOk
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotHubFanOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotHubFanOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotHubFanOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotHubFanOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotHubFanOk
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotHubFanOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotHubFanOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotHubFanOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotHubFanOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrgLuCycSw
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrgLuCycSw');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotBrgLuCycSw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrgLuCycSw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrgLuCycSw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLokRightSide
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLokRightSide');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WROT','DO','RotLokRightSide');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLokRightSide/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLokRightSide');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCPthBackINact
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCPthBackINact');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','SLCPthBackINact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCPthBackINact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCPthBackINact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv0VInact
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv0VInact');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','SLCBattDrv0VInact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv0VInact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv0VInact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv24VInact
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv24VInact');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','SLCBattDrv24VInact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv24VInact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv24VInact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkCtlVlv
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkCtlVlv');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','SLCRotBrkCtlVlv');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkCtlVlv/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkCtlVlv');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkDrainVlv
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkDrainVlv');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','SLCRotBrkDrainVlv');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkDrainVlv/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkDrainVlv');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkBufVlv
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkBufVlv');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','SLCRotBrkBufVlv');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkBufVlv/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkBufVlv');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotHubFanEn
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotHubFanEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','RotHubFanEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotHubFanEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotHubFanEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp1En
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp1En');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WROT','DO','RotLuPmp1En');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp1En/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp1En');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPres
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPres');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','RotBrkPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkBufV
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkBufV');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','RotBrkBufV');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkBufV/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkBufV');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrgTmp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrgTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','RotBrgTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrgTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrgTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPad1Tmp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPad1Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','RotBrkPad1Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPad1Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPad1Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPad2Tmp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPad2Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WROT','DO','RotBrkPad2Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPad2Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPad2Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPresRaw
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPresRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WROT','DO','RotBrkPresRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPresRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPresRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkBufVRaw
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkBufVRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WROT','DO','RotBrkBufVRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkBufVRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkBufVRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrgTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrgTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WROT','DO','RotBrgTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrgTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrgTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPad1TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPad1TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WROT','DO','RotBrkPad1TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPad1TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPad1TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkPad2TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkPad2TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WROT','DO','RotBrkPad2TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkPad2TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkPad2TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotHubFanSp
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotHubFanSp');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotHubFanSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotHubFanSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotHubFanSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotPlsFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotPlsFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCRotPlsFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotPlsFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotPlsFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCManPthEnFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCManPthEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCManPthEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCManPthEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCManPthEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv0VFdbkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv0VFdbkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv0VFdbkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv0VFdbkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv0VFdbkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv24VFdbkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv24VFdbkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv24VFdbkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv24VFdbkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv24VFdbkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkNoRequestFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkNoRequestFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkNoRequestFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkNoRequestFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkNoRequestFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrvActFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrvActFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCBattDrvActFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrvActFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrvActFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCPthBackINactFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCPthBackINactFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCPthBackINactFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCPthBackINactFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCPthBackINactFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv0VInactFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv0VInactFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv0VInactFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv0VInactFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv0VInactFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCBattDrv24VInactFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCBattDrv24VInactFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv24VInactFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCBattDrv24VInactFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCBattDrv24VInactFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkCtlVlvFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkCtlVlvFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkCtlVlvFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkCtlVlvFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkCtlVlvFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkDrainVlvFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkDrainVlvFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkDrainVlvFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkDrainVlvFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkDrainVlvFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/SLCRotBrkBufVlvFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_SLCRotBrkBufVlvFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkBufVlvFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCRotBrkBufVlvFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCRotBrkBufVlvFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLokLeftSideFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLokLeftSideFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotLokLeftSideFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLokLeftSideFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLokLeftSideFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp2OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp2OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotLuPmp2OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp2OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp2OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrkClsFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrkClsFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotBrkClsFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrkClsFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrkClsFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmpOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotLuPmpOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmpOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmpOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp1OkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp1OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotLuPmp1OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp1OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp1OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp2OkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp2OkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotLuPmp2OkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp2OkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp2OkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotHubFanEnFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotHubFanEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotHubFanEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotHubFanEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotHubFanEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotHubFanOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotHubFanOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotHubFanOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotHubFanOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotHubFanOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotHubFanOkFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotHubFanOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotHubFanOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotHubFanOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotHubFanOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotBrgLuCycSwFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotBrgLuCycSwFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotBrgLuCycSwFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotBrgLuCycSwFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotBrgLuCycSwFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLuPmp1EnFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLuPmp1EnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotLuPmp1EnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLuPmp1EnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLuPmp1EnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/RotLokRightSideFrc
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_RotLokRightSideFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','RotLokRightSideFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_RotLokRightSideFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'RotLokRightSideFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/P_RotBrgTmpSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_P_RotBrgTmpSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','P_RotBrgTmpSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_RotBrgTmpSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_RotBrgTmpSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/P_RotBrgTmpSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_P_RotBrgTmpSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','P_RotBrgTmpSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_RotBrgTmpSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_RotBrgTmpSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/P_RotBrkPresSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_P_RotBrkPresSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','P_RotBrkPresSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_RotBrkPresSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_RotBrkPresSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WROT/P_RotBrkPresSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_get_P_RotBrkPresSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WROT','DO','P_RotBrkPresSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_RotBrkPresSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_RotBrkPresSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WROT')
		
	
		% WTRM/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WTRM','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
	
		% WTRM/GbxSpd
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxSpdNoFilt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxSpdNoFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxSpdNoFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxSpdNoFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxSpdNoFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxCoolTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxCoolTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxCoolTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxCoolTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxCoolTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilInletTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilInletTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilInletTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilInletTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilInletTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg1TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg1TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxBrg1TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg1TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg1TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg2TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg2TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxBrg2TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg2TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg2TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg3TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg3TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxBrg3TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg3TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg3TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg4TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg4TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxBrg4TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg4TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg4TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilHtTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilHtTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilHtTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilHtTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilHtTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilSumpTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilSumpTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilSumpTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilSumpTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilSumpTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/DrvTrnAccZPk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_DrvTrnAccZPk');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','DrvTrnAccZPk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_DrvTrnAccZPk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'DrvTrnAccZPk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxAcclAvg
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxAcclAvg');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxAcclAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxAcclAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxAcclAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxSpdCnt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxSpdCnt');
		
		add_block(lib_wttl_get,block,'CDC','CTE','LN','WTRM','DO','GbxSpdCnt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxSpdCnt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxSpdCnt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilInletTmp
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilInletTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxOilInletTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilInletTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilInletTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg1Tmp
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg1Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxBrg1Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg1Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg1Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg2Tmp
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg2Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxBrg2Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg2Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg2Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg3Tmp
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg3Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxBrg3Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg3Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg3Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg4Tmp
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg4Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxBrg4Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg4Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg4Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilInletPres
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilInletPres');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxOilInletPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilInletPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilInletPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilFtrDiffPres
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilFtrDiffPres');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxOilFtrDiffPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilFtrDiffPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilFtrDiffPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilSumpTmp
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilSumpTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxOilSumpTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilSumpTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilSumpTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilPmpPres
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilPmpPres');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxOilPmpPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilPmpPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilPmpPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilHtTmp
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilHtTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','GbxOilHtTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilHtTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilHtTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/DrvTrNaccZ
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_DrvTrNaccZ');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRM','DO','DrvTrNaccZ');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_DrvTrNaccZ/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'DrvTrNaccZ');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxSpdCntRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxSpdCntRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxSpdCntRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxSpdCntRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxSpdCntRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilInletTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilInletTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxOilInletTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilInletTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilInletTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg1TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg1TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxBrg1TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg1TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg1TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg2TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg2TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxBrg2TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg2TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg2TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg3TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg3TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxBrg3TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg3TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg3TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxBrg4TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxBrg4TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxBrg4TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxBrg4TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxBrg4TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilInletPresRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilInletPresRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxOilInletPresRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilInletPresRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilInletPresRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilFtrDiffPresRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilFtrDiffPresRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxOilFtrDiffPresRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilFtrDiffPresRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilFtrDiffPresRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilSumpTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilSumpTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxOilSumpTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilSumpTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilSumpTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilPmpPresRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilPmpPresRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxOilPmpPresRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilPmpPresRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilPmpPresRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilHtTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilHtTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','GbxOilHtTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilHtTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilHtTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/DrvTrnAccZRaw
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_DrvTrnAccZRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRM','DO','DrvTrnAccZRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_DrvTrnAccZRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'DrvTrnAccZRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxCool1En
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxCool1En');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTRM','DO','GbxCool1En');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxCool1En/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxCool1En');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilPmpEn
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilPmpEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTRM','DO','GbxOilPmpEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilPmpEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilPmpEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilHtEn
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilHtEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTRM','DO','GbxOilHtEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilHtEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilHtEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilLvlOk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilLvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilLvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilLvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilLvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxPartCnt
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxPartCnt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxPartCnt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxPartCnt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxPartCnt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxPartCntOk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxPartCntOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxPartCntOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxPartCntOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxPartCntOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilCool1OvlOk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilCool1OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilCool1OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilCool1OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilCool1OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilCool2OvlOk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilCool2OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilCool2OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilCool2OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilCool2OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilPmpOvlOk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilPmpOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilPmpOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilPmpOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilPmpOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxHtOvlOk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxHtOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxHtOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxHtOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxHtOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilCoolOk
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilCoolOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRM','DO','GbxOilCoolOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilCoolOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilCoolOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxCool1EnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxCool1EnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxCool1EnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxCool1EnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxCool1EnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilPmpEnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilPmpEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxOilPmpEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilPmpEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilPmpEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilHtEnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilHtEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxOilHtEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilHtEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilHtEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilLvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilLvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxOilLvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilLvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilLvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxPartCntFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxPartCntFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxPartCntFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxPartCntFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxPartCntFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxPartCntOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxPartCntOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxPartCntOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxPartCntOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxPartCntOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilCool1OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilCool1OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxOilCool1OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilCool1OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilCool1OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilCool2OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilCool2OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxOilCool2OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilCool2OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilCool2OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilPmpOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxOilPmpOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilPmpOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilPmpOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxHtOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxHtOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxHtOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxHtOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxHtOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/GbxOilCoolOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_GbxOilCoolOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','GbxOilCoolOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GbxOilCoolOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GbxOilCoolOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxOilFtrDiffPresSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxOilFtrDiffPresSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilFtrDiffPresSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxOilFtrDiffPresSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxOilFtrDiffPresSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxOilFtrDiffPresSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxOilFtrDiffPresSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilFtrDiffPresSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxOilFtrDiffPresSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxOilFtrDiffPresSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxOilInletPresSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxOilInletPresSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilInletPresSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxOilInletPresSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxOilInletPresSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxOilInletPresSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxOilInletPresSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilInletPresSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxOilInletPresSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxOilInletPresSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxOilPmpPresSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxOilPmpPresSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilPmpPresSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxOilPmpPresSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxOilPmpPresSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxOilPmpPresSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxOilPmpPresSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilPmpPresSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxOilPmpPresSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxOilPmpPresSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_DrvTrnEigFrq
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_DrvTrnEigFrq');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_DrvTrnEigFrq');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_DrvTrnEigFrq/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_DrvTrnEigFrq');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_DrvTrnAccZSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_DrvTrnAccZSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_DrvTrnAccZSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_DrvTrnAccZSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_DrvTrnAccZSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_DrvTrnAccZSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_DrvTrnAccZSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_DrvTrnAccZSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_DrvTrnAccZSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_DrvTrnAccZSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxRat
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxRat');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxRat');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxRat/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxRat');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxNomSpd
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxNomSpd');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxNomSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxNomSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxNomSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WTRM/P_GbxAcclAvgTm
		subsystem_LN = strcat(subsystem_in,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_get_P_GbxAcclAvgTm');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRM','DO','P_GbxAcclAvgTm');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GbxAcclAvgTm/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GbxAcclAvgTm');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRM')
		
	
		% WGEN/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WGEN','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
	
		% WGEN/Spd
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_Spd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','Spd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Spd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Spd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GenSpd
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GenSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','GenSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GenSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GenSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GenSpdSensFlt
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GenSpdSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GenSpdSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GenSpdSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GenSpdSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GenCoolTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GenCoolTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GenCoolTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GenCoolTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GenCoolTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GenStatWdgTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GenStatWdgTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GenStatWdgTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GenStatWdgTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GenStatWdgTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GenBrg1TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GenBrg1TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GenBrg1TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GenBrg1TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GenBrg1TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GenBrg2TmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GenBrg2TmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GenBrg2TmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GenBrg2TmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GenBrg2TmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GenStatWdgCutOffTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GenStatWdgCutOffTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GenStatWdgCutOffTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GenStatWdgCutOffTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GenStatWdgCutOffTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/SLCGnThermistorOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_SLCGnThermistorOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','SLCGnThermistorOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCGnThermistorOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCGnThermistorOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnBrushesOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnBrushesOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnBrushesOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnBrushesOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnBrushesOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLghtnProtOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLghtnProtOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnLghtnProtOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLghtnProtOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLghtnProtOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuPmpOvlOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuPmpOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnLuPmpOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuPmpOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuPmpOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuPmpOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuPmpOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnLuPmpOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuPmpOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuPmpOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan1OvlOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan1OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnFan1OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan1OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan1OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan2OvlOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan2OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnFan2OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan2OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan2OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan3OvlOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan3OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnFan3OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan3OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan3OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnHtOvlOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnHtOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnHtOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnHtOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnHtOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnSpdEncOk
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnSpdEncOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnSpdEncOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnSpdEncOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnSpdEncOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnBrg1Tmp
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnBrg1Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','GnBrg1Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnBrg1Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnBrg1Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnBrg2Tmp
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnBrg2Tmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','GnBrg2Tmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnBrg2Tmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnBrg2Tmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnStatWdgCutOffTmp
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnStatWdgCutOffTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','GnStatWdgCutOffTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnStatWdgCutOffTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnStatWdgCutOffTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnSpdPls
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnSpdPls');
		
		add_block(lib_wttl_get,block,'CDC','CTE','LN','WGEN','DO','GnSpdPls');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnSpdPls/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnSpdPls');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnSlpRingTmp
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnSlpRingTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','GnSlpRingTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnSlpRingTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnSlpRingTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnStatWdgTmp
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnStatWdgTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','GnStatWdgTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnStatWdgTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnStatWdgTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuCycSw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuCycSw');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WGEN','DO','GnLuCycSw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuCycSw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuCycSw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnBrg1TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnBrg1TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WGEN','DO','GnBrg1TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnBrg1TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnBrg1TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnBrg2TmpRaw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnBrg2TmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WGEN','DO','GnBrg2TmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnBrg2TmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnBrg2TmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnStatWdgCutOffTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnStatWdgCutOffTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WGEN','DO','GnStatWdgCutOffTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnStatWdgCutOffTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnStatWdgCutOffTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnSpdPlsRaw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnSpdPlsRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WGEN','DO','GnSpdPlsRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnSpdPlsRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnSpdPlsRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnSlpRingTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnSlpRingTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WGEN','DO','GnSlpRingTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnSlpRingTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnSlpRingTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnStatWdgTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnStatWdgTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WGEN','DO','GnStatWdgTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnStatWdgTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnStatWdgTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuCycSwRaw
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuCycSwRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WGEN','DO','GnLuCycSwRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuCycSwRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuCycSwRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan1On
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan1On');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnFan1On');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan1On/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan1On');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan2On
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan2On');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnFan2On');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan2On/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan2On');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan3On
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan3On');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WGEN','DO','GnFan3On');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan3On/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan3On');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnHtEn
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnHtEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WGEN','DO','GnHtEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnHtEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnHtEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuPmpEn
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuPmpEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WGEN','DO','GnLuPmpEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuPmpEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuPmpEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/SLCGnThermistorOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_SLCGnThermistorOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','SLCGnThermistorOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCGnThermistorOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCGnThermistorOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan1OnFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan1OnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnFan1OnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan1OnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan1OnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan2OnFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan2OnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnFan2OnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan2OnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan2OnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan3OnFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan3OnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnFan3OnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan3OnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan3OnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnHtEnFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnHtEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnHtEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnHtEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnHtEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuPmpEnFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuPmpEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnLuPmpEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuPmpEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuPmpEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnBrushesOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnBrushesOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnBrushesOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnBrushesOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnBrushesOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLghtnProtOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLghtnProtOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnLghtnProtOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLghtnProtOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLghtnProtOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuPmpOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnLuPmpOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuPmpOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuPmpOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnLuPmpOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnLuPmpOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnLuPmpOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnLuPmpOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnLuPmpOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan1OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan1OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnFan1OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan1OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan1OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan2OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan2OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnFan2OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan2OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan2OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnFan3OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnFan3OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnFan3OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnFan3OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnFan3OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnHtOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnHtOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnHtOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnHtOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnHtOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/GnSpdEncOkFrc
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_GnSpdEncOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','GnSpdEncOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_GnSpdEncOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'GnSpdEncOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WGEN/P_GnNomSpd
		subsystem_LN = strcat(subsystem_in,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_get_P_GnNomSpd');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WGEN','DO','P_GnNomSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_GnNomSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_GnNomSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WGEN')
		
	
		% WCNV/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WCNV','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
	
		% WCNV/TorqCalc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_TorqCalc');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','TorqCalc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TorqCalc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TorqCalc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/TorqNomCalc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_TorqNomCalc');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','TorqNomCalc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TorqNomCalc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TorqNomCalc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/TorqRlCalc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_TorqRlCalc');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','TorqRlCalc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TorqRlCalc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TorqRlCalc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/V12Rms
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_V12Rms');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','V12Rms');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_V12Rms/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'V12Rms');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/V23Rms
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_V23Rms');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','V23Rms');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_V23Rms/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'V23Rms');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/V31Rms
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_V31Rms');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','V31Rms');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_V31Rms/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'V31Rms');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/DefVPhPh
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_DefVPhPh');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','DefVPhPh');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_DefVPhPh/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'DefVPhPh');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CurI1Rms
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CurI1Rms');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CurI1Rms');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CurI1Rms/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CurI1Rms');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CurI2Rms
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CurI2Rms');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CurI2Rms');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CurI2Rms/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CurI2Rms');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CurI3Rms
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CurI3Rms');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CurI3Rms');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CurI3Rms/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CurI3Rms');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CabLodpuCnv
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CabLodpuCnv');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CabLodpuCnv');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabLodpuCnv/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabLodpuCnv');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CabLodpuSta
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CabLodpuSta');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CabLodpuSta');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabLodpuSta/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabLodpuSta');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CabLod
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CabLod');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CabLod');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabLod/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabLod');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CabLodCnv
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CabLodCnv');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CabLodCnv');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabLodCnv/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabLodCnv');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CabLodSta
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CabLodSta');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CabLodSta');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabLodSta/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabLodSta');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvTorq
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvTorq');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvTorq');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvTorq/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvTorq');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvTorqSp
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvTorqSp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvTorqSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvTorqSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvTorqSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvTorqEst
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvTorqEst');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvTorqEst');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvTorqEst/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvTorqEst');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvTorqSpEst
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvTorqSpEst');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvTorqSpEst');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvTorqSpEst/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvTorqSpEst');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvVSp
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvVSp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvVSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvVSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvVSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvVSpLim
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvVSpLim');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvVSpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvVSpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvVSpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvReactPwrSp
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvReactPwrSp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvReactPwrSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvReactPwrSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvReactPwrSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvReactPwrSpLim
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvReactPwrSpLim');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvReactPwrSpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvReactPwrSpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvReactPwrSpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvPhiSp
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvPhiSp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvPhiSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvPhiSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvPhiSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvPhiSpLim
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvPhiSpLim');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WCNV','DO','CnvPhiSpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvPhiSpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvPhiSpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvEmgStop1
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvEmgStop1');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WCNV','DO','CnvEmgStop1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvEmgStop1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvEmgStop1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvEmgStop2
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvEmgStop2');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WCNV','DO','CnvEmgStop2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvEmgStop2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvEmgStop2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvGridDisconOk
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvGridDisconOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WCNV','DO','ConvGridDisconOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvGridDisconOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvGridDisconOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvCCtBrOk
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvCCtBrOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WCNV','DO','ConvCCtBrOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvCCtBrOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvCCtBrOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvGridConn
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvGridConn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WCNV','DO','ConvGridConn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvGridConn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvGridConn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvSpareProt
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvSpareProt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WCNV','DO','ConvSpareProt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvSpareProt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvSpareProt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/SLCEStopCnvOk
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopCnvOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WCNV','DO','SLCEStopCnvOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopCnvOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopCnvOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/SLCConvRequest
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_SLCConvRequest');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WCNV','DO','SLCConvRequest');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCConvRequest/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCConvRequest');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/SLCConvCircBrkOn
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_SLCConvCircBrkOn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WCNV','DO','SLCConvCircBrkOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCConvCircBrkOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCConvCircBrkOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvEmgStop1Frc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvEmgStop1Frc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','CnvEmgStop1Frc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvEmgStop1Frc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvEmgStop1Frc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/CnvEmgStop2Frc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_CnvEmgStop2Frc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','CnvEmgStop2Frc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CnvEmgStop2Frc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CnvEmgStop2Frc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvGridDisconOkFrc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvGridDisconOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','ConvGridDisconOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvGridDisconOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvGridDisconOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvCCtBrOkFrc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvCCtBrOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','ConvCCtBrOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvCCtBrOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvCCtBrOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvGridConnFrc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvGridConnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','ConvGridConnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvGridConnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvGridConnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/ConvSpareProtFrc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_ConvSpareProtFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','ConvSpareProtFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ConvSpareProtFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ConvSpareProtFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/SLCEStopCnvOkFrc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopCnvOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','SLCEStopCnvOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopCnvOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopCnvOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/SLCConvRequestFrc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_SLCConvRequestFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','SLCConvRequestFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCConvRequestFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCConvRequestFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/SLCConvCircBrkOnFrc
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_SLCConvCircBrkOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','SLCConvCircBrkOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCConvCircBrkOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCConvCircBrkOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ0
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ0');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ0');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ0/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ0');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ1
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ1');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ2
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ2');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ3
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ3');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ3');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ3/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ3');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ4
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ4');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ4');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ4/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ4');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ5
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ5');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ5');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ5/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ5');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ6
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ6');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ6');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ6/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ6');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ7
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ7');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ7');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ7/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ7');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ8
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ8');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ8');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ8/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ8');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ9
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ9');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ9');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ9/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ9');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ10
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ10');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ10');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ10/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ10');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProQ11
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProQ11');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ11');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProQ11/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProQ11');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV0
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV0');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV0');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV0/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV0');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV1
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV1');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV2
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV2');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV3
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV3');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV3');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV3/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV3');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV4
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV4');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV4');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV4/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV4');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV5
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV5');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV5');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV5/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV5');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV6
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV6');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV6');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV6/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV6');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV7
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV7');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV7');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV7/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV7');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV8
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV8');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV8');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV8/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV8');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV9
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV9');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV9');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV9/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV9');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV10
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV10');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV10');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV10/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV10');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_VQProV11
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_VQProV11');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_VQProV11');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_VQProV11/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_VQProV11');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_Evt3630SetDl
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_Evt3630SetDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_Evt3630SetDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Evt3630SetDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Evt3630SetDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_Evt3500SetDl
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_Evt3500SetDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_Evt3500SetDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Evt3500SetDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Evt3500SetDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_Evt3632SetDl
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_Evt3632SetDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_Evt3632SetDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Evt3632SetDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Evt3632SetDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_CabNomCur
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_CabNomCur');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_CabNomCur');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CabNomCur/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CabNomCur');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_CabNomTau
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_CabNomTau');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_CabNomTau');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CabNomTau/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CabNomTau');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_CabLodCnvConvFact
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_CabLodCnvConvFact');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_CabLodCnvConvFact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CabLodCnvConvFact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CabLodCnvConvFact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_CabLodStaConvFact
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_CabLodStaConvFact');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_CabLodStaConvFact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CabLodStaConvFact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CabLodStaConvFact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_TorqEstCnvActTau
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_TorqEstCnvActTau');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_TorqEstCnvActTau');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TorqEstCnvActTau/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TorqEstCnvActTau');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_TorqEstCnvSpTau
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_TorqEstCnvSpTau');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_TorqEstCnvSpTau');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TorqEstCnvSpTau/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TorqEstCnvSpTau');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_CnvSendTrigAct
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_CnvSendTrigAct');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WCNV','DO','P_CnvSendTrigAct');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CnvSendTrigAct/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CnvSendTrigAct');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_CnvSendTrigSnapAct
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_CnvSendTrigSnapAct');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WCNV','DO','P_CnvSendTrigSnapAct');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CnvSendTrigSnapAct/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CnvSendTrigSnapAct');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_CnvSendTrigEvtAct
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_CnvSendTrigEvtAct');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WCNV','DO','P_CnvSendTrigEvtAct');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_CnvSendTrigEvtAct/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_CnvSendTrigEvtAct');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WCNV/P_PtMotCurMaxLim10mAvg
		subsystem_LN = strcat(subsystem_in,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_get_P_PtMotCurMaxLim10mAvg');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WCNV','DO','P_PtMotCurMaxLim10mAvg');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_PtMotCurMaxLim10mAvg/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_PtMotCurMaxLim10mAvg');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WCNV')
		
	
		% WTRF/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WTRF','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
	
		% WTRF/AuxTrfTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_AuxTrfTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','AuxTrfTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxTrfTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxTrfTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/AuxPwrCtlAct
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_AuxPwrCtlAct');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','AuxPwrCtlAct');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxPwrCtlAct/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxPwrCtlAct');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/AuxPwrCtlSwOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_AuxPwrCtlSwOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','AuxPwrCtlSwOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxPwrCtlSwOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxPwrCtlSwOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilTmpOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilTmpOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfOilTmpOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilTmpOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilTmpOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilTmpFuOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilTmpFuOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfOilTmpFuOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilTmpFuOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilTmpFuOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOvVOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOvVOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfOvVOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOvVOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOvVOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfCCtBrOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfCCtBrOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSTrfCCtBrOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfCCtBrOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfCCtBrOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfCCtBrTripped
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfCCtBrTripped');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSTrfCCtBrTripped');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfCCtBrTripped/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfCCtBrTripped');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/ExtProtDev
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_ExtProtDev');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','ExtProtDev');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ExtProtDev/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ExtProtDev');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfDiscon
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfDiscon');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSTrfDiscon');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfDiscon/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfDiscon');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfEarthed
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfEarthed');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSTrfEarthed');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfEarthed/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfEarthed');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfPmpOvlOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfPmpOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfPmpOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfPmpOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfPmpOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfLiquidLvlOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfLiquidLvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfLiquidLvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfLiquidLvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfLiquidLvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfPmpThermistorOK
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfPmpThermistorOK');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfPmpThermistorOK');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfPmpThermistorOK/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfPmpThermistorOK');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl1DisconOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl1DisconOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSOutl1DisconOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl1DisconOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl1DisconOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl1EarthingSwOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl1EarthingSwOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSOutl1EarthingSwOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl1EarthingSwOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl1EarthingSwOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl2DisconOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl2DisconOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSOutl2DisconOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl2DisconOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl2DisconOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl2EarthingSwOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl2EarthingSwOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSOutl2EarthingSwOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl2EarthingSwOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl2EarthingSwOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilTmpFltOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilTmpFltOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfOilTmpFltOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilTmpFltOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilTmpFltOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSGridDisconOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSGridDisconOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSGridDisconOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSGridDisconOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSGridDisconOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSGridEarthingSwOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSGridEarthingSwOn');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSGridEarthingSwOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSGridEarthingSwOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSGridEarthingSwOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfProtFailureOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfProtFailureOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','MVSTrfProtFailureOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfProtFailureOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfProtFailureOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilPresOk
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilPresOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTRF','DO','TrfOilPresOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilPresOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilPresOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfPmpOn
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfPmpOn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTRF','DO','TrfPmpOn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfPmpOn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfPmpOn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/SLCMVSTrfRemOff
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_SLCMVSTrfRemOff');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTRF','DO','SLCMVSTrfRemOff');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCMVSTrfRemOff/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCMVSTrfRemOff');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfInnerSpaceTmp
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfInnerSpaceTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRF','DO','TrfInnerSpaceTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfInnerSpaceTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfInnerSpaceTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/AuxTrfTmp
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_AuxTrfTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTRF','DO','AuxTrfTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxTrfTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxTrfTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfInnerSpaceTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfInnerSpaceTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRF','DO','TrfInnerSpaceTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfInnerSpaceTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfInnerSpaceTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/AuxTrfTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_AuxTrfTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTRF','DO','AuxTrfTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxTrfTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxTrfTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/AuxPwrCtlActFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_AuxPwrCtlActFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','AuxPwrCtlActFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxPwrCtlActFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxPwrCtlActFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/AuxPwrCtlSwOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_AuxPwrCtlSwOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','AuxPwrCtlSwOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AuxPwrCtlSwOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AuxPwrCtlSwOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilTmpOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilTmpOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfOilTmpOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilTmpOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilTmpOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilTmpFuOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilTmpFuOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfOilTmpFuOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilTmpFuOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilTmpFuOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOvVOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOvVOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfOvVOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOvVOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOvVOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfCCtBrOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfCCtBrOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSTrfCCtBrOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfCCtBrOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfCCtBrOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfCCtBrTrippedFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfCCtBrTrippedFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSTrfCCtBrTrippedFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfCCtBrTrippedFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfCCtBrTrippedFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/ExtProtDevFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_ExtProtDevFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','ExtProtDevFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ExtProtDevFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ExtProtDevFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfDisconFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfDisconFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSTrfDisconFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfDisconFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfDisconFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfEarthedFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfEarthedFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSTrfEarthedFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfEarthedFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfEarthedFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfPmpOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfPmpOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfPmpOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfPmpOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfLiquidLvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfLiquidLvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfLiquidLvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfLiquidLvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfLiquidLvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfPmpThermistorOKFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfPmpThermistorOKFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfPmpThermistorOKFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfPmpThermistorOKFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfPmpThermistorOKFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl1DisconOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl1DisconOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSOutl1DisconOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl1DisconOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl1DisconOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl1EarthingSwOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl1EarthingSwOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSOutl1EarthingSwOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl1EarthingSwOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl1EarthingSwOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl2DisconOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl2DisconOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSOutl2DisconOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl2DisconOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl2DisconOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSOutl2EarthingSwOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSOutl2EarthingSwOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSOutl2EarthingSwOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSOutl2EarthingSwOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSOutl2EarthingSwOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilTmpFltOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilTmpFltOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfOilTmpFltOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilTmpFltOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilTmpFltOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSGridDisconOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSGridDisconOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSGridDisconOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSGridDisconOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSGridDisconOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSGridEarthingSwOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSGridEarthingSwOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSGridEarthingSwOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSGridEarthingSwOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSGridEarthingSwOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfPmpOnFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfPmpOnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfPmpOnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfPmpOnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfPmpOnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/MVSTrfProtFailureOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_MVSTrfProtFailureOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','MVSTrfProtFailureOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MVSTrfProtFailureOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MVSTrfProtFailureOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/TrfOilPresOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_TrfOilPresOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','TrfOilPresOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TrfOilPresOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TrfOilPresOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WTRF/SLCMVSTrfRemOffFrc
		subsystem_LN = strcat(subsystem_in,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_get_SLCMVSTrfRemOffFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTRF','DO','SLCMVSTrfRemOffFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCMVSTrfRemOffFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCMVSTrfRemOffFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTRF')
		
	
		% WNAC/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WNAC','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
	
		% WNAC/Dir
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Dir');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Dir');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Dir/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Dir');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/WdSpd
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_WdSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','WdSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WdSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WdSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/WdDir
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_WdDir');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','WdDir');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WdDir/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WdDir');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ExTmp
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ExTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','ExTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ExTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ExTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/IntlTmp
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_IntlTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','IntlTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_IntlTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'IntlTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/WdSpdCal
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_WdSpdCal');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','WdSpdCal');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_WdSpdCal/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'WdSpdCal');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/AneIceDetWdSpdCal
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_AneIceDetWdSpdCal');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','AneIceDetWdSpdCal');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AneIceDetWdSpdCal/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AneIceDetWdSpdCal');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1WdSpdCal
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1WdSpdCal');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane1WdSpdCal');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1WdSpdCal/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1WdSpdCal');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane2WdSpdCal
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane2WdSpdCal');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane2WdSpdCal');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane2WdSpdCal/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane2WdSpdCal');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1WdDirCorr
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1WdDirCorr');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane1WdDirCorr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1WdDirCorr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1WdDirCorr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane2WdDirCorr
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane2WdDirCorr');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane2WdDirCorr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane2WdDirCorr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane2WdDirCorr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1a2WdDirCorr
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1a2WdDirCorr');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane1a2WdDirCorr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1a2WdDirCorr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1a2WdDirCorr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1a2WdDir
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1a2WdDir');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane1a2WdDir');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1a2WdDir/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1a2WdDir');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacExTmp1a2Av
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacExTmp1a2Av');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','NacExTmp1a2Av');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacExTmp1a2Av/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacExTmp1a2Av');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacCoolTmpSensFlt
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacCoolTmpSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacCoolTmpSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacCoolTmpSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacCoolTmpSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacCoolPresSensFlt
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacCoolPresSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacCoolPresSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacCoolPresSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacCoolPresSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacCoolPmpInletPresSensFlt
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacCoolPmpInletPresSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacCoolPmpInletPresSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacCoolPmpInletPresSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacCoolPmpInletPresSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/CoolInletPmpPResSensFlt
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_CoolInletPmpPResSensFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','CoolInletPmpPResSensFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CoolInletPmpPResSensFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CoolInletPmpPResSensFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacExtTmp1a2Av
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacExtTmp1a2Av');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','NacExtTmp1a2Av');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacExtTmp1a2Av/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacExtTmp1a2Av');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/IceWrn
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_IceWrn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WNAC','DO','IceWrn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_IceWrn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'IceWrn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/SLCNacSysState
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_SLCNacSysState');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WNAC','DO','SLCNacSysState');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCNacSysState/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCNacSysState');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacFanEn
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacFanEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WNAC','DO','NacFanEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacFanEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacFanEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/MetHtEn
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_MetHtEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WNAC','DO','MetHtEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MetHtEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MetHtEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/LghtRedLvl1
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_LghtRedLvl1');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WNAC','DO','LghtRedLvl1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_LghtRedLvl1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LghtRedLvl1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/LghtRedLvl2
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_LghtRedLvl2');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WNAC','DO','LghtRedLvl2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_LghtRedLvl2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LghtRedLvl2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/SLCNacRs
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_SLCNacRs');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','SLCNacRs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCNacRs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCNacRs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ByVlvOvlOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ByVlvOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','ByVlvOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ByVlvOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ByVlvOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacEStop
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacEStop');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacEStop');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacEStop/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacEStop');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacSmkDetectOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacSmkDetectOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacSmkDetectOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacSmkDetectOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacSmkDetectOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacNoSmkAlm
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacNoSmkAlm');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacNoSmkAlm');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacNoSmkAlm/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacNoSmkAlm');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacVisSensOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacVisSensOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacVisSensOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacVisSensOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacVisSensOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacVisLvl1
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacVisLvl1');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacVisLvl1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacVisLvl1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacVisLvl1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacVisLvl2
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacVisLvl2');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacVisLvl2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacVisLvl2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacVisLvl2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacFanOvlOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacFanOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacFanOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacFanOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacFanOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacFanOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacFanOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NacFanOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacFanOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacFanOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ObstacleLghtOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ObstacleLghtOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','ObstacleLghtOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ObstacleLghtOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ObstacleLghtOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ObstacleLghtMaintOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ObstacleLghtMaintOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','ObstacleLghtMaintOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ObstacleLghtMaintOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ObstacleLghtMaintOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ObstacleLghtFltOk
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ObstacleLghtFltOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','ObstacleLghtFltOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ObstacleLghtFltOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ObstacleLghtFltOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NoIceDet
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NoIceDet');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WNAC','DO','NoIceDet');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NoIceDet/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NoIceDet');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacTmp
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','NacTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacInsideRelHum
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacInsideRelHum');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','NacInsideRelHum');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacInsideRelHum/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacInsideRelHum');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane2WdSpd
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane2WdSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane2WdSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane2WdSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane2WdSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane2WdDir
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane2WdDir');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane2WdDir');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane2WdDir/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane2WdDir');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/AneIceDetWdSpd
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_AneIceDetWdSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','AneIceDetWdSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AneIceDetWdSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AneIceDetWdSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacExTmp
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacExTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','NacExTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacExTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacExTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1WdDir
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1WdDir');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane1WdDir');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1WdDir/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1WdDir');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1WdSpd
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1WdSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','Ane1WdSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1WdSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1WdSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacExTmp2
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacExTmp2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WNAC','DO','NacExTmp2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacExTmp2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacExTmp2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','NacTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacInsideRelHumRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacInsideRelHumRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','NacInsideRelHumRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacInsideRelHumRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacInsideRelHumRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane2WdSpdRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane2WdSpdRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','Ane2WdSpdRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane2WdSpdRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane2WdSpdRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane2WdDirRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane2WdDirRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','Ane2WdDirRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane2WdDirRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane2WdDirRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/AneIceDetWdSpdRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_AneIceDetWdSpdRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','AneIceDetWdSpdRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_AneIceDetWdSpdRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'AneIceDetWdSpdRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacExTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacExTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','NacExTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacExTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacExTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1WdDirRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1WdDirRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','Ane1WdDirRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1WdDirRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1WdDirRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/Ane1WdSpdRaw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_Ane1WdSpdRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','Ane1WdSpdRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_Ane1WdSpdRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'Ane1WdSpdRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacExTmp2Raw
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacExTmp2Raw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WNAC','DO','NacExTmp2Raw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacExTmp2Raw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacExTmp2Raw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacFanSp
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacFanSp');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacFanSp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacFanSp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacFanSp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/IceWrnFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_IceWrnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','IceWrnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_IceWrnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'IceWrnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/SLCNacRsFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_SLCNacRsFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','SLCNacRsFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCNacRsFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCNacRsFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/SLCNacSysStateFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_SLCNacSysStateFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','SLCNacSysStateFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCNacSysStateFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCNacSysStateFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ByVlvOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ByVlvOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','ByVlvOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ByVlvOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ByVlvOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacEStopFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacEStopFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacEStopFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacEStopFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacEStopFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacSmkDetectOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacSmkDetectOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacSmkDetectOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacSmkDetectOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacSmkDetectOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacNoSmkAlmFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacNoSmkAlmFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacNoSmkAlmFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacNoSmkAlmFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacNoSmkAlmFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacFanEnFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacFanEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacFanEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacFanEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacFanEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacVisSensOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacVisSensOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacVisSensOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacVisSensOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacVisSensOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacVisLvl1Frc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacVisLvl1Frc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacVisLvl1Frc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacVisLvl1Frc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacVisLvl1Frc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacVisLvl2Frc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacVisLvl2Frc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacVisLvl2Frc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacVisLvl2Frc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacVisLvl2Frc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacFanOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacFanOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacFanOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacFanOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacFanOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NacFanOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NacFanOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NacFanOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacFanOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacFanOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ObstacleLghtOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ObstacleLghtOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','ObstacleLghtOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ObstacleLghtOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ObstacleLghtOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ObstacleLghtMaintOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ObstacleLghtMaintOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','ObstacleLghtMaintOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ObstacleLghtMaintOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ObstacleLghtMaintOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/ObstacleLghtFltOkFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_ObstacleLghtFltOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','ObstacleLghtFltOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_ObstacleLghtFltOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'ObstacleLghtFltOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/NoIceDetFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_NoIceDetFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','NoIceDetFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NoIceDetFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NoIceDetFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/MetHtEnFrc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_MetHtEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','MetHtEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_MetHtEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'MetHtEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/LghtRedLvl1Frc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_LghtRedLvl1Frc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','LghtRedLvl1Frc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_LghtRedLvl1Frc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LghtRedLvl1Frc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/LghtRedLvl2Frc
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_LghtRedLvl2Frc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','LghtRedLvl2Frc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_LghtRedLvl2Frc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'LghtRedLvl2Frc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacIceDetAne
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacIceDetAne');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WNAC','DO','P_NacIceDetAne');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacIceDetAne/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacIceDetAne');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacIceDetAneSlope
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacIceDetAneSlope');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacIceDetAneSlope');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacIceDetAneSlope/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacIceDetAneSlope');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacIceDetAneBias
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacIceDetAneBias');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacIceDetAneBias');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacIceDetAneBias/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacIceDetAneBias');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Ane1Slope
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Ane1Slope');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Ane1Slope');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Ane1Slope/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Ane1Slope');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Ane1Bias
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Ane1Bias');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Ane1Bias');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Ane1Bias/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Ane1Bias');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Ane1a
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Ane1a');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Ane1a');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Ane1a/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Ane1a');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Ane1b
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Ane1b');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Ane1b');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Ane1b/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Ane1b');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Ane2Slope
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Ane2Slope');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Ane2Slope');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Ane2Slope/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Ane2Slope');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Ane2Bias
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Ane2Bias');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Ane2Bias');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Ane2Bias/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Ane2Bias');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Ane2a
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Ane2a');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Ane2a');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Ane2a/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Ane2a');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_MinGbxSpdWdSpdCal
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_MinGbxSpdWdSpdCal');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_MinGbxSpdWdSpdCal');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_MinGbxSpdWdSpdCal/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_MinGbxSpdWdSpdCal');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Van1Ofs
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Van1Ofs');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Van1Ofs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Van1Ofs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Van1Ofs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Van1RotOfs
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Van1RotOfs');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Van1RotOfs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Van1RotOfs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Van1RotOfs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Van2Ofs
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Van2Ofs');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Van2Ofs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Van2Ofs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Van2Ofs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_Van2RotOfs
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_Van2RotOfs');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_Van2RotOfs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_Van2RotOfs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_Van2RotOfs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacExTmp1SensUpLim
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacExTmp1SensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp1SensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacExTmp1SensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacExTmp1SensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacExTmp1SensLoLim
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacExTmp1SensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp1SensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacExTmp1SensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacExTmp1SensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacExTmp2SensUpLim
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacExTmp2SensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp2SensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacExTmp2SensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacExTmp2SensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacExTmp2SensLoLim
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacExTmp2SensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp2SensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacExTmp2SensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacExTmp2SensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacTmpSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacTmpSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacTmpSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacTmpSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacTmpSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_NacTmpSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_NacTmpSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_NacTmpSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NacTmpSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NacTmpSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WNAC/P_WdSpdChgSpdEvt60
		subsystem_LN = strcat(subsystem_in,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_get_P_WdSpdChgSpdEvt60');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WNAC','DO','P_WdSpdChgSpdEvt60');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_WdSpdChgSpdEvt60/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_WdSpdChgSpdEvt60');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WNAC')
		
	
		% WYAW/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WYAW','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
	
		% WYAW/YwSt
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwSt');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WYAW','DO','YwSt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwSt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwSt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwBrakeSt
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwBrakeSt');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WYAW','DO','YwBrakeSt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwBrakeSt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwBrakeSt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwSpd
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwSpd');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WYAW','DO','YwSpd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwSpd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwSpd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YawAng
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YawAng');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WYAW','DO','YawAng');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YawAng/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YawAng');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/CabWup
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_CabWup');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WYAW','DO','CabWup');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabWup/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabWup');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwErr
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwErr');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WYAW','DO','YwErr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwErr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwErr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TwrBaseYwManCCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseYwManCCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','TwrBaseYwManCCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseYwManCCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseYwManCCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TwrBaseYwManCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseYwManCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','TwrBaseYwManCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseYwManCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseYwManCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCEStopNacOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopNacOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','SLCEStopNacOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopNacOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopNacOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCCabTwistedCWOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCCabTwistedCWOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','SLCCabTwistedCWOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCCabTwistedCWOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCCabTwistedCWOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCCabTwistedCCWOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCCabTwistedCCWOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','SLCCabTwistedCCWOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCCabTwistedCCWOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCCabTwistedCCWOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwEnFdbk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwEnFdbk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','SLCYwEnFdbk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwEnFdbk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwEnFdbk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TopBoxYwManCCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxYwManCCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','TopBoxYwManCCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxYwManCCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxYwManCCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TopBoxYwManCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxYwManCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','TopBoxYwManCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxYwManCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxYwManCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwDrvOff
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwDrvOff');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwDrvOff');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwDrvOff/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwDrvOff');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwEncCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwEncCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwEncCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwEncCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwEncCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwEncCCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwEncCCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwEncCCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwEncCCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwEncCCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/NacPosNorth
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_NacPosNorth');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','NacPosNorth');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacPosNorth/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacPosNorth');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/CabTwistCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_CabTwistCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','CabTwistCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabTwistCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabTwistCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/CabTwistCCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_CabTwistCCW');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','CabTwistCCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabTwistCCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabTwistCCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpOvlOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwLuPmpOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwLuPmpOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwMot1t2OvlOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwMot1t2OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwMot1t2OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwMot1t2OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwMot1t2OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwMot3t4OvlOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwMot3t4OvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwMot3t4OvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwMot3t4OvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwMot3t4OvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwElecBrkOvlOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwElecBrkOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwElecBrkOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwElecBrkOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwElecBrkOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwBrkTmpOk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwBrkTmpOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwBrkTmpOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwBrkTmpOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwBrkTmpOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpCysSw
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpCysSw');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WYAW','DO','YwLuPmpCysSw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpCysSw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpCysSw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwEn
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WYAW','DO','SLCYwEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwDrvCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwDrvCW');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WYAW','DO','SLCYwDrvCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwDrvCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwDrvCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwDrvCCW
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwDrvCCW');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WYAW','DO','SLCYwDrvCCW');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwDrvCCW/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwDrvCCW');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwElecBrk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwElecBrk');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WYAW','DO','SLCYwElecBrk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwElecBrk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwElecBrk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwBrk
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwBrk');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WYAW','DO','SLCYwBrk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwBrk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwBrk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwBrkResPres
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwBrkResPres');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WYAW','DO','SLCYwBrkResPres');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwBrkResPres/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwBrkResPres');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpEn
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpEn');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WYAW','DO','YwLuPmpEn');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpEn/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpEn');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwMotCur
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwMotCur');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WYAW','DO','YwMotCur');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwMotCur/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwMotCur');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwMotCurRaw
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwMotCurRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WYAW','DO','YwMotCurRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwMotCurRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwMotCurRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TwrBaseYwManCCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseYwManCCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','TwrBaseYwManCCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseYwManCCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseYwManCCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TwrBaseYwManCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseYwManCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','TwrBaseYwManCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseYwManCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseYwManCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCEStopNacOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCEStopNacOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCEStopNacOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCEStopNacOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCEStopNacOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCCabTwistedCWOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCCabTwistedCWOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCCabTwistedCWOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCCabTwistedCWOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCCabTwistedCWOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCCabTwistedCCWOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCCabTwistedCCWOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCCabTwistedCCWOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCCabTwistedCCWOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCCabTwistedCCWOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwEnFdbkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwEnFdbkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCYwEnFdbkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwEnFdbkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwEnFdbkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwEnFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCYwEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwDrvCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwDrvCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCYwDrvCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwDrvCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwDrvCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwDrvCCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwDrvCCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCYwDrvCCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwDrvCCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwDrvCCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwElecBrkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwElecBrkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCYwElecBrkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwElecBrkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwElecBrkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwBrkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwBrkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCYwBrkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwBrkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwBrkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/SLCYwBrkResPresFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_SLCYwBrkResPresFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','SLCYwBrkResPresFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_SLCYwBrkResPresFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'SLCYwBrkResPresFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TopBoxYwManCCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxYwManCCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','TopBoxYwManCCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxYwManCCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxYwManCCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/TopBoxYwManCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_TopBoxYwManCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','TopBoxYwManCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TopBoxYwManCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TopBoxYwManCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwDrvOffFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwDrvOffFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwDrvOffFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwDrvOffFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwDrvOffFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwEncCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwEncCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwEncCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwEncCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwEncCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwEncCCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwEncCCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwEncCCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwEncCCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwEncCCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/NacPosNorthFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_NacPosNorthFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','NacPosNorthFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NacPosNorthFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NacPosNorthFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/CabTwistCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_CabTwistCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','CabTwistCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabTwistCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabTwistCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/CabTwistCCWFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_CabTwistCCWFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','CabTwistCCWFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_CabTwistCCWFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'CabTwistCCWFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwMot1t2OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwMot1t2OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwMot1t2OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwMot1t2OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwMot1t2OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwMot3t4OvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwMot3t4OvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwMot3t4OvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwMot3t4OvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwMot3t4OvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwElecBrkOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwElecBrkOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwElecBrkOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwElecBrkOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwElecBrkOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwBrkTmpOkFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwBrkTmpOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwBrkTmpOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwBrkTmpOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwBrkTmpOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpCysSwFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpCysSwFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpCysSwFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpCysSwFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpCysSwFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLuPmpEnFrc
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLuPmpEnFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpEnFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLuPmpEnFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLuPmpEnFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/P_YwMaxCntFlt
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_P_YwMaxCntFlt');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','P_YwMaxCntFlt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_YwMaxCntFlt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_YwMaxCntFlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/P_YwCogNum
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_P_YwCogNum');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','P_YwCogNum');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_YwCogNum/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_YwCogNum');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/P_YwZeroOfs
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_P_YwZeroOfs');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','P_YwZeroOfs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_YwZeroOfs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_YwZeroOfs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/P_NoYwSpdDl
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_P_NoYwSpdDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','P_NoYwSpdDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_NoYwSpdDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_NoYwSpdDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/P_SensFltDl
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_P_SensFltDl');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WYAW','DO','P_SensFltDl');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_SensFltDl/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_SensFltDl');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WYAW/YwLev
		subsystem_LN = strcat(subsystem_in,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_get_YwLev');
		
		add_block(lib_wttl_get,block,'CDC','STV','LN','WYAW','DO','YwLev');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_YwLev/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'YwLev');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WYAW')
		
	
		% WTOW/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WTOW','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
	
		% WTOW/TwrAcc2EFX
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAcc2EFX');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFX');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAcc2EFX/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAcc2EFX');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAcc2EFXAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAcc2EFXAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFXAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAcc2EFXAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAcc2EFXAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAcc2EFY
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAcc2EFY');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFY');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAcc2EFY/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAcc2EFY');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAcc2EFYAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAcc2EFYAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFYAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAcc2EFYAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAcc2EFYAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX1Abs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX1Abs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX1Abs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX1Abs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX1Abs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX1HiPassFilt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX1HiPassFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX1HiPassFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX1HiPassFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX1HiPassFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX1LoPassFilt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX1LoPassFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX1LoPassFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX1LoPassFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX1LoPassFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX1LoPassFiltAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX1LoPassFiltAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX1LoPassFiltAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX1LoPassFiltAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX1LoPassFiltAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX1Pk
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX1Pk');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX1Pk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX1Pk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX1Pk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX2Abs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX2Abs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX2Abs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX2Abs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX2Abs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX2HiPassFilt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX2HiPassFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX2HiPassFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX2HiPassFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX2HiPassFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrHiPassFiltAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrHiPassFiltAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrHiPassFiltAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrHiPassFiltAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrHiPassFiltAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrLoPassFilt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrLoPassFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrLoPassFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrLoPassFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrLoPassFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrLoPassFiltAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrLoPassFiltAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrLoPassFiltAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrLoPassFiltAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrLoPassFiltAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX23P
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX23P');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX23P');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX23P/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX23P');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX23PAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX23PAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX23PAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX23PAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX23PAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX2nP
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX2nP');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX2nP');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX2nP/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX2nP');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX2nPAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX2nPAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX2nPAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX2nPAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX2nPAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY1Abs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY1Abs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY1Abs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY1Abs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY1Abs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY1HiPassFilt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY1HiPassFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY1HiPassFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY1HiPassFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY1HiPassFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY1LoPassFilt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY1LoPassFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY1LoPassFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY1LoPassFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY1LoPassFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY1LoPassFiltAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY1LoPassFiltAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY1LoPassFiltAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY1LoPassFiltAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY1LoPassFiltAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY1Pk
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY1Pk');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY1Pk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY1Pk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY1Pk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY2Abs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY2Abs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY2Abs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY2Abs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY2Abs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY2HiPassFilt
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY2HiPassFilt');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY2HiPassFilt');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY2HiPassFilt/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY2HiPassFilt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY23P
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY23P');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY23P');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY23P/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY23P');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY23PAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY23PAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY23PAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY23PAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY23PAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY2nP
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY2nP');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY2nP');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY2nP/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY2nP');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY2nPAbs
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY2nPAbs');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY2nPAbs');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY2nPAbs/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY2nPAbs');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAcc2EFXRaw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAcc2EFXRaw');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFXRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAcc2EFXRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAcc2EFXRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAcc2EFYRaw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAcc2EFYRaw');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFYRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAcc2EFYRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAcc2EFYRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrFanOk
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrFanOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','TwrFanOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrFanOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrFanOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/NoPersTwrBase
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_NoPersTwrBase');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','NoPersTwrBase');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NoPersTwrBase/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NoPersTwrBase');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrDoorClsd
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrDoorClsd');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','TwrDoorClsd');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrDoorClsd/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrDoorClsd');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrFanOvlOk
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrFanOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','TwrFanOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrFanOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrFanOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseNoSmkAlm
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseNoSmkAlm');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','TwrBaseNoSmkAlm');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseNoSmkAlm/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseNoSmkAlm');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrExtrFanOk
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrExtrFanOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','TwrExtrFanOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrExtrFanOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrExtrFanOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrExtrFanOvlOk
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrExtrFanOvlOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','TwrExtrFanOvlOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrExtrFanOvlOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrExtrFanOvlOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/OscillSensOk
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_OscillSensOk');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','OscillSensOk');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_OscillSensOk/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'OscillSensOk');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrVbr
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrVbr');
		
		add_block(lib_wttl_get,block,'CDC','SPS','LN','WTOW','DO','TwrVbr');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrVbr/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrVbr');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseTmpEx
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseTmpEx');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrBaseTmpEx');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseTmpEx/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseTmpEx');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseTmp
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseTmp');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrBaseTmp');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseTmp/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseTmp');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseRelHum
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseRelHum');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrBaseRelHum');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseRelHum/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseRelHum');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY1
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY1');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX1
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX1');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX1');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX1/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY2
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccY2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX2
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX2');
		
		add_block(lib_wttl_get,block,'CDC','MV','LN','WTOW','DO','TwrAccX2');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX2/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX2');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseTmpExRaw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseTmpExRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTOW','DO','TwrBaseTmpExRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseTmpExRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseTmpExRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseTmpRaw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseTmpRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTOW','DO','TwrBaseTmpRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseTmpRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseTmpRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseRelHumRaw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseRelHumRaw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTOW','DO','TwrBaseRelHumRaw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseRelHumRaw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseRelHumRaw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY1Raw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY1Raw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTOW','DO','TwrAccY1Raw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY1Raw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY1Raw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX1Raw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX1Raw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTOW','DO','TwrAccX1Raw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX1Raw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX1Raw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccY2Raw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccY2Raw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTOW','DO','TwrAccY2Raw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccY2Raw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccY2Raw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrAccX2Raw
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrAccX2Raw');
		
		add_block(lib_wttl_get,block,'CDC','INS','LN','WTOW','DO','TwrAccX2Raw');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrAccX2Raw/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrAccX2Raw');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TestVibrSens
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TestVibrSens');
		
		add_block(lib_wttl_get,block,'CDC','SPC','LN','WTOW','DO','TestVibrSens');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TestVibrSens/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TestVibrSens');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrFanOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrFanOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TwrFanOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrFanOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrFanOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/NoPersTwrBaseFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_NoPersTwrBaseFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','NoPersTwrBaseFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_NoPersTwrBaseFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'NoPersTwrBaseFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrDoorClsdFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrDoorClsdFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TwrDoorClsdFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrDoorClsdFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrDoorClsdFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrFanOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrFanOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TwrFanOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrFanOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrFanOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrBaseNoSmkAlmFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrBaseNoSmkAlmFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TwrBaseNoSmkAlmFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrBaseNoSmkAlmFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrBaseNoSmkAlmFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrExtrFanOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrExtrFanOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TwrExtrFanOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrExtrFanOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrExtrFanOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrExtrFanOvlOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrExtrFanOvlOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TwrExtrFanOvlOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrExtrFanOvlOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrExtrFanOvlOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TestVibrSensFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TestVibrSensFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TestVibrSensFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TestVibrSensFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TestVibrSensFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/OscillSensOkFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_OscillSensOkFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','OscillSensOkFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_OscillSensOkFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'OscillSensOkFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/TwrVbrFrc
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_TwrVbrFrc');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','TwrVbrFrc');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_TwrVbrFrc/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'TwrVbrFrc');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrBaseTmpSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrBaseTmpSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrBaseTmpSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrBaseTmpSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrBaseTmpSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrBaseTmpSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrBaseTmpSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrBaseTmpSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_RotBrkPresSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_RotBrkPresSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_RotBrkPresSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_RotBrkPresSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_RotBrkPresSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_RotBrkPresSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_RotBrkPresSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_RotBrkPresSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_RotBrkPresSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_RotBrkPresSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrBaseTmpExSensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrBaseTmpExSensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpExSensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrBaseTmpExSensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrBaseTmpExSensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrBaseTmpExSensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrBaseTmpExSensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpExSensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrBaseTmpExSensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrBaseTmpExSensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrEigFreq
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrEigFreq');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrEigFreq');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrEigFreq/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrEigFreq');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccBandPassFiltGain
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccBandPassFiltGain');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccBandPassFiltGain');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccBandPassFiltGain/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccBandPassFiltGain');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccBandPassFiltCutOffFrq
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccBandPassFiltCutOffFrq');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccBandPassFiltCutOffFrq');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccBandPassFiltCutOffFrq/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccBandPassFiltCutOffFrq');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccBandPassFiltShapeFact
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccBandPassFiltShapeFact');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccBandPassFiltShapeFact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccBandPassFiltShapeFact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccBandPassFiltShapeFact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccX1SensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccX1SensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX1SensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccX1SensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccX1SensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccX1SensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccX1SensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX1SensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccX1SensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccX1SensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccX2SensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccX2SensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX2SensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccX2SensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccX2SensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccX2SensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccX2SensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX2SensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccX2SensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccX2SensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccY1SensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccY1SensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY1SensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccY1SensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccY1SensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccY1SensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccY1SensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY1SensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccY1SensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccY1SensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccY2SensUpLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccY2SensUpLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY2SensUpLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccY2SensUpLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccY2SensUpLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_TwrAccY2SensLoLim
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_TwrAccY2SensLoLim');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY2SensLoLim');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_TwrAccY2SensLoLim/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_TwrAccY2SensLoLim');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_nPFiltShapeFact
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_nPFiltShapeFact');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_nPFiltShapeFact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_nPFiltShapeFact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_nPFiltShapeFact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_nPFiltFact
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_nPFiltFact');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_nPFiltFact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_nPFiltFact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_nPFiltFact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WTOW/P_3PFiltShapeFact
		subsystem_LN = strcat(subsystem_in,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_get_P_3PFiltShapeFact');
		
		add_block(lib_wttl_get,block,'CDC','SPV','LN','WTOW','DO','P_3PFiltShapeFact');
		
		bus_inputs = get_param(strcat(subsystem_LN,'/bus'),'Inputs');
		bus_inputs = str2double(bus_inputs) + 1;
		set_param(strcat(subsystem_LN,'/bus'),'Inputs',int2str(bus_inputs));
		
		lineHandle = add_line(subsystem_LN,'wttl_get_P_3PFiltShapeFact/1',strcat('bus/',int2str(bus_inputs)));
		set_param(lineHandle, 'Name', 'P_3PFiltShapeFact');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WTOW')
		
	
		% WALM/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WALM');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WALM','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WALM')
	
		% WSLG/NamPlt
		subsystem_LN = strcat(subsystem_in,'/WSLG');
		block        = strcat(subsystem_LN,'/wttl_get_NamPlt');
		
		add_block(lib_wttl_get,block,'CDC','LPL','LN','WSLG','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input/WSLG')

	%% Simulation Level
	delete_line(subsystem_sim,'In1/1','Out1/1');
	add_block('simulink/Sinks/Terminator',strcat(subsystem_sim,'/Terminator'));
	add_line(subsystem_sim,'In1/1', 'Terminator/1');
	add_block('simulink/Sources/Ground',strcat(subsystem_sim,'/Ground'));
	add_line(subsystem_sim,'Ground/1', 'Out1/1');

	%% Output Level
	delete_line(subsystem_out,'In1/1','Out1/1');
	delete_block(strcat(subsystem_out,'/Out1'));
	add_block('simulink/Sinks/Terminator',strcat(subsystem_out,'/Terminator'));
	add_line(subsystem_out,'In1/1', 'Terminator/1');
	
	%% LN Level
	% add subsystem for each logical node
	
		% LLN0
		subsystem_LN = strcat(subsystem_out,'/LLN0');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% LPHD
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WTUR
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WROT
		subsystem_LN = strcat(subsystem_out,'/WROT');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WTRM
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WGEN
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WCNV
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WTRF
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WNAC
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WYAW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WTOW
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WALM
		subsystem_LN = strcat(subsystem_out,'/WALM');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	
	
		% WSLG
		subsystem_LN = strcat(subsystem_out,'/WSLG');
		
		add_block('simulink/Ports & Subsystems/Subsystem',subsystem_LN);
		delete_line(subsystem_LN,'In1/1','Out1/1');
		delete_block(strcat(subsystem_LN,'/In1'));
		delete_block(strcat(subsystem_LN,'/Out1'));
	

	%% CDC Level
	% add Block wttl_get in subsystem for each dataobject 
	
		% LLN0/NamPlt
		subsystem_LN = strcat(subsystem_out,'/LLN0');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','LLN0','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LLN0')
	
		% LPHD/PhyNam
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_PhyNam');
		
		add_block(lib_wttl_set,block,'CDC','WDPL','LN','LPHD','DO','PhyNam');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PhyNam'));
		add_line(subsystem_LN,'Ground_PhyNam/1', 'wttl_set_PhyNam/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/PhyHealth
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_PhyHealth');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','LPHD','DO','PhyHealth');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PhyHealth'));
		add_line(subsystem_LN,'Ground_PhyHealth/1', 'wttl_set_PhyHealth/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/Proxy
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_Proxy');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','LPHD','DO','Proxy');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Proxy'));
		add_line(subsystem_LN,'Ground_Proxy/1', 'wttl_set_Proxy/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/FileHdlCm
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_FileHdlCm');
		
		add_block(lib_wttl_set,block,'CDC','CMD','LN','LPHD','DO','FileHdlCm');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FileHdlCm'));
		add_line(subsystem_LN,'Ground_FileHdlCm/1', 'wttl_set_FileHdlCm/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/LogCm
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_LogCm');
		
		add_block(lib_wttl_set,block,'CDC','CMD','LN','LPHD','DO','LogCm');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_LogCm'));
		add_line(subsystem_LN,'Ground_LogCm/1', 'wttl_set_LogCm/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/LogDevMem
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_LogDevMem');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','LPHD','DO','LogDevMem');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_LogDevMem'));
		add_line(subsystem_LN,'Ground_LogDevMem/1', 'wttl_set_LogDevMem/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/FtpSrvHost1
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_FtpSrvHost1');
		
		add_block(lib_wttl_set,block,'CDC','VSG','LN','LPHD','DO','FtpSrvHost1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FtpSrvHost1'));
		add_line(subsystem_LN,'Ground_FtpSrvHost1/1', 'wttl_set_FtpSrvHost1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/FtpSrvUsr1
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_FtpSrvUsr1');
		
		add_block(lib_wttl_set,block,'CDC','VSG','LN','LPHD','DO','FtpSrvUsr1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FtpSrvUsr1'));
		add_line(subsystem_LN,'Ground_FtpSrvUsr1/1', 'wttl_set_FtpSrvUsr1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/FtpSrvPwd1
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_FtpSrvPwd1');
		
		add_block(lib_wttl_set,block,'CDC','VSG','LN','LPHD','DO','FtpSrvPwd1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FtpSrvPwd1'));
		add_line(subsystem_LN,'Ground_FtpSrvPwd1/1', 'wttl_set_FtpSrvPwd1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% LPHD/FtpSrv1Cm
		subsystem_LN = strcat(subsystem_out,'/LPHD');
		block        = strcat(subsystem_LN,'/wttl_set_FtpSrv1Cm');
		
		add_block(lib_wttl_set,block,'CDC','CMD','LN','LPHD','DO','FtpSrv1Cm');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FtpSrv1Cm'));
		add_line(subsystem_LN,'Ground_FtpSrv1Cm/1', 'wttl_set_FtpSrv1Cm/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/LPHD')
	
	
		% WTUR/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WTUR','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
		% WTUR/TotWh
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TotWh');
		
		add_block(lib_wttl_set,block,'CDC','CTE','LN','WTUR','DO','TotWh');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TotWh'));
		add_line(subsystem_LN,'Ground_TotWh/1', 'wttl_set_TotWh/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TotVArh
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TotVArh');
		
		add_block(lib_wttl_set,block,'CDC','CTE','LN','WTUR','DO','TotVArh');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TotVArh'));
		add_line(subsystem_LN,'Ground_TotVArh/1', 'wttl_set_TotVArh/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TurSt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TurSt');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WTUR','DO','TurSt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TurSt'));
		add_line(subsystem_LN,'Ground_TurSt/1', 'wttl_set_TurSt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/W
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_W');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','W');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_W'));
		add_line(subsystem_LN,'Ground_W/1', 'wttl_set_W/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/VAr
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_VAr');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','VAr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_VAr'));
		add_line(subsystem_LN,'Ground_VAr/1', 'wttl_set_VAr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SetTurOp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SetTurOp');
		
		add_block(lib_wttl_set,block,'CDC','CMD','LN','WTUR','DO','SetTurOp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SetTurOp'));
		add_line(subsystem_LN,'Ground_SetTurOp/1', 'wttl_set_SetTurOp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TwrBaseTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseTmpSensFlt'));
		add_line(subsystem_LN,'Ground_TwrBaseTmpSensFlt/1', 'wttl_set_TwrBaseTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TopBoxTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxTmpSensFlt'));
		add_line(subsystem_LN,'Ground_TopBoxTmpSensFlt/1', 'wttl_set_TopBoxTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BottomBoxTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BottomBoxTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','BottomBoxTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BottomBoxTmpSensFlt'));
		add_line(subsystem_LN,'Ground_BottomBoxTmpSensFlt/1', 'wttl_set_BottomBoxTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TrfInnerSpaceTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TrfInnerSpaceTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TrfInnerSpaceTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfInnerSpaceTmpSensFlt'));
		add_line(subsystem_LN,'Ground_TrfInnerSpaceTmpSensFlt/1', 'wttl_set_TrfInnerSpaceTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CPUTmp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CPUTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','CPUTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CPUTmp'));
		add_line(subsystem_LN,'Ground_CPUTmp/1', 'wttl_set_CPUTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HyPresRte
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HyPresRte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','HyPresRte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HyPresRte'));
		add_line(subsystem_LN,'Ground_HyPresRte/1', 'wttl_set_HyPresRte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ReactPwr
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ReactPwr');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','ReactPwr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ReactPwr'));
		add_line(subsystem_LN,'Ground_ReactPwr/1', 'wttl_set_ReactPwr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TurbDet
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TurbDet');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TurbDet');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TurbDet'));
		add_line(subsystem_LN,'Ground_TurbDet/1', 'wttl_set_TurbDet/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/WdDirDeviLev1
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_WdDirDeviLev1');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','WdDirDeviLev1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WdDirDeviLev1'));
		add_line(subsystem_LN,'Ground_WdDirDeviLev1/1', 'wttl_set_WdDirDeviLev1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/WdDirDeviLev2
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_WdDirDeviLev2');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','WdDirDeviLev2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WdDirDeviLev2'));
		add_line(subsystem_LN,'Ground_WdDirDeviLev2/1', 'wttl_set_WdDirDeviLev2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TurStFwd
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TurStFwd');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WTUR','DO','TurStFwd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TurStFwd'));
		add_line(subsystem_LN,'Ground_TurStFwd/1', 'wttl_set_TurStFwd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TurStBwd
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TurStBwd');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WTUR','DO','TurStBwd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TurStBwd'));
		add_line(subsystem_LN,'Ground_TurStBwd/1', 'wttl_set_TurStBwd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BrkLev
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BrkLev');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WTUR','DO','BrkLev');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BrkLev'));
		add_line(subsystem_LN,'Ground_BrkLev/1', 'wttl_set_BrkLev/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BrkLevLim
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BrkLevLim');
		
		add_block(lib_wttl_set,block,'CDC','INC','LN','WTUR','DO','BrkLevLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BrkLevLim'));
		add_line(subsystem_LN,'Ground_BrkLevLim/1', 'wttl_set_BrkLevLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/RsEvt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_RsEvt');
		
		add_block(lib_wttl_set,block,'CDC','INC','LN','WTUR','DO','RsEvt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RsEvt'));
		add_line(subsystem_LN,'Ground_RsEvt/1', 'wttl_set_RsEvt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/Parm
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_Parm');
		
		add_block(lib_wttl_set,block,'CDC','CMD','LN','WTUR','DO','Parm');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Parm'));
		add_line(subsystem_LN,'Ground_Parm/1', 'wttl_set_Parm/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ActEgyCnt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ActEgyCnt');
		
		add_block(lib_wttl_set,block,'CDC','CTE','LN','WTUR','DO','ActEgyCnt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ActEgyCnt'));
		add_line(subsystem_LN,'Ground_ActEgyCnt/1', 'wttl_set_ActEgyCnt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ReactEgyCnt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ReactEgyCnt');
		
		add_block(lib_wttl_set,block,'CDC','CTE','LN','WTUR','DO','ReactEgyCnt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ReactEgyCnt'));
		add_line(subsystem_LN,'Ground_ReactEgyCnt/1', 'wttl_set_ReactEgyCnt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/AuxActEgyCnt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_AuxActEgyCnt');
		
		add_block(lib_wttl_set,block,'CDC','CTE','LN','WTUR','DO','AuxActEgyCnt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxActEgyCnt'));
		add_line(subsystem_LN,'Ground_AuxActEgyCnt/1', 'wttl_set_AuxActEgyCnt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BoilerPresLow
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BoilerPresLow');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','BoilerPresLow');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BoilerPresLow'));
		add_line(subsystem_LN,'Ground_BoilerPresLow/1', 'wttl_set_BoilerPresLow/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ExtDeactSoundMgt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ExtDeactSoundMgt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','ExtDeactSoundMgt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ExtDeactSoundMgt'));
		add_line(subsystem_LN,'Ground_ExtDeactSoundMgt/1', 'wttl_set_ExtDeactSoundMgt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BaseBoxEmgStop
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BaseBoxEmgStop');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','BaseBoxEmgStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BaseBoxEmgStop'));
		add_line(subsystem_LN,'Ground_BaseBoxEmgStop/1', 'wttl_set_BaseBoxEmgStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ShdSwOff
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ShdSwOff');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','ShdSwOff');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ShdSwOff'));
		add_line(subsystem_LN,'Ground_ShdSwOff/1', 'wttl_set_ShdSwOff/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ShdSwModuleOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ShdSwModuleOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','ShdSwModuleOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ShdSwModuleOk'));
		add_line(subsystem_LN,'Ground_ShdSwModuleOk/1', 'wttl_set_ShdSwModuleOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/WTGStop
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_WTGStop');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','WTGStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WTGStop'));
		add_line(subsystem_LN,'Ground_WTGStop/1', 'wttl_set_WTGStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SpareProtShtoffOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SpareProtShtoffOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','SpareProtShtoffOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SpareProtShtoffOk'));
		add_line(subsystem_LN,'Ground_SpareProtShtoffOk/1', 'wttl_set_SpareProtShtoffOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseEmgStop
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseEmgStop');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TwrBaseEmgStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseEmgStop'));
		add_line(subsystem_LN,'Ground_TwrBaseEmgStop/1', 'wttl_set_TwrBaseEmgStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UpsOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UpsOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','UpsOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UpsOk'));
		add_line(subsystem_LN,'Ground_UpsOk/1', 'wttl_set_UpsOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseManStop
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseManStop');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TwrBaseManStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseManStop'));
		add_line(subsystem_LN,'Ground_TwrBaseManStop/1', 'wttl_set_TwrBaseManStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseBoxSwOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseBoxSwOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TwrBaseBoxSwOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseBoxSwOk'));
		add_line(subsystem_LN,'Ground_TwrBaseBoxSwOk/1', 'wttl_set_TwrBaseBoxSwOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseBoxOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseBoxOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TwrBaseBoxOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseBoxOk'));
		add_line(subsystem_LN,'Ground_TwrBaseBoxOk/1', 'wttl_set_TwrBaseBoxOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrDistrCabinetOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrDistrCabinetOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TwrDistrCabinetOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrDistrCabinetOk'));
		add_line(subsystem_LN,'Ground_TwrDistrCabinetOk/1', 'wttl_set_TwrDistrCabinetOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UPSFailureOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UPSFailureOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','UPSFailureOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UPSFailureOk'));
		add_line(subsystem_LN,'Ground_UPSFailureOk/1', 'wttl_set_UPSFailureOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UPSBattWarn
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UPSBattWarn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','UPSBattWarn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UPSBattWarn'));
		add_line(subsystem_LN,'Ground_UPSBattWarn/1', 'wttl_set_UPSBattWarn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan1Ok
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan1Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan1Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan1Ok'));
		add_line(subsystem_LN,'Ground_CoolSysFan1Ok/1', 'wttl_set_CoolSysFan1Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan2Ok
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan2Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan2Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan2Ok'));
		add_line(subsystem_LN,'Ground_CoolSysFan2Ok/1', 'wttl_set_CoolSysFan2Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan3Ok
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan3Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan3Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan3Ok'));
		add_line(subsystem_LN,'Ground_CoolSysFan3Ok/1', 'wttl_set_CoolSysFan3Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan4Ok
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan4Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysFan4Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan4Ok'));
		add_line(subsystem_LN,'Ground_CoolSysFan4Ok/1', 'wttl_set_CoolSysFan4Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFansHeatOverlOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFansHeatOverlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysFansHeatOverlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFansHeatOverlOk'));
		add_line(subsystem_LN,'Ground_CoolSysFansHeatOverlOk/1', 'wttl_set_CoolSysFansHeatOverlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysCoolHeater1a2Ok
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysCoolHeater1a2Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysCoolHeater1a2Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysCoolHeater1a2Ok'));
		add_line(subsystem_LN,'Ground_CoolSysCoolHeater1a2Ok/1', 'wttl_set_CoolSysCoolHeater1a2Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysPresSw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysPresSw');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysPresSw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysPresSw'));
		add_line(subsystem_LN,'Ground_CoolSysPresSw/1', 'wttl_set_CoolSysPresSw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysPmpOverlOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysPmpOverlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolSysPmpOverlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysPmpOverlOk'));
		add_line(subsystem_LN,'Ground_CoolSysPmpOverlOk/1', 'wttl_set_CoolSysPmpOverlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCTwrBaseRs
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCTwrBaseRs');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','SLCTwrBaseRs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCTwrBaseRs'));
		add_line(subsystem_LN,'Ground_SLCTwrBaseRs/1', 'wttl_set_SLCTwrBaseRs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCEStopBaseBoxOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopBaseBoxOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','SLCEStopBaseBoxOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopBaseBoxOk'));
		add_line(subsystem_LN,'Ground_SLCEStopBaseBoxOk/1', 'wttl_set_SLCEStopBaseBoxOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/reserve
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_reserve');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','reserve');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_reserve'));
		add_line(subsystem_LN,'Ground_reserve/1', 'wttl_set_reserve/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCTwrBaseOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCTwrBaseOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','SLCTwrBaseOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCTwrBaseOk'));
		add_line(subsystem_LN,'Ground_SLCTwrBaseOk/1', 'wttl_set_SLCTwrBaseOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCEStopTopBoxOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopTopBoxOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','SLCEStopTopBoxOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopTopBoxOk'));
		add_line(subsystem_LN,'Ground_SLCEStopTopBoxOk/1', 'wttl_set_SLCEStopTopBoxOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCVbrOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCVbrOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','SLCVbrOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCVbrOk'));
		add_line(subsystem_LN,'Ground_SLCVbrOk/1', 'wttl_set_SLCVbrOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCStormPos
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCStormPos');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','SLCStormPos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCStormPos'));
		add_line(subsystem_LN,'Ground_SLCStormPos/1', 'wttl_set_SLCStormPos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BatProDeact
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BatProDeact');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','BatProDeact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BatProDeact'));
		add_line(subsystem_LN,'Ground_BatProDeact/1', 'wttl_set_BatProDeact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TopBoxOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxOk'));
		add_line(subsystem_LN,'Ground_TopBoxOk/1', 'wttl_set_TopBoxOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HydrOilPmpOff
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HydrOilPmpOff');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','HydrOilPmpOff');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HydrOilPmpOff'));
		add_line(subsystem_LN,'Ground_HydrOilPmpOff/1', 'wttl_set_HydrOilPmpOff/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxEStop
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxEStop');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TopBoxEStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxEStop'));
		add_line(subsystem_LN,'Ground_TopBoxEStop/1', 'wttl_set_TopBoxEStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxSwOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxSwOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TopBoxSwOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxSwOk'));
		add_line(subsystem_LN,'Ground_TopBoxSwOk/1', 'wttl_set_TopBoxSwOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxManStop
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxManStop');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','TopBoxManStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxManStop'));
		add_line(subsystem_LN,'Ground_TopBoxManStop/1', 'wttl_set_TopBoxManStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/FireAlmSysOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_FireAlmSysOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','FireAlmSysOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FireAlmSysOk'));
		add_line(subsystem_LN,'Ground_FireAlmSysOk/1', 'wttl_set_FireAlmSysOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/FireAlmSysServOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_FireAlmSysServOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','FireAlmSysServOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FireAlmSysServOk'));
		add_line(subsystem_LN,'Ground_FireAlmSysServOk/1', 'wttl_set_FireAlmSysServOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/NacSmkDetect2Ok
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_NacSmkDetect2Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','NacSmkDetect2Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacSmkDetect2Ok'));
		add_line(subsystem_LN,'Ground_NacSmkDetect2Ok/1', 'wttl_set_NacSmkDetect2Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/MutinGn
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_MutinGn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','MutinGn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MutinGn'));
		add_line(subsystem_LN,'Ground_MutinGn/1', 'wttl_set_MutinGn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPmpOvlOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPmpOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','CoolPmpOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPmpOvlOk'));
		add_line(subsystem_LN,'Ground_CoolPmpOvlOk/1', 'wttl_set_CoolPmpOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BattVoltageOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BattVoltageOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','BattVoltageOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BattVoltageOk'));
		add_line(subsystem_LN,'Ground_BattVoltageOk/1', 'wttl_set_BattVoltageOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HydrOilLvlOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HydrOilLvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','HydrOilLvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HydrOilLvlOk'));
		add_line(subsystem_LN,'Ground_HydrOilLvlOk/1', 'wttl_set_HydrOilLvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HydrPmpOvlOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HydrPmpOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','HydrPmpOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HydrPmpOvlOk'));
		add_line(subsystem_LN,'Ground_HydrPmpOvlOk/1', 'wttl_set_HydrPmpOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/OvlFuOk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_OvlFuOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','OvlFuOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_OvlFuOk'));
		add_line(subsystem_LN,'Ground_OvlFuOk/1', 'wttl_set_OvlFuOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrFanSp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrFanSp');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrFanSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrFanSp'));
		add_line(subsystem_LN,'Ground_TwrFanSp/1', 'wttl_set_TwrFanSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysGrp1FanSpdSp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysGrp1FanSpdSp');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysGrp1FanSpdSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysGrp1FanSpdSp'));
		add_line(subsystem_LN,'Ground_CoolSysGrp1FanSpdSp/1', 'wttl_set_CoolSysGrp1FanSpdSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysGrp2FanSpdSp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysGrp2FanSpdSp');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysGrp2FanSpdSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysGrp2FanSpdSp'));
		add_line(subsystem_LN,'Ground_CoolSysGrp2FanSpdSp/1', 'wttl_set_CoolSysGrp2FanSpdSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrExtrFanSpdSp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrExtrFanSpdSp');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrExtrFanSpdSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrExtrFanSpdSp'));
		add_line(subsystem_LN,'Ground_TwrExtrFanSpdSp/1', 'wttl_set_TwrExtrFanSpdSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysHeatFan1t4On
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysHeatFan1t4On');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysHeatFan1t4On');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysHeatFan1t4On'));
		add_line(subsystem_LN,'Ground_CoolSysHeatFan1t4On/1', 'wttl_set_CoolSysHeatFan1t4On/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysHeat1a2On
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysHeat1a2On');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysHeat1a2On');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysHeat1a2On'));
		add_line(subsystem_LN,'Ground_CoolSysHeat1a2On/1', 'wttl_set_CoolSysHeat1a2On/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFansOn
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFansOn');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysFansOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFansOn'));
		add_line(subsystem_LN,'Ground_CoolSysFansOn/1', 'wttl_set_CoolSysFansOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysPmpOn
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysPmpOn');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysPmpOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysPmpOn'));
		add_line(subsystem_LN,'Ground_CoolSysPmpOn/1', 'wttl_set_CoolSysPmpOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrExtrFanEn
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrExtrFanEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','TwrExtrFanEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrExtrFanEn'));
		add_line(subsystem_LN,'Ground_TwrExtrFanEn/1', 'wttl_set_TwrExtrFanEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UPSShutdown
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UPSShutdown');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','UPSShutdown');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UPSShutdown'));
		add_line(subsystem_LN,'Ground_UPSShutdown/1', 'wttl_set_UPSShutdown/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/WTGManStop
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_WTGManStop');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','WTGManStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WTGManStop'));
		add_line(subsystem_LN,'Ground_WTGManStop/1', 'wttl_set_WTGManStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrFanEn
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrFanEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','TwrFanEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrFanEn'));
		add_line(subsystem_LN,'Ground_TwrFanEn/1', 'wttl_set_TwrFanEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/GridProtAct
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_GridProtAct');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','GridProtAct');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GridProtAct'));
		add_line(subsystem_LN,'Ground_GridProtAct/1', 'wttl_set_GridProtAct/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCTwrBaseSysState
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCTwrBaseSysState');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','SLCTwrBaseSysState');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCTwrBaseSysState'));
		add_line(subsystem_LN,'Ground_SLCTwrBaseSysState/1', 'wttl_set_SLCTwrBaseSysState/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCHydrOilPmp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCHydrOilPmp');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','SLCHydrOilPmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCHydrOilPmp'));
		add_line(subsystem_LN,'Ground_SLCHydrOilPmp/1', 'wttl_set_SLCHydrOilPmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SigPls
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SigPls');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','SigPls');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SigPls'));
		add_line(subsystem_LN,'Ground_SigPls/1', 'wttl_set_SigPls/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BrkPadTmpTest
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BrkPadTmpTest');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','BrkPadTmpTest');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BrkPadTmpTest'));
		add_line(subsystem_LN,'Ground_BrkPadTmpTest/1', 'wttl_set_BrkPadTmpTest/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPmpEn
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPmpEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','CoolPmpEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPmpEn'));
		add_line(subsystem_LN,'Ground_CoolPmpEn/1', 'wttl_set_CoolPmpEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HeatBypVlv
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HeatBypVlv');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTUR','DO','HeatBypVlv');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HeatBypVlv'));
		add_line(subsystem_LN,'Ground_HeatBypVlv/1', 'wttl_set_HeatBypVlv/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BottomBoxTmp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BottomBoxTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','BottomBoxTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BottomBoxTmp'));
		add_line(subsystem_LN,'Ground_BottomBoxTmp/1', 'wttl_set_BottomBoxTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPres
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPres');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','CoolPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPres'));
		add_line(subsystem_LN,'Ground_CoolPres/1', 'wttl_set_CoolPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolTmp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','CoolTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolTmp'));
		add_line(subsystem_LN,'Ground_CoolTmp/1', 'wttl_set_CoolTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolInletPmpPres
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolInletPmpPres');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','CoolInletPmpPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolInletPmpPres'));
		add_line(subsystem_LN,'Ground_CoolInletPmpPres/1', 'wttl_set_CoolInletPmpPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxTmp
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','TopBoxTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxTmp'));
		add_line(subsystem_LN,'Ground_TopBoxTmp/1', 'wttl_set_TopBoxTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxCur
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxCur');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','TopBoxCur');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxCur'));
		add_line(subsystem_LN,'Ground_TopBoxCur/1', 'wttl_set_TopBoxCur/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HyPres
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HyPres');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','HyPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HyPres'));
		add_line(subsystem_LN,'Ground_HyPres/1', 'wttl_set_HyPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPmpOffFdbk
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPmpOffFdbk');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','CoolPmpOffFdbk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPmpOffFdbk'));
		add_line(subsystem_LN,'Ground_CoolPmpOffFdbk/1', 'wttl_set_CoolPmpOffFdbk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BottomBoxTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BottomBoxTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','BottomBoxTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BottomBoxTmpRaw'));
		add_line(subsystem_LN,'Ground_BottomBoxTmpRaw/1', 'wttl_set_BottomBoxTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPresRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPresRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','CoolPresRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPresRaw'));
		add_line(subsystem_LN,'Ground_CoolPresRaw/1', 'wttl_set_CoolPresRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','CoolTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolTmpRaw'));
		add_line(subsystem_LN,'Ground_CoolTmpRaw/1', 'wttl_set_CoolTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolInletPmpPresRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolInletPmpPresRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','CoolInletPmpPresRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolInletPmpPresRaw'));
		add_line(subsystem_LN,'Ground_CoolInletPmpPresRaw/1', 'wttl_set_CoolInletPmpPresRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','TopBoxTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxTmpRaw'));
		add_line(subsystem_LN,'Ground_TopBoxTmpRaw/1', 'wttl_set_TopBoxTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxCurRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxCurRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','TopBoxCurRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxCurRaw'));
		add_line(subsystem_LN,'Ground_TopBoxCurRaw/1', 'wttl_set_TopBoxCurRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HyPresRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HyPresRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','HyPresRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HyPresRaw'));
		add_line(subsystem_LN,'Ground_HyPresRaw/1', 'wttl_set_HyPresRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPmpOffFdbkRaw
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPmpOffFdbkRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','CoolPmpOffFdbkRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPmpOffFdbkRaw'));
		add_line(subsystem_LN,'Ground_CoolPmpOffFdbkRaw/1', 'wttl_set_CoolPmpOffFdbkRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BoilerPresLowFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BoilerPresLowFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','BoilerPresLowFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BoilerPresLowFrc'));
		add_line(subsystem_LN,'Ground_BoilerPresLowFrc/1', 'wttl_set_BoilerPresLowFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ExtDeactSoundMgtFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ExtDeactSoundMgtFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','ExtDeactSoundMgtFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ExtDeactSoundMgtFrc'));
		add_line(subsystem_LN,'Ground_ExtDeactSoundMgtFrc/1', 'wttl_set_ExtDeactSoundMgtFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BaseBoxEmgStopFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BaseBoxEmgStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','BaseBoxEmgStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BaseBoxEmgStopFrc'));
		add_line(subsystem_LN,'Ground_BaseBoxEmgStopFrc/1', 'wttl_set_BaseBoxEmgStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ShdSwOffFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ShdSwOffFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','ShdSwOffFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ShdSwOffFrc'));
		add_line(subsystem_LN,'Ground_ShdSwOffFrc/1', 'wttl_set_ShdSwOffFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/ShdSwModuleOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_ShdSwModuleOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','ShdSwModuleOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ShdSwModuleOkFrc'));
		add_line(subsystem_LN,'Ground_ShdSwModuleOkFrc/1', 'wttl_set_ShdSwModuleOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/WTGStopFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_WTGStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','WTGStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WTGStopFrc'));
		add_line(subsystem_LN,'Ground_WTGStopFrc/1', 'wttl_set_WTGStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SpareProtShtoffOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SpareProtShtoffOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SpareProtShtoffOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SpareProtShtoffOkFrc'));
		add_line(subsystem_LN,'Ground_SpareProtShtoffOkFrc/1', 'wttl_set_SpareProtShtoffOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseEmgStopFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseEmgStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrBaseEmgStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseEmgStopFrc'));
		add_line(subsystem_LN,'Ground_TwrBaseEmgStopFrc/1', 'wttl_set_TwrBaseEmgStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UpsOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UpsOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','UpsOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UpsOkFrc'));
		add_line(subsystem_LN,'Ground_UpsOkFrc/1', 'wttl_set_UpsOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseManStopFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseManStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrBaseManStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseManStopFrc'));
		add_line(subsystem_LN,'Ground_TwrBaseManStopFrc/1', 'wttl_set_TwrBaseManStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseBoxSwOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseBoxSwOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrBaseBoxSwOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseBoxSwOkFrc'));
		add_line(subsystem_LN,'Ground_TwrBaseBoxSwOkFrc/1', 'wttl_set_TwrBaseBoxSwOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrBaseBoxOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseBoxOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrBaseBoxOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseBoxOkFrc'));
		add_line(subsystem_LN,'Ground_TwrBaseBoxOkFrc/1', 'wttl_set_TwrBaseBoxOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrDistrCabinetOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrDistrCabinetOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrDistrCabinetOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrDistrCabinetOkFrc'));
		add_line(subsystem_LN,'Ground_TwrDistrCabinetOkFrc/1', 'wttl_set_TwrDistrCabinetOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrExtrFanEnFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrExtrFanEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrExtrFanEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrExtrFanEnFrc'));
		add_line(subsystem_LN,'Ground_TwrExtrFanEnFrc/1', 'wttl_set_TwrExtrFanEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UPSShutdownFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UPSShutdownFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','UPSShutdownFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UPSShutdownFrc'));
		add_line(subsystem_LN,'Ground_UPSShutdownFrc/1', 'wttl_set_UPSShutdownFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/WTGManStopFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_WTGManStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','WTGManStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WTGManStopFrc'));
		add_line(subsystem_LN,'Ground_WTGManStopFrc/1', 'wttl_set_WTGManStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TwrFanEnFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TwrFanEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TwrFanEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrFanEnFrc'));
		add_line(subsystem_LN,'Ground_TwrFanEnFrc/1', 'wttl_set_TwrFanEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/GridProtActFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_GridProtActFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','GridProtActFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GridProtActFrc'));
		add_line(subsystem_LN,'Ground_GridProtActFrc/1', 'wttl_set_GridProtActFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UPSFailureOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UPSFailureOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','UPSFailureOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UPSFailureOkFrc'));
		add_line(subsystem_LN,'Ground_UPSFailureOkFrc/1', 'wttl_set_UPSFailureOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/UPSBattWarnFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_UPSBattWarnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','UPSBattWarnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_UPSBattWarnFrc'));
		add_line(subsystem_LN,'Ground_UPSBattWarnFrc/1', 'wttl_set_UPSBattWarnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan1OkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan1OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan1OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan1OkFrc'));
		add_line(subsystem_LN,'Ground_CoolSysFan1OkFrc/1', 'wttl_set_CoolSysFan1OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan2OkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan2OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan2OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan2OkFrc'));
		add_line(subsystem_LN,'Ground_CoolSysFan2OkFrc/1', 'wttl_set_CoolSysFan2OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan3OkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan3OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan3OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan3OkFrc'));
		add_line(subsystem_LN,'Ground_CoolSysFan3OkFrc/1', 'wttl_set_CoolSysFan3OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFan4OkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFan4OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysFan4OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFan4OkFrc'));
		add_line(subsystem_LN,'Ground_CoolSysFan4OkFrc/1', 'wttl_set_CoolSysFan4OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysFansHeatOverlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysFansHeatOverlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysFansHeatOverlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysFansHeatOverlOkFrc'));
		add_line(subsystem_LN,'Ground_CoolSysFansHeatOverlOkFrc/1', 'wttl_set_CoolSysFansHeatOverlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysCoolHeater1a2OkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysCoolHeater1a2OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysCoolHeater1a2OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysCoolHeater1a2OkFrc'));
		add_line(subsystem_LN,'Ground_CoolSysCoolHeater1a2OkFrc/1', 'wttl_set_CoolSysCoolHeater1a2OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysPresSwFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysPresSwFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysPresSwFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysPresSwFrc'));
		add_line(subsystem_LN,'Ground_CoolSysPresSwFrc/1', 'wttl_set_CoolSysPresSwFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolSysPmpOverlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolSysPmpOverlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolSysPmpOverlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolSysPmpOverlOkFrc'));
		add_line(subsystem_LN,'Ground_CoolSysPmpOverlOkFrc/1', 'wttl_set_CoolSysPmpOverlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCTwrBaseRsFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCTwrBaseRsFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCTwrBaseRsFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCTwrBaseRsFrc'));
		add_line(subsystem_LN,'Ground_SLCTwrBaseRsFrc/1', 'wttl_set_SLCTwrBaseRsFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCEStopBaseBoxOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopBaseBoxOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCEStopBaseBoxOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopBaseBoxOkFrc'));
		add_line(subsystem_LN,'Ground_SLCEStopBaseBoxOkFrc/1', 'wttl_set_SLCEStopBaseBoxOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/reserveFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_reserveFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','reserveFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_reserveFrc'));
		add_line(subsystem_LN,'Ground_reserveFrc/1', 'wttl_set_reserveFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCTwrBaseOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCTwrBaseOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCTwrBaseOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCTwrBaseOkFrc'));
		add_line(subsystem_LN,'Ground_SLCTwrBaseOkFrc/1', 'wttl_set_SLCTwrBaseOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCTwrBaseSysStateFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCTwrBaseSysStateFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCTwrBaseSysStateFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCTwrBaseSysStateFrc'));
		add_line(subsystem_LN,'Ground_SLCTwrBaseSysStateFrc/1', 'wttl_set_SLCTwrBaseSysStateFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCEStopTopBoxOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopTopBoxOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCEStopTopBoxOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopTopBoxOkFrc'));
		add_line(subsystem_LN,'Ground_SLCEStopTopBoxOkFrc/1', 'wttl_set_SLCEStopTopBoxOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCVbrOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCVbrOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCVbrOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCVbrOkFrc'));
		add_line(subsystem_LN,'Ground_SLCVbrOkFrc/1', 'wttl_set_SLCVbrOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCStormPosFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCStormPosFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCStormPosFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCStormPosFrc'));
		add_line(subsystem_LN,'Ground_SLCStormPosFrc/1', 'wttl_set_SLCStormPosFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SLCHydrOilPmpFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SLCHydrOilPmpFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SLCHydrOilPmpFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCHydrOilPmpFrc'));
		add_line(subsystem_LN,'Ground_SLCHydrOilPmpFrc/1', 'wttl_set_SLCHydrOilPmpFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BatProDeactFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BatProDeactFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','BatProDeactFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BatProDeactFrc'));
		add_line(subsystem_LN,'Ground_BatProDeactFrc/1', 'wttl_set_BatProDeactFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TopBoxOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxOkFrc'));
		add_line(subsystem_LN,'Ground_TopBoxOkFrc/1', 'wttl_set_TopBoxOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HydrOilPmpOffFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HydrOilPmpOffFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','HydrOilPmpOffFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HydrOilPmpOffFrc'));
		add_line(subsystem_LN,'Ground_HydrOilPmpOffFrc/1', 'wttl_set_HydrOilPmpOffFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxEStopFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxEStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TopBoxEStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxEStopFrc'));
		add_line(subsystem_LN,'Ground_TopBoxEStopFrc/1', 'wttl_set_TopBoxEStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxSwOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxSwOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TopBoxSwOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxSwOkFrc'));
		add_line(subsystem_LN,'Ground_TopBoxSwOkFrc/1', 'wttl_set_TopBoxSwOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TopBoxManStopFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxManStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','TopBoxManStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxManStopFrc'));
		add_line(subsystem_LN,'Ground_TopBoxManStopFrc/1', 'wttl_set_TopBoxManStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/FireAlmSysOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_FireAlmSysOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','FireAlmSysOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FireAlmSysOkFrc'));
		add_line(subsystem_LN,'Ground_FireAlmSysOkFrc/1', 'wttl_set_FireAlmSysOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/FireAlmSysServOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_FireAlmSysServOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','FireAlmSysServOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_FireAlmSysServOkFrc'));
		add_line(subsystem_LN,'Ground_FireAlmSysServOkFrc/1', 'wttl_set_FireAlmSysServOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/NacSmkDetect2OkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_NacSmkDetect2OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','NacSmkDetect2OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacSmkDetect2OkFrc'));
		add_line(subsystem_LN,'Ground_NacSmkDetect2OkFrc/1', 'wttl_set_NacSmkDetect2OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/MutinGnFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_MutinGnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','MutinGnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MutinGnFrc'));
		add_line(subsystem_LN,'Ground_MutinGnFrc/1', 'wttl_set_MutinGnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPmpOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolPmpOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPmpOvlOkFrc'));
		add_line(subsystem_LN,'Ground_CoolPmpOvlOkFrc/1', 'wttl_set_CoolPmpOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BattVoltageOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BattVoltageOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','BattVoltageOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BattVoltageOkFrc'));
		add_line(subsystem_LN,'Ground_BattVoltageOkFrc/1', 'wttl_set_BattVoltageOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HydrOilLvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HydrOilLvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','HydrOilLvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HydrOilLvlOkFrc'));
		add_line(subsystem_LN,'Ground_HydrOilLvlOkFrc/1', 'wttl_set_HydrOilLvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HydrPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HydrPmpOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','HydrPmpOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HydrPmpOvlOkFrc'));
		add_line(subsystem_LN,'Ground_HydrPmpOvlOkFrc/1', 'wttl_set_HydrPmpOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/SigPlsFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_SigPlsFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','SigPlsFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SigPlsFrc'));
		add_line(subsystem_LN,'Ground_SigPlsFrc/1', 'wttl_set_SigPlsFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/BrkPadTmpTestFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_BrkPadTmpTestFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','BrkPadTmpTestFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BrkPadTmpTestFrc'));
		add_line(subsystem_LN,'Ground_BrkPadTmpTestFrc/1', 'wttl_set_BrkPadTmpTestFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/CoolPmpEnFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_CoolPmpEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','CoolPmpEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolPmpEnFrc'));
		add_line(subsystem_LN,'Ground_CoolPmpEnFrc/1', 'wttl_set_CoolPmpEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/HeatBypVlvFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_HeatBypVlvFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','HeatBypVlvFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HeatBypVlvFrc'));
		add_line(subsystem_LN,'Ground_HeatBypVlvFrc/1', 'wttl_set_HeatBypVlvFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/OvlFuOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_OvlFuOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','OvlFuOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_OvlFuOkFrc'));
		add_line(subsystem_LN,'Ground_OvlFuOkFrc/1', 'wttl_set_OvlFuOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_StrOptAct
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_StrOptAct');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_StrOptAct');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_StrOptAct'));
		add_line(subsystem_LN,'Ground_P_StrOptAct/1', 'wttl_set_P_StrOptAct/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_CoolTmpSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_CoolTmpSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_CoolTmpSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CoolTmpSensUpLim'));
		add_line(subsystem_LN,'Ground_P_CoolTmpSensUpLim/1', 'wttl_set_P_CoolTmpSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_CoolTmpSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_CoolTmpSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_CoolTmpSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CoolTmpSensLoLim'));
		add_line(subsystem_LN,'Ground_P_CoolTmpSensLoLim/1', 'wttl_set_P_CoolTmpSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_HyPresSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_HyPresSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_HyPresSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_HyPresSensUpLim'));
		add_line(subsystem_LN,'Ground_P_HyPresSensUpLim/1', 'wttl_set_P_HyPresSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_HyPresSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_HyPresSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_HyPresSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_HyPresSensLoLim'));
		add_line(subsystem_LN,'Ground_P_HyPresSensLoLim/1', 'wttl_set_P_HyPresSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_WNom
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_WNom');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_WNom');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_WNom'));
		add_line(subsystem_LN,'Ground_P_WNom/1', 'wttl_set_P_WNom/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_TurbDetrWdDirDevi
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_TurbDetrWdDirDevi');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrWdDirDevi');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TurbDetrWdDirDevi'));
		add_line(subsystem_LN,'Ground_P_TurbDetrWdDirDevi/1', 'wttl_set_P_TurbDetrWdDirDevi/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_TurbDetrWdSpd
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_TurbDetrWdSpd');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrWdSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TurbDetrWdSpd'));
		add_line(subsystem_LN,'Ground_P_TurbDetrWdSpd/1', 'wttl_set_P_TurbDetrWdSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_TurbDetrSetDl
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_TurbDetrSetDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrSetDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TurbDetrSetDl'));
		add_line(subsystem_LN,'Ground_P_TurbDetrSetDl/1', 'wttl_set_P_TurbDetrSetDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_TurbDetrRsDl
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_TurbDetrRsDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_TurbDetrRsDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TurbDetrRsDl'));
		add_line(subsystem_LN,'Ground_P_TurbDetrRsDl/1', 'wttl_set_P_TurbDetrRsDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_WdDirDeviLev1WdSpd
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_WdDirDeviLev1WdSpd');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev1WdSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_WdDirDeviLev1WdSpd'));
		add_line(subsystem_LN,'Ground_P_WdDirDeviLev1WdSpd/1', 'wttl_set_P_WdDirDeviLev1WdSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_WdDirDeviLev1WdDir
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_WdDirDeviLev1WdDir');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev1WdDir');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_WdDirDeviLev1WdDir'));
		add_line(subsystem_LN,'Ground_P_WdDirDeviLev1WdDir/1', 'wttl_set_P_WdDirDeviLev1WdDir/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_WdDirDeviLev2WdSpd
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_WdDirDeviLev2WdSpd');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev2WdSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_WdDirDeviLev2WdSpd'));
		add_line(subsystem_LN,'Ground_P_WdDirDeviLev2WdSpd/1', 'wttl_set_P_WdDirDeviLev2WdSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_WdDirDeviLev2WdDir
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_WdDirDeviLev2WdDir');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_WdDirDeviLev2WdDir');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_WdDirDeviLev2WdDir'));
		add_line(subsystem_LN,'Ground_P_WdDirDeviLev2WdDir/1', 'wttl_set_P_WdDirDeviLev2WdDir/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/P_PT100ErrDl
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_P_PT100ErrDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTUR','DO','P_PT100ErrDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_PT100ErrDl'));
		add_line(subsystem_LN,'Ground_P_PT100ErrDl/1', 'wttl_set_P_PT100ErrDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/NumActErr
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_NumActErr');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTUR','DO','NumActErr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NumActErr'));
		add_line(subsystem_LN,'Ground_NumActErr/1', 'wttl_set_NumActErr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/AccUsrPrio
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_AccUsrPrio');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WTUR','DO','AccUsrPrio');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AccUsrPrio'));
		add_line(subsystem_LN,'Ground_AccUsrPrio/1', 'wttl_set_AccUsrPrio/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/AccAtSt
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_AccAtSt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTUR','DO','AccAtSt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AccAtSt'));
		add_line(subsystem_LN,'Ground_AccAtSt/1', 'wttl_set_AccAtSt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WTUR/TurStrUpTime
		subsystem_LN = strcat(subsystem_out,'/WTUR');
		block        = strcat(subsystem_LN,'/wttl_set_TurStrUpTime');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTUR','DO','TurStrUpTime');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TurStrUpTime'));
		add_line(subsystem_LN,'Ground_TurStrUpTime/1', 'wttl_set_TurStrUpTime/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTUR')
	
	
		% WROT/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WROT','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
		% WROT/RotSpd
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','RotSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotSpd'));
		add_line(subsystem_LN,'Ground_RotSpd/1', 'wttl_set_RotSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotPos
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotPos');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','RotPos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotPos'));
		add_line(subsystem_LN,'Ground_RotPos/1', 'wttl_set_RotPos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/HubTmp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_HubTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','HubTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_HubTmp'));
		add_line(subsystem_LN,'Ground_HubTmp/1', 'wttl_set_HubTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAngSpBl1
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAngSpBl1');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAngSpBl1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAngSpBl1'));
		add_line(subsystem_LN,'Ground_PtAngSpBl1/1', 'wttl_set_PtAngSpBl1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAngSpBl2
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAngSpBl2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAngSpBl2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAngSpBl2'));
		add_line(subsystem_LN,'Ground_PtAngSpBl2/1', 'wttl_set_PtAngSpBl2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAngSpBl3
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAngSpBl3');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAngSpBl3');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAngSpBl3'));
		add_line(subsystem_LN,'Ground_PtAngSpBl3/1', 'wttl_set_PtAngSpBl3/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAngValBl1
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAngValBl1');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAngValBl1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAngValBl1'));
		add_line(subsystem_LN,'Ground_PtAngValBl1/1', 'wttl_set_PtAngValBl1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAngValBl2
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAngValBl2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAngValBl2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAngValBl2'));
		add_line(subsystem_LN,'Ground_PtAngValBl2/1', 'wttl_set_PtAngValBl2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAngValBl3
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAngValBl3');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAngValBl3');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAngValBl3'));
		add_line(subsystem_LN,'Ground_PtAngValBl3/1', 'wttl_set_PtAngValBl3/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPad1TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPad1TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotBrkPad1TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPad1TmpSensFlt'));
		add_line(subsystem_LN,'Ground_RotBrkPad1TmpSensFlt/1', 'wttl_set_RotBrkPad1TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPad2TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPad2TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotBrkPad2TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPad2TmpSensFlt'));
		add_line(subsystem_LN,'Ground_RotBrkPad2TmpSensFlt/1', 'wttl_set_RotBrkPad2TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAngAvg
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAngAvg');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAngAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAngAvg'));
		add_line(subsystem_LN,'Ground_PtAngAvg/1', 'wttl_set_PtAngAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAxPosAvg
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAxPosAvg');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAxPosAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAxPosAvg'));
		add_line(subsystem_LN,'Ground_EncAAxPosAvg/1', 'wttl_set_EncAAxPosAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAx1Pos
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAx1Pos');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAx1Pos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAx1Pos'));
		add_line(subsystem_LN,'Ground_EncAAx1Pos/1', 'wttl_set_EncAAx1Pos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAx2Pos
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAx2Pos');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAx2Pos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAx2Pos'));
		add_line(subsystem_LN,'Ground_EncAAx2Pos/1', 'wttl_set_EncAAx2Pos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAx3Pos
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAx3Pos');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAx3Pos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAx3Pos'));
		add_line(subsystem_LN,'Ground_EncAAx3Pos/1', 'wttl_set_EncAAx3Pos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAxPosAvg
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAxPosAvg');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAxPosAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAxPosAvg'));
		add_line(subsystem_LN,'Ground_EncBAxPosAvg/1', 'wttl_set_EncBAxPosAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAx1Pos
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAx1Pos');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAx1Pos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAx1Pos'));
		add_line(subsystem_LN,'Ground_EncBAx1Pos/1', 'wttl_set_EncBAx1Pos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAx2Pos
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAx2Pos');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAx2Pos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAx2Pos'));
		add_line(subsystem_LN,'Ground_EncBAx2Pos/1', 'wttl_set_EncBAx2Pos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAx3Pos
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAx3Pos');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAx3Pos');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAx3Pos'));
		add_line(subsystem_LN,'Ground_EncBAx3Pos/1', 'wttl_set_EncBAx3Pos/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngSpAvg
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngSpAvg');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngSpAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngSpAvg'));
		add_line(subsystem_LN,'Ground_BlAngSpAvg/1', 'wttl_set_BlAngSpAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngSpAx1
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngSpAx1');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngSpAx1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngSpAx1'));
		add_line(subsystem_LN,'Ground_BlAngSpAx1/1', 'wttl_set_BlAngSpAx1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngSpAx2
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngSpAx2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngSpAx2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngSpAx2'));
		add_line(subsystem_LN,'Ground_BlAngSpAx2/1', 'wttl_set_BlAngSpAx2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngSpAx3
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngSpAx3');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngSpAx3');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngSpAx3'));
		add_line(subsystem_LN,'Ground_BlAngSpAx3/1', 'wttl_set_BlAngSpAx3/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngSndSpAx1
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngSndSpAx1');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngSndSpAx1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngSndSpAx1'));
		add_line(subsystem_LN,'Ground_BlAngSndSpAx1/1', 'wttl_set_BlAngSndSpAx1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngSndSpAx2
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngSndSpAx2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngSndSpAx2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngSndSpAx2'));
		add_line(subsystem_LN,'Ground_BlAngSndSpAx2/1', 'wttl_set_BlAngSndSpAx2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngSndSpAx3
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngSndSpAx3');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngSndSpAx3');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngSndSpAx3'));
		add_line(subsystem_LN,'Ground_BlAngSndSpAx3/1', 'wttl_set_BlAngSndSpAx3/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngRteSp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngRteSp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngRteSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngRteSp'));
		add_line(subsystem_LN,'Ground_BlAngRteSp/1', 'wttl_set_BlAngRteSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtRte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtRte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtRte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtRte'));
		add_line(subsystem_LN,'Ground_PtRte/1', 'wttl_set_PtRte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAxRteAvg
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAxRteAvg');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAxRteAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAxRteAvg'));
		add_line(subsystem_LN,'Ground_EncAAxRteAvg/1', 'wttl_set_EncAAxRteAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAx1Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAx1Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAx1Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAx1Rte'));
		add_line(subsystem_LN,'Ground_EncAAx1Rte/1', 'wttl_set_EncAAx1Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAx2Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAx2Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAx2Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAx2Rte'));
		add_line(subsystem_LN,'Ground_EncAAx2Rte/1', 'wttl_set_EncAAx2Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncAAx3Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncAAx3Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncAAx3Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncAAx3Rte'));
		add_line(subsystem_LN,'Ground_EncAAx3Rte/1', 'wttl_set_EncAAx3Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAxRteAvg
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAxRteAvg');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAxRteAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAxRteAvg'));
		add_line(subsystem_LN,'Ground_EncBAxRteAvg/1', 'wttl_set_EncBAxRteAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAx1Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAx1Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAx1Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAx1Rte'));
		add_line(subsystem_LN,'Ground_EncBAx1Rte/1', 'wttl_set_EncBAx1Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAx2Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAx2Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAx2Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAx2Rte'));
		add_line(subsystem_LN,'Ground_EncBAx2Rte/1', 'wttl_set_EncBAx2Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/EncBAx3Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_EncBAx3Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','EncBAx3Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_EncBAx3Rte'));
		add_line(subsystem_LN,'Ground_EncBAx3Rte/1', 'wttl_set_EncBAx3Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAx1Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAx1Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAx1Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAx1Rte'));
		add_line(subsystem_LN,'Ground_PtAx1Rte/1', 'wttl_set_PtAx1Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAx2Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAx2Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAx2Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAx2Rte'));
		add_line(subsystem_LN,'Ground_PtAx2Rte/1', 'wttl_set_PtAx2Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAx3Rte
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAx3Rte');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAx3Rte');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAx3Rte'));
		add_line(subsystem_LN,'Ground_PtAx3Rte/1', 'wttl_set_PtAx3Rte/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngAx1
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngAx1');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngAx1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngAx1'));
		add_line(subsystem_LN,'Ground_BlAngAx1/1', 'wttl_set_BlAngAx1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngAx2
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngAx2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngAx2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngAx2'));
		add_line(subsystem_LN,'Ground_BlAngAx2/1', 'wttl_set_BlAngAx2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/BlAngAx3
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_BlAngAx3');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','BlAngAx3');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_BlAngAx3'));
		add_line(subsystem_LN,'Ground_BlAngAx3/1', 'wttl_set_BlAngAx3/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtMotAx1Cur
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtMotAx1Cur');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtMotAx1Cur');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtMotAx1Cur'));
		add_line(subsystem_LN,'Ground_PtMotAx1Cur/1', 'wttl_set_PtMotAx1Cur/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtMotAx2Cur
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtMotAx2Cur');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtMotAx2Cur');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtMotAx2Cur'));
		add_line(subsystem_LN,'Ground_PtMotAx2Cur/1', 'wttl_set_PtMotAx2Cur/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtMotAx3Cur
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtMotAx3Cur');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtMotAx3Cur');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtMotAx3Cur'));
		add_line(subsystem_LN,'Ground_PtMotAx3Cur/1', 'wttl_set_PtMotAx3Cur/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtMotAx1CurAbs
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtMotAx1CurAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtMotAx1CurAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtMotAx1CurAbs'));
		add_line(subsystem_LN,'Ground_PtMotAx1CurAbs/1', 'wttl_set_PtMotAx1CurAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtMotAx2CurAbs
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtMotAx2CurAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtMotAx2CurAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtMotAx2CurAbs'));
		add_line(subsystem_LN,'Ground_PtMotAx2CurAbs/1', 'wttl_set_PtMotAx2CurAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtMotAx3CurAbs
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtMotAx3CurAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtMotAx3CurAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtMotAx3CurAbs'));
		add_line(subsystem_LN,'Ground_PtMotAx3CurAbs/1', 'wttl_set_PtMotAx3CurAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAx1MotTmp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAx1MotTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAx1MotTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAx1MotTmp'));
		add_line(subsystem_LN,'Ground_PtAx1MotTmp/1', 'wttl_set_PtAx1MotTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAx2MotTmp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAx2MotTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAx2MotTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAx2MotTmp'));
		add_line(subsystem_LN,'Ground_PtAx2MotTmp/1', 'wttl_set_PtAx2MotTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/PtAx3MotTmp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_PtAx3MotTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','PtAx3MotTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_PtAx3MotTmp'));
		add_line(subsystem_LN,'Ground_PtAx3MotTmp/1', 'wttl_set_PtAx3MotTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotPls
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotPls');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','SLCRotPls');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotPls'));
		add_line(subsystem_LN,'Ground_SLCRotPls/1', 'wttl_set_SLCRotPls/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCManPthEn
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCManPthEn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','SLCManPthEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCManPthEn'));
		add_line(subsystem_LN,'Ground_SLCManPthEn/1', 'wttl_set_SLCManPthEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv0VFdbk
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv0VFdbk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','SLCBattDrv0VFdbk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv0VFdbk'));
		add_line(subsystem_LN,'Ground_SLCBattDrv0VFdbk/1', 'wttl_set_SLCBattDrv0VFdbk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv24VFdbk
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv24VFdbk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','SLCBattDrv24VFdbk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv24VFdbk'));
		add_line(subsystem_LN,'Ground_SLCBattDrv24VFdbk/1', 'wttl_set_SLCBattDrv24VFdbk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkNoRequest
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkNoRequest');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','SLCRotBrkNoRequest');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkNoRequest'));
		add_line(subsystem_LN,'Ground_SLCRotBrkNoRequest/1', 'wttl_set_SLCRotBrkNoRequest/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrvAct
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrvAct');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','SLCBattDrvAct');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrvAct'));
		add_line(subsystem_LN,'Ground_SLCBattDrvAct/1', 'wttl_set_SLCBattDrvAct/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLokLeftSide
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLokLeftSide');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotLokLeftSide');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLokLeftSide'));
		add_line(subsystem_LN,'Ground_RotLokLeftSide/1', 'wttl_set_RotLokLeftSide/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp2OvlOk
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp2OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotLuPmp2OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp2OvlOk'));
		add_line(subsystem_LN,'Ground_RotLuPmp2OvlOk/1', 'wttl_set_RotLuPmp2OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkCls
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkCls');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotBrkCls');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkCls'));
		add_line(subsystem_LN,'Ground_RotBrkCls/1', 'wttl_set_RotBrkCls/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmpOvlOk
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmpOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotLuPmpOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmpOvlOk'));
		add_line(subsystem_LN,'Ground_RotLuPmpOvlOk/1', 'wttl_set_RotLuPmpOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp1Ok
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp1Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotLuPmp1Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp1Ok'));
		add_line(subsystem_LN,'Ground_RotLuPmp1Ok/1', 'wttl_set_RotLuPmp1Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp2Ok
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp2Ok');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotLuPmp2Ok');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp2Ok'));
		add_line(subsystem_LN,'Ground_RotLuPmp2Ok/1', 'wttl_set_RotLuPmp2Ok/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotHubFanOvlOk
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotHubFanOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotHubFanOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotHubFanOvlOk'));
		add_line(subsystem_LN,'Ground_RotHubFanOvlOk/1', 'wttl_set_RotHubFanOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotHubFanOk
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotHubFanOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotHubFanOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotHubFanOk'));
		add_line(subsystem_LN,'Ground_RotHubFanOk/1', 'wttl_set_RotHubFanOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrgLuCycSw
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrgLuCycSw');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotBrgLuCycSw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrgLuCycSw'));
		add_line(subsystem_LN,'Ground_RotBrgLuCycSw/1', 'wttl_set_RotBrgLuCycSw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLokRightSide
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLokRightSide');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WROT','DO','RotLokRightSide');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLokRightSide'));
		add_line(subsystem_LN,'Ground_RotLokRightSide/1', 'wttl_set_RotLokRightSide/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCPthBackINact
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCPthBackINact');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','SLCPthBackINact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCPthBackINact'));
		add_line(subsystem_LN,'Ground_SLCPthBackINact/1', 'wttl_set_SLCPthBackINact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv0VInact
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv0VInact');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','SLCBattDrv0VInact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv0VInact'));
		add_line(subsystem_LN,'Ground_SLCBattDrv0VInact/1', 'wttl_set_SLCBattDrv0VInact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv24VInact
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv24VInact');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','SLCBattDrv24VInact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv24VInact'));
		add_line(subsystem_LN,'Ground_SLCBattDrv24VInact/1', 'wttl_set_SLCBattDrv24VInact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkCtlVlv
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkCtlVlv');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','SLCRotBrkCtlVlv');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkCtlVlv'));
		add_line(subsystem_LN,'Ground_SLCRotBrkCtlVlv/1', 'wttl_set_SLCRotBrkCtlVlv/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkDrainVlv
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkDrainVlv');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','SLCRotBrkDrainVlv');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkDrainVlv'));
		add_line(subsystem_LN,'Ground_SLCRotBrkDrainVlv/1', 'wttl_set_SLCRotBrkDrainVlv/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkBufVlv
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkBufVlv');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','SLCRotBrkBufVlv');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkBufVlv'));
		add_line(subsystem_LN,'Ground_SLCRotBrkBufVlv/1', 'wttl_set_SLCRotBrkBufVlv/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotHubFanEn
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotHubFanEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','RotHubFanEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotHubFanEn'));
		add_line(subsystem_LN,'Ground_RotHubFanEn/1', 'wttl_set_RotHubFanEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp1En
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp1En');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WROT','DO','RotLuPmp1En');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp1En'));
		add_line(subsystem_LN,'Ground_RotLuPmp1En/1', 'wttl_set_RotLuPmp1En/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPres
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPres');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','RotBrkPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPres'));
		add_line(subsystem_LN,'Ground_RotBrkPres/1', 'wttl_set_RotBrkPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkBufV
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkBufV');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','RotBrkBufV');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkBufV'));
		add_line(subsystem_LN,'Ground_RotBrkBufV/1', 'wttl_set_RotBrkBufV/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrgTmp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrgTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','RotBrgTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrgTmp'));
		add_line(subsystem_LN,'Ground_RotBrgTmp/1', 'wttl_set_RotBrgTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPad1Tmp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPad1Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','RotBrkPad1Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPad1Tmp'));
		add_line(subsystem_LN,'Ground_RotBrkPad1Tmp/1', 'wttl_set_RotBrkPad1Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPad2Tmp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPad2Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WROT','DO','RotBrkPad2Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPad2Tmp'));
		add_line(subsystem_LN,'Ground_RotBrkPad2Tmp/1', 'wttl_set_RotBrkPad2Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPresRaw
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPresRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WROT','DO','RotBrkPresRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPresRaw'));
		add_line(subsystem_LN,'Ground_RotBrkPresRaw/1', 'wttl_set_RotBrkPresRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkBufVRaw
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkBufVRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WROT','DO','RotBrkBufVRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkBufVRaw'));
		add_line(subsystem_LN,'Ground_RotBrkBufVRaw/1', 'wttl_set_RotBrkBufVRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrgTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrgTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WROT','DO','RotBrgTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrgTmpRaw'));
		add_line(subsystem_LN,'Ground_RotBrgTmpRaw/1', 'wttl_set_RotBrgTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPad1TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPad1TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WROT','DO','RotBrkPad1TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPad1TmpRaw'));
		add_line(subsystem_LN,'Ground_RotBrkPad1TmpRaw/1', 'wttl_set_RotBrkPad1TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkPad2TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkPad2TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WROT','DO','RotBrkPad2TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkPad2TmpRaw'));
		add_line(subsystem_LN,'Ground_RotBrkPad2TmpRaw/1', 'wttl_set_RotBrkPad2TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotHubFanSp
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotHubFanSp');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotHubFanSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotHubFanSp'));
		add_line(subsystem_LN,'Ground_RotHubFanSp/1', 'wttl_set_RotHubFanSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotPlsFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotPlsFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCRotPlsFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotPlsFrc'));
		add_line(subsystem_LN,'Ground_SLCRotPlsFrc/1', 'wttl_set_SLCRotPlsFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCManPthEnFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCManPthEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCManPthEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCManPthEnFrc'));
		add_line(subsystem_LN,'Ground_SLCManPthEnFrc/1', 'wttl_set_SLCManPthEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv0VFdbkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv0VFdbkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv0VFdbkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv0VFdbkFrc'));
		add_line(subsystem_LN,'Ground_SLCBattDrv0VFdbkFrc/1', 'wttl_set_SLCBattDrv0VFdbkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv24VFdbkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv24VFdbkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv24VFdbkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv24VFdbkFrc'));
		add_line(subsystem_LN,'Ground_SLCBattDrv24VFdbkFrc/1', 'wttl_set_SLCBattDrv24VFdbkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkNoRequestFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkNoRequestFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkNoRequestFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkNoRequestFrc'));
		add_line(subsystem_LN,'Ground_SLCRotBrkNoRequestFrc/1', 'wttl_set_SLCRotBrkNoRequestFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrvActFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrvActFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCBattDrvActFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrvActFrc'));
		add_line(subsystem_LN,'Ground_SLCBattDrvActFrc/1', 'wttl_set_SLCBattDrvActFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCPthBackINactFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCPthBackINactFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCPthBackINactFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCPthBackINactFrc'));
		add_line(subsystem_LN,'Ground_SLCPthBackINactFrc/1', 'wttl_set_SLCPthBackINactFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv0VInactFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv0VInactFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv0VInactFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv0VInactFrc'));
		add_line(subsystem_LN,'Ground_SLCBattDrv0VInactFrc/1', 'wttl_set_SLCBattDrv0VInactFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCBattDrv24VInactFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCBattDrv24VInactFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCBattDrv24VInactFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCBattDrv24VInactFrc'));
		add_line(subsystem_LN,'Ground_SLCBattDrv24VInactFrc/1', 'wttl_set_SLCBattDrv24VInactFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkCtlVlvFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkCtlVlvFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkCtlVlvFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkCtlVlvFrc'));
		add_line(subsystem_LN,'Ground_SLCRotBrkCtlVlvFrc/1', 'wttl_set_SLCRotBrkCtlVlvFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkDrainVlvFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkDrainVlvFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkDrainVlvFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkDrainVlvFrc'));
		add_line(subsystem_LN,'Ground_SLCRotBrkDrainVlvFrc/1', 'wttl_set_SLCRotBrkDrainVlvFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/SLCRotBrkBufVlvFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_SLCRotBrkBufVlvFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','SLCRotBrkBufVlvFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCRotBrkBufVlvFrc'));
		add_line(subsystem_LN,'Ground_SLCRotBrkBufVlvFrc/1', 'wttl_set_SLCRotBrkBufVlvFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLokLeftSideFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLokLeftSideFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotLokLeftSideFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLokLeftSideFrc'));
		add_line(subsystem_LN,'Ground_RotLokLeftSideFrc/1', 'wttl_set_RotLokLeftSideFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp2OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp2OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotLuPmp2OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp2OvlOkFrc'));
		add_line(subsystem_LN,'Ground_RotLuPmp2OvlOkFrc/1', 'wttl_set_RotLuPmp2OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrkClsFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrkClsFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotBrkClsFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrkClsFrc'));
		add_line(subsystem_LN,'Ground_RotBrkClsFrc/1', 'wttl_set_RotBrkClsFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmpOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotLuPmpOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmpOvlOkFrc'));
		add_line(subsystem_LN,'Ground_RotLuPmpOvlOkFrc/1', 'wttl_set_RotLuPmpOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp1OkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp1OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotLuPmp1OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp1OkFrc'));
		add_line(subsystem_LN,'Ground_RotLuPmp1OkFrc/1', 'wttl_set_RotLuPmp1OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp2OkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp2OkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotLuPmp2OkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp2OkFrc'));
		add_line(subsystem_LN,'Ground_RotLuPmp2OkFrc/1', 'wttl_set_RotLuPmp2OkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotHubFanEnFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotHubFanEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotHubFanEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotHubFanEnFrc'));
		add_line(subsystem_LN,'Ground_RotHubFanEnFrc/1', 'wttl_set_RotHubFanEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotHubFanOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotHubFanOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotHubFanOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotHubFanOvlOkFrc'));
		add_line(subsystem_LN,'Ground_RotHubFanOvlOkFrc/1', 'wttl_set_RotHubFanOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotHubFanOkFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotHubFanOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotHubFanOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotHubFanOkFrc'));
		add_line(subsystem_LN,'Ground_RotHubFanOkFrc/1', 'wttl_set_RotHubFanOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotBrgLuCycSwFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotBrgLuCycSwFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotBrgLuCycSwFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotBrgLuCycSwFrc'));
		add_line(subsystem_LN,'Ground_RotBrgLuCycSwFrc/1', 'wttl_set_RotBrgLuCycSwFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLuPmp1EnFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLuPmp1EnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotLuPmp1EnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLuPmp1EnFrc'));
		add_line(subsystem_LN,'Ground_RotLuPmp1EnFrc/1', 'wttl_set_RotLuPmp1EnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/RotLokRightSideFrc
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_RotLokRightSideFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','RotLokRightSideFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_RotLokRightSideFrc'));
		add_line(subsystem_LN,'Ground_RotLokRightSideFrc/1', 'wttl_set_RotLokRightSideFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/P_RotBrgTmpSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_P_RotBrgTmpSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','P_RotBrgTmpSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_RotBrgTmpSensUpLim'));
		add_line(subsystem_LN,'Ground_P_RotBrgTmpSensUpLim/1', 'wttl_set_P_RotBrgTmpSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/P_RotBrgTmpSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_P_RotBrgTmpSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','P_RotBrgTmpSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_RotBrgTmpSensLoLim'));
		add_line(subsystem_LN,'Ground_P_RotBrgTmpSensLoLim/1', 'wttl_set_P_RotBrgTmpSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/P_RotBrkPresSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_P_RotBrkPresSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','P_RotBrkPresSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_RotBrkPresSensUpLim'));
		add_line(subsystem_LN,'Ground_P_RotBrkPresSensUpLim/1', 'wttl_set_P_RotBrkPresSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WROT/P_RotBrkPresSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WROT');
		block        = strcat(subsystem_LN,'/wttl_set_P_RotBrkPresSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WROT','DO','P_RotBrkPresSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_RotBrkPresSensLoLim'));
		add_line(subsystem_LN,'Ground_P_RotBrkPresSensLoLim/1', 'wttl_set_P_RotBrkPresSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WROT')
	
	
		% WTRM/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WTRM','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
		% WTRM/GbxSpd
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxSpd'));
		add_line(subsystem_LN,'Ground_GbxSpd/1', 'wttl_set_GbxSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxSpdNoFilt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxSpdNoFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxSpdNoFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxSpdNoFilt'));
		add_line(subsystem_LN,'Ground_GbxSpdNoFilt/1', 'wttl_set_GbxSpdNoFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxCoolTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxCoolTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxCoolTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxCoolTmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxCoolTmpSensFlt/1', 'wttl_set_GbxCoolTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilInletTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilInletTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilInletTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilInletTmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxOilInletTmpSensFlt/1', 'wttl_set_GbxOilInletTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg1TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg1TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxBrg1TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg1TmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxBrg1TmpSensFlt/1', 'wttl_set_GbxBrg1TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg2TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg2TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxBrg2TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg2TmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxBrg2TmpSensFlt/1', 'wttl_set_GbxBrg2TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg3TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg3TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxBrg3TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg3TmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxBrg3TmpSensFlt/1', 'wttl_set_GbxBrg3TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg4TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg4TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxBrg4TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg4TmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxBrg4TmpSensFlt/1', 'wttl_set_GbxBrg4TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilHtTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilHtTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilHtTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilHtTmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxOilHtTmpSensFlt/1', 'wttl_set_GbxOilHtTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilSumpTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilSumpTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilSumpTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilSumpTmpSensFlt'));
		add_line(subsystem_LN,'Ground_GbxOilSumpTmpSensFlt/1', 'wttl_set_GbxOilSumpTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/DrvTrnAccZPk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_DrvTrnAccZPk');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','DrvTrnAccZPk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_DrvTrnAccZPk'));
		add_line(subsystem_LN,'Ground_DrvTrnAccZPk/1', 'wttl_set_DrvTrnAccZPk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxAcclAvg
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxAcclAvg');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxAcclAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxAcclAvg'));
		add_line(subsystem_LN,'Ground_GbxAcclAvg/1', 'wttl_set_GbxAcclAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxSpdCnt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxSpdCnt');
		
		add_block(lib_wttl_set,block,'CDC','CTE','LN','WTRM','DO','GbxSpdCnt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxSpdCnt'));
		add_line(subsystem_LN,'Ground_GbxSpdCnt/1', 'wttl_set_GbxSpdCnt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilInletTmp
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilInletTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxOilInletTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilInletTmp'));
		add_line(subsystem_LN,'Ground_GbxOilInletTmp/1', 'wttl_set_GbxOilInletTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg1Tmp
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg1Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxBrg1Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg1Tmp'));
		add_line(subsystem_LN,'Ground_GbxBrg1Tmp/1', 'wttl_set_GbxBrg1Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg2Tmp
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg2Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxBrg2Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg2Tmp'));
		add_line(subsystem_LN,'Ground_GbxBrg2Tmp/1', 'wttl_set_GbxBrg2Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg3Tmp
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg3Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxBrg3Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg3Tmp'));
		add_line(subsystem_LN,'Ground_GbxBrg3Tmp/1', 'wttl_set_GbxBrg3Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg4Tmp
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg4Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxBrg4Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg4Tmp'));
		add_line(subsystem_LN,'Ground_GbxBrg4Tmp/1', 'wttl_set_GbxBrg4Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilInletPres
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilInletPres');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxOilInletPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilInletPres'));
		add_line(subsystem_LN,'Ground_GbxOilInletPres/1', 'wttl_set_GbxOilInletPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilFtrDiffPres
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilFtrDiffPres');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxOilFtrDiffPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilFtrDiffPres'));
		add_line(subsystem_LN,'Ground_GbxOilFtrDiffPres/1', 'wttl_set_GbxOilFtrDiffPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilSumpTmp
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilSumpTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxOilSumpTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilSumpTmp'));
		add_line(subsystem_LN,'Ground_GbxOilSumpTmp/1', 'wttl_set_GbxOilSumpTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilPmpPres
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilPmpPres');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxOilPmpPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilPmpPres'));
		add_line(subsystem_LN,'Ground_GbxOilPmpPres/1', 'wttl_set_GbxOilPmpPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilHtTmp
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilHtTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','GbxOilHtTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilHtTmp'));
		add_line(subsystem_LN,'Ground_GbxOilHtTmp/1', 'wttl_set_GbxOilHtTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/DrvTrNaccZ
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_DrvTrNaccZ');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRM','DO','DrvTrNaccZ');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_DrvTrNaccZ'));
		add_line(subsystem_LN,'Ground_DrvTrNaccZ/1', 'wttl_set_DrvTrNaccZ/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxSpdCntRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxSpdCntRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxSpdCntRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxSpdCntRaw'));
		add_line(subsystem_LN,'Ground_GbxSpdCntRaw/1', 'wttl_set_GbxSpdCntRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilInletTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilInletTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxOilInletTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilInletTmpRaw'));
		add_line(subsystem_LN,'Ground_GbxOilInletTmpRaw/1', 'wttl_set_GbxOilInletTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg1TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg1TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxBrg1TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg1TmpRaw'));
		add_line(subsystem_LN,'Ground_GbxBrg1TmpRaw/1', 'wttl_set_GbxBrg1TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg2TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg2TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxBrg2TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg2TmpRaw'));
		add_line(subsystem_LN,'Ground_GbxBrg2TmpRaw/1', 'wttl_set_GbxBrg2TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg3TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg3TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxBrg3TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg3TmpRaw'));
		add_line(subsystem_LN,'Ground_GbxBrg3TmpRaw/1', 'wttl_set_GbxBrg3TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxBrg4TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxBrg4TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxBrg4TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxBrg4TmpRaw'));
		add_line(subsystem_LN,'Ground_GbxBrg4TmpRaw/1', 'wttl_set_GbxBrg4TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilInletPresRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilInletPresRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxOilInletPresRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilInletPresRaw'));
		add_line(subsystem_LN,'Ground_GbxOilInletPresRaw/1', 'wttl_set_GbxOilInletPresRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilFtrDiffPresRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilFtrDiffPresRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxOilFtrDiffPresRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilFtrDiffPresRaw'));
		add_line(subsystem_LN,'Ground_GbxOilFtrDiffPresRaw/1', 'wttl_set_GbxOilFtrDiffPresRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilSumpTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilSumpTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxOilSumpTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilSumpTmpRaw'));
		add_line(subsystem_LN,'Ground_GbxOilSumpTmpRaw/1', 'wttl_set_GbxOilSumpTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilPmpPresRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilPmpPresRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxOilPmpPresRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilPmpPresRaw'));
		add_line(subsystem_LN,'Ground_GbxOilPmpPresRaw/1', 'wttl_set_GbxOilPmpPresRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilHtTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilHtTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','GbxOilHtTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilHtTmpRaw'));
		add_line(subsystem_LN,'Ground_GbxOilHtTmpRaw/1', 'wttl_set_GbxOilHtTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/DrvTrnAccZRaw
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_DrvTrnAccZRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRM','DO','DrvTrnAccZRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_DrvTrnAccZRaw'));
		add_line(subsystem_LN,'Ground_DrvTrnAccZRaw/1', 'wttl_set_DrvTrnAccZRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxCool1En
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxCool1En');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTRM','DO','GbxCool1En');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxCool1En'));
		add_line(subsystem_LN,'Ground_GbxCool1En/1', 'wttl_set_GbxCool1En/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilPmpEn
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilPmpEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTRM','DO','GbxOilPmpEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilPmpEn'));
		add_line(subsystem_LN,'Ground_GbxOilPmpEn/1', 'wttl_set_GbxOilPmpEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilHtEn
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilHtEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTRM','DO','GbxOilHtEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilHtEn'));
		add_line(subsystem_LN,'Ground_GbxOilHtEn/1', 'wttl_set_GbxOilHtEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilLvlOk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilLvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilLvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilLvlOk'));
		add_line(subsystem_LN,'Ground_GbxOilLvlOk/1', 'wttl_set_GbxOilLvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxPartCnt
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxPartCnt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxPartCnt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxPartCnt'));
		add_line(subsystem_LN,'Ground_GbxPartCnt/1', 'wttl_set_GbxPartCnt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxPartCntOk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxPartCntOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxPartCntOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxPartCntOk'));
		add_line(subsystem_LN,'Ground_GbxPartCntOk/1', 'wttl_set_GbxPartCntOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilCool1OvlOk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilCool1OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilCool1OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilCool1OvlOk'));
		add_line(subsystem_LN,'Ground_GbxOilCool1OvlOk/1', 'wttl_set_GbxOilCool1OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilCool2OvlOk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilCool2OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilCool2OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilCool2OvlOk'));
		add_line(subsystem_LN,'Ground_GbxOilCool2OvlOk/1', 'wttl_set_GbxOilCool2OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilPmpOvlOk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilPmpOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilPmpOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilPmpOvlOk'));
		add_line(subsystem_LN,'Ground_GbxOilPmpOvlOk/1', 'wttl_set_GbxOilPmpOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxHtOvlOk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxHtOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxHtOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxHtOvlOk'));
		add_line(subsystem_LN,'Ground_GbxHtOvlOk/1', 'wttl_set_GbxHtOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilCoolOk
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilCoolOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRM','DO','GbxOilCoolOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilCoolOk'));
		add_line(subsystem_LN,'Ground_GbxOilCoolOk/1', 'wttl_set_GbxOilCoolOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxCool1EnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxCool1EnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxCool1EnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxCool1EnFrc'));
		add_line(subsystem_LN,'Ground_GbxCool1EnFrc/1', 'wttl_set_GbxCool1EnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilPmpEnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilPmpEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxOilPmpEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilPmpEnFrc'));
		add_line(subsystem_LN,'Ground_GbxOilPmpEnFrc/1', 'wttl_set_GbxOilPmpEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilHtEnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilHtEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxOilHtEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilHtEnFrc'));
		add_line(subsystem_LN,'Ground_GbxOilHtEnFrc/1', 'wttl_set_GbxOilHtEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilLvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilLvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxOilLvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilLvlOkFrc'));
		add_line(subsystem_LN,'Ground_GbxOilLvlOkFrc/1', 'wttl_set_GbxOilLvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxPartCntFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxPartCntFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxPartCntFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxPartCntFrc'));
		add_line(subsystem_LN,'Ground_GbxPartCntFrc/1', 'wttl_set_GbxPartCntFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxPartCntOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxPartCntOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxPartCntOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxPartCntOkFrc'));
		add_line(subsystem_LN,'Ground_GbxPartCntOkFrc/1', 'wttl_set_GbxPartCntOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilCool1OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilCool1OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxOilCool1OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilCool1OvlOkFrc'));
		add_line(subsystem_LN,'Ground_GbxOilCool1OvlOkFrc/1', 'wttl_set_GbxOilCool1OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilCool2OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilCool2OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxOilCool2OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilCool2OvlOkFrc'));
		add_line(subsystem_LN,'Ground_GbxOilCool2OvlOkFrc/1', 'wttl_set_GbxOilCool2OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilPmpOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxOilPmpOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilPmpOvlOkFrc'));
		add_line(subsystem_LN,'Ground_GbxOilPmpOvlOkFrc/1', 'wttl_set_GbxOilPmpOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxHtOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxHtOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxHtOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxHtOvlOkFrc'));
		add_line(subsystem_LN,'Ground_GbxHtOvlOkFrc/1', 'wttl_set_GbxHtOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/GbxOilCoolOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_GbxOilCoolOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','GbxOilCoolOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GbxOilCoolOkFrc'));
		add_line(subsystem_LN,'Ground_GbxOilCoolOkFrc/1', 'wttl_set_GbxOilCoolOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxOilFtrDiffPresSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxOilFtrDiffPresSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilFtrDiffPresSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxOilFtrDiffPresSensUpLim'));
		add_line(subsystem_LN,'Ground_P_GbxOilFtrDiffPresSensUpLim/1', 'wttl_set_P_GbxOilFtrDiffPresSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxOilFtrDiffPresSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxOilFtrDiffPresSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilFtrDiffPresSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxOilFtrDiffPresSensLoLim'));
		add_line(subsystem_LN,'Ground_P_GbxOilFtrDiffPresSensLoLim/1', 'wttl_set_P_GbxOilFtrDiffPresSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxOilInletPresSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxOilInletPresSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilInletPresSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxOilInletPresSensUpLim'));
		add_line(subsystem_LN,'Ground_P_GbxOilInletPresSensUpLim/1', 'wttl_set_P_GbxOilInletPresSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxOilInletPresSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxOilInletPresSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilInletPresSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxOilInletPresSensLoLim'));
		add_line(subsystem_LN,'Ground_P_GbxOilInletPresSensLoLim/1', 'wttl_set_P_GbxOilInletPresSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxOilPmpPresSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxOilPmpPresSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilPmpPresSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxOilPmpPresSensUpLim'));
		add_line(subsystem_LN,'Ground_P_GbxOilPmpPresSensUpLim/1', 'wttl_set_P_GbxOilPmpPresSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxOilPmpPresSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxOilPmpPresSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxOilPmpPresSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxOilPmpPresSensLoLim'));
		add_line(subsystem_LN,'Ground_P_GbxOilPmpPresSensLoLim/1', 'wttl_set_P_GbxOilPmpPresSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_DrvTrnEigFrq
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_DrvTrnEigFrq');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_DrvTrnEigFrq');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_DrvTrnEigFrq'));
		add_line(subsystem_LN,'Ground_P_DrvTrnEigFrq/1', 'wttl_set_P_DrvTrnEigFrq/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_DrvTrnAccZSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_DrvTrnAccZSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_DrvTrnAccZSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_DrvTrnAccZSensUpLim'));
		add_line(subsystem_LN,'Ground_P_DrvTrnAccZSensUpLim/1', 'wttl_set_P_DrvTrnAccZSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_DrvTrnAccZSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_DrvTrnAccZSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_DrvTrnAccZSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_DrvTrnAccZSensLoLim'));
		add_line(subsystem_LN,'Ground_P_DrvTrnAccZSensLoLim/1', 'wttl_set_P_DrvTrnAccZSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxRat
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxRat');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxRat');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxRat'));
		add_line(subsystem_LN,'Ground_P_GbxRat/1', 'wttl_set_P_GbxRat/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxNomSpd
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxNomSpd');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxNomSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxNomSpd'));
		add_line(subsystem_LN,'Ground_P_GbxNomSpd/1', 'wttl_set_P_GbxNomSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WTRM/P_GbxAcclAvgTm
		subsystem_LN = strcat(subsystem_out,'/WTRM');
		block        = strcat(subsystem_LN,'/wttl_set_P_GbxAcclAvgTm');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRM','DO','P_GbxAcclAvgTm');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GbxAcclAvgTm'));
		add_line(subsystem_LN,'Ground_P_GbxAcclAvgTm/1', 'wttl_set_P_GbxAcclAvgTm/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRM')
	
	
		% WGEN/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WGEN','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
		% WGEN/Spd
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_Spd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','Spd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Spd'));
		add_line(subsystem_LN,'Ground_Spd/1', 'wttl_set_Spd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GenSpd
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GenSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','GenSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GenSpd'));
		add_line(subsystem_LN,'Ground_GenSpd/1', 'wttl_set_GenSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GenSpdSensFlt
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GenSpdSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GenSpdSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GenSpdSensFlt'));
		add_line(subsystem_LN,'Ground_GenSpdSensFlt/1', 'wttl_set_GenSpdSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GenCoolTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GenCoolTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GenCoolTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GenCoolTmpSensFlt'));
		add_line(subsystem_LN,'Ground_GenCoolTmpSensFlt/1', 'wttl_set_GenCoolTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GenStatWdgTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GenStatWdgTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GenStatWdgTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GenStatWdgTmpSensFlt'));
		add_line(subsystem_LN,'Ground_GenStatWdgTmpSensFlt/1', 'wttl_set_GenStatWdgTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GenBrg1TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GenBrg1TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GenBrg1TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GenBrg1TmpSensFlt'));
		add_line(subsystem_LN,'Ground_GenBrg1TmpSensFlt/1', 'wttl_set_GenBrg1TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GenBrg2TmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GenBrg2TmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GenBrg2TmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GenBrg2TmpSensFlt'));
		add_line(subsystem_LN,'Ground_GenBrg2TmpSensFlt/1', 'wttl_set_GenBrg2TmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GenStatWdgCutOffTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GenStatWdgCutOffTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GenStatWdgCutOffTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GenStatWdgCutOffTmpSensFlt'));
		add_line(subsystem_LN,'Ground_GenStatWdgCutOffTmpSensFlt/1', 'wttl_set_GenStatWdgCutOffTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/SLCGnThermistorOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_SLCGnThermistorOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','SLCGnThermistorOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCGnThermistorOk'));
		add_line(subsystem_LN,'Ground_SLCGnThermistorOk/1', 'wttl_set_SLCGnThermistorOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnBrushesOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnBrushesOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnBrushesOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnBrushesOk'));
		add_line(subsystem_LN,'Ground_GnBrushesOk/1', 'wttl_set_GnBrushesOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLghtnProtOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLghtnProtOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnLghtnProtOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLghtnProtOk'));
		add_line(subsystem_LN,'Ground_GnLghtnProtOk/1', 'wttl_set_GnLghtnProtOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuPmpOvlOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuPmpOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnLuPmpOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuPmpOvlOk'));
		add_line(subsystem_LN,'Ground_GnLuPmpOvlOk/1', 'wttl_set_GnLuPmpOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuPmpOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuPmpOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnLuPmpOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuPmpOk'));
		add_line(subsystem_LN,'Ground_GnLuPmpOk/1', 'wttl_set_GnLuPmpOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan1OvlOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan1OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnFan1OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan1OvlOk'));
		add_line(subsystem_LN,'Ground_GnFan1OvlOk/1', 'wttl_set_GnFan1OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan2OvlOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan2OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnFan2OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan2OvlOk'));
		add_line(subsystem_LN,'Ground_GnFan2OvlOk/1', 'wttl_set_GnFan2OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan3OvlOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan3OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnFan3OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan3OvlOk'));
		add_line(subsystem_LN,'Ground_GnFan3OvlOk/1', 'wttl_set_GnFan3OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnHtOvlOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnHtOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnHtOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnHtOvlOk'));
		add_line(subsystem_LN,'Ground_GnHtOvlOk/1', 'wttl_set_GnHtOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnSpdEncOk
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnSpdEncOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnSpdEncOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnSpdEncOk'));
		add_line(subsystem_LN,'Ground_GnSpdEncOk/1', 'wttl_set_GnSpdEncOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnBrg1Tmp
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnBrg1Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','GnBrg1Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnBrg1Tmp'));
		add_line(subsystem_LN,'Ground_GnBrg1Tmp/1', 'wttl_set_GnBrg1Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnBrg2Tmp
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnBrg2Tmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','GnBrg2Tmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnBrg2Tmp'));
		add_line(subsystem_LN,'Ground_GnBrg2Tmp/1', 'wttl_set_GnBrg2Tmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnStatWdgCutOffTmp
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnStatWdgCutOffTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','GnStatWdgCutOffTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnStatWdgCutOffTmp'));
		add_line(subsystem_LN,'Ground_GnStatWdgCutOffTmp/1', 'wttl_set_GnStatWdgCutOffTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnSpdPls
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnSpdPls');
		
		add_block(lib_wttl_set,block,'CDC','CTE','LN','WGEN','DO','GnSpdPls');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnSpdPls'));
		add_line(subsystem_LN,'Ground_GnSpdPls/1', 'wttl_set_GnSpdPls/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnSlpRingTmp
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnSlpRingTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','GnSlpRingTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnSlpRingTmp'));
		add_line(subsystem_LN,'Ground_GnSlpRingTmp/1', 'wttl_set_GnSlpRingTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnStatWdgTmp
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnStatWdgTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','GnStatWdgTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnStatWdgTmp'));
		add_line(subsystem_LN,'Ground_GnStatWdgTmp/1', 'wttl_set_GnStatWdgTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuCycSw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuCycSw');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WGEN','DO','GnLuCycSw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuCycSw'));
		add_line(subsystem_LN,'Ground_GnLuCycSw/1', 'wttl_set_GnLuCycSw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnBrg1TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnBrg1TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WGEN','DO','GnBrg1TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnBrg1TmpRaw'));
		add_line(subsystem_LN,'Ground_GnBrg1TmpRaw/1', 'wttl_set_GnBrg1TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnBrg2TmpRaw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnBrg2TmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WGEN','DO','GnBrg2TmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnBrg2TmpRaw'));
		add_line(subsystem_LN,'Ground_GnBrg2TmpRaw/1', 'wttl_set_GnBrg2TmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnStatWdgCutOffTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnStatWdgCutOffTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WGEN','DO','GnStatWdgCutOffTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnStatWdgCutOffTmpRaw'));
		add_line(subsystem_LN,'Ground_GnStatWdgCutOffTmpRaw/1', 'wttl_set_GnStatWdgCutOffTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnSpdPlsRaw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnSpdPlsRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WGEN','DO','GnSpdPlsRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnSpdPlsRaw'));
		add_line(subsystem_LN,'Ground_GnSpdPlsRaw/1', 'wttl_set_GnSpdPlsRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnSlpRingTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnSlpRingTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WGEN','DO','GnSlpRingTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnSlpRingTmpRaw'));
		add_line(subsystem_LN,'Ground_GnSlpRingTmpRaw/1', 'wttl_set_GnSlpRingTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnStatWdgTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnStatWdgTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WGEN','DO','GnStatWdgTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnStatWdgTmpRaw'));
		add_line(subsystem_LN,'Ground_GnStatWdgTmpRaw/1', 'wttl_set_GnStatWdgTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuCycSwRaw
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuCycSwRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WGEN','DO','GnLuCycSwRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuCycSwRaw'));
		add_line(subsystem_LN,'Ground_GnLuCycSwRaw/1', 'wttl_set_GnLuCycSwRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan1On
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan1On');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnFan1On');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan1On'));
		add_line(subsystem_LN,'Ground_GnFan1On/1', 'wttl_set_GnFan1On/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan2On
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan2On');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnFan2On');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan2On'));
		add_line(subsystem_LN,'Ground_GnFan2On/1', 'wttl_set_GnFan2On/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan3On
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan3On');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WGEN','DO','GnFan3On');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan3On'));
		add_line(subsystem_LN,'Ground_GnFan3On/1', 'wttl_set_GnFan3On/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnHtEn
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnHtEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WGEN','DO','GnHtEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnHtEn'));
		add_line(subsystem_LN,'Ground_GnHtEn/1', 'wttl_set_GnHtEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuPmpEn
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuPmpEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WGEN','DO','GnLuPmpEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuPmpEn'));
		add_line(subsystem_LN,'Ground_GnLuPmpEn/1', 'wttl_set_GnLuPmpEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/SLCGnThermistorOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_SLCGnThermistorOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','SLCGnThermistorOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCGnThermistorOkFrc'));
		add_line(subsystem_LN,'Ground_SLCGnThermistorOkFrc/1', 'wttl_set_SLCGnThermistorOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan1OnFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan1OnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnFan1OnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan1OnFrc'));
		add_line(subsystem_LN,'Ground_GnFan1OnFrc/1', 'wttl_set_GnFan1OnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan2OnFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan2OnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnFan2OnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan2OnFrc'));
		add_line(subsystem_LN,'Ground_GnFan2OnFrc/1', 'wttl_set_GnFan2OnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan3OnFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan3OnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnFan3OnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan3OnFrc'));
		add_line(subsystem_LN,'Ground_GnFan3OnFrc/1', 'wttl_set_GnFan3OnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnHtEnFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnHtEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnHtEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnHtEnFrc'));
		add_line(subsystem_LN,'Ground_GnHtEnFrc/1', 'wttl_set_GnHtEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuPmpEnFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuPmpEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnLuPmpEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuPmpEnFrc'));
		add_line(subsystem_LN,'Ground_GnLuPmpEnFrc/1', 'wttl_set_GnLuPmpEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnBrushesOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnBrushesOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnBrushesOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnBrushesOkFrc'));
		add_line(subsystem_LN,'Ground_GnBrushesOkFrc/1', 'wttl_set_GnBrushesOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLghtnProtOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLghtnProtOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnLghtnProtOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLghtnProtOkFrc'));
		add_line(subsystem_LN,'Ground_GnLghtnProtOkFrc/1', 'wttl_set_GnLghtnProtOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuPmpOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnLuPmpOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuPmpOvlOkFrc'));
		add_line(subsystem_LN,'Ground_GnLuPmpOvlOkFrc/1', 'wttl_set_GnLuPmpOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnLuPmpOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnLuPmpOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnLuPmpOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnLuPmpOkFrc'));
		add_line(subsystem_LN,'Ground_GnLuPmpOkFrc/1', 'wttl_set_GnLuPmpOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan1OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan1OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnFan1OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan1OvlOkFrc'));
		add_line(subsystem_LN,'Ground_GnFan1OvlOkFrc/1', 'wttl_set_GnFan1OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan2OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan2OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnFan2OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan2OvlOkFrc'));
		add_line(subsystem_LN,'Ground_GnFan2OvlOkFrc/1', 'wttl_set_GnFan2OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnFan3OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnFan3OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnFan3OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnFan3OvlOkFrc'));
		add_line(subsystem_LN,'Ground_GnFan3OvlOkFrc/1', 'wttl_set_GnFan3OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnHtOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnHtOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnHtOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnHtOvlOkFrc'));
		add_line(subsystem_LN,'Ground_GnHtOvlOkFrc/1', 'wttl_set_GnHtOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/GnSpdEncOkFrc
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_GnSpdEncOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','GnSpdEncOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_GnSpdEncOkFrc'));
		add_line(subsystem_LN,'Ground_GnSpdEncOkFrc/1', 'wttl_set_GnSpdEncOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WGEN/P_GnNomSpd
		subsystem_LN = strcat(subsystem_out,'/WGEN');
		block        = strcat(subsystem_LN,'/wttl_set_P_GnNomSpd');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WGEN','DO','P_GnNomSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_GnNomSpd'));
		add_line(subsystem_LN,'Ground_P_GnNomSpd/1', 'wttl_set_P_GnNomSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WGEN')
	
	
		% WCNV/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WCNV','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
		% WCNV/TorqCalc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_TorqCalc');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','TorqCalc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TorqCalc'));
		add_line(subsystem_LN,'Ground_TorqCalc/1', 'wttl_set_TorqCalc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/TorqNomCalc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_TorqNomCalc');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','TorqNomCalc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TorqNomCalc'));
		add_line(subsystem_LN,'Ground_TorqNomCalc/1', 'wttl_set_TorqNomCalc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/TorqRlCalc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_TorqRlCalc');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','TorqRlCalc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TorqRlCalc'));
		add_line(subsystem_LN,'Ground_TorqRlCalc/1', 'wttl_set_TorqRlCalc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/V12Rms
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_V12Rms');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','V12Rms');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_V12Rms'));
		add_line(subsystem_LN,'Ground_V12Rms/1', 'wttl_set_V12Rms/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/V23Rms
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_V23Rms');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','V23Rms');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_V23Rms'));
		add_line(subsystem_LN,'Ground_V23Rms/1', 'wttl_set_V23Rms/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/V31Rms
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_V31Rms');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','V31Rms');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_V31Rms'));
		add_line(subsystem_LN,'Ground_V31Rms/1', 'wttl_set_V31Rms/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/DefVPhPh
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_DefVPhPh');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','DefVPhPh');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_DefVPhPh'));
		add_line(subsystem_LN,'Ground_DefVPhPh/1', 'wttl_set_DefVPhPh/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CurI1Rms
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CurI1Rms');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CurI1Rms');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CurI1Rms'));
		add_line(subsystem_LN,'Ground_CurI1Rms/1', 'wttl_set_CurI1Rms/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CurI2Rms
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CurI2Rms');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CurI2Rms');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CurI2Rms'));
		add_line(subsystem_LN,'Ground_CurI2Rms/1', 'wttl_set_CurI2Rms/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CurI3Rms
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CurI3Rms');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CurI3Rms');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CurI3Rms'));
		add_line(subsystem_LN,'Ground_CurI3Rms/1', 'wttl_set_CurI3Rms/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CabLodpuCnv
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CabLodpuCnv');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CabLodpuCnv');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabLodpuCnv'));
		add_line(subsystem_LN,'Ground_CabLodpuCnv/1', 'wttl_set_CabLodpuCnv/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CabLodpuSta
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CabLodpuSta');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CabLodpuSta');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabLodpuSta'));
		add_line(subsystem_LN,'Ground_CabLodpuSta/1', 'wttl_set_CabLodpuSta/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CabLod
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CabLod');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CabLod');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabLod'));
		add_line(subsystem_LN,'Ground_CabLod/1', 'wttl_set_CabLod/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CabLodCnv
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CabLodCnv');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CabLodCnv');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabLodCnv'));
		add_line(subsystem_LN,'Ground_CabLodCnv/1', 'wttl_set_CabLodCnv/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CabLodSta
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CabLodSta');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CabLodSta');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabLodSta'));
		add_line(subsystem_LN,'Ground_CabLodSta/1', 'wttl_set_CabLodSta/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvTorq
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvTorq');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvTorq');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvTorq'));
		add_line(subsystem_LN,'Ground_CnvTorq/1', 'wttl_set_CnvTorq/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvTorqSp
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvTorqSp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvTorqSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvTorqSp'));
		add_line(subsystem_LN,'Ground_CnvTorqSp/1', 'wttl_set_CnvTorqSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvTorqEst
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvTorqEst');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvTorqEst');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvTorqEst'));
		add_line(subsystem_LN,'Ground_CnvTorqEst/1', 'wttl_set_CnvTorqEst/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvTorqSpEst
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvTorqSpEst');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvTorqSpEst');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvTorqSpEst'));
		add_line(subsystem_LN,'Ground_CnvTorqSpEst/1', 'wttl_set_CnvTorqSpEst/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvVSp
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvVSp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvVSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvVSp'));
		add_line(subsystem_LN,'Ground_CnvVSp/1', 'wttl_set_CnvVSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvVSpLim
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvVSpLim');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvVSpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvVSpLim'));
		add_line(subsystem_LN,'Ground_CnvVSpLim/1', 'wttl_set_CnvVSpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvReactPwrSp
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvReactPwrSp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvReactPwrSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvReactPwrSp'));
		add_line(subsystem_LN,'Ground_CnvReactPwrSp/1', 'wttl_set_CnvReactPwrSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvReactPwrSpLim
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvReactPwrSpLim');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvReactPwrSpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvReactPwrSpLim'));
		add_line(subsystem_LN,'Ground_CnvReactPwrSpLim/1', 'wttl_set_CnvReactPwrSpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvPhiSp
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvPhiSp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvPhiSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvPhiSp'));
		add_line(subsystem_LN,'Ground_CnvPhiSp/1', 'wttl_set_CnvPhiSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvPhiSpLim
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvPhiSpLim');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WCNV','DO','CnvPhiSpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvPhiSpLim'));
		add_line(subsystem_LN,'Ground_CnvPhiSpLim/1', 'wttl_set_CnvPhiSpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvEmgStop1
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvEmgStop1');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WCNV','DO','CnvEmgStop1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvEmgStop1'));
		add_line(subsystem_LN,'Ground_CnvEmgStop1/1', 'wttl_set_CnvEmgStop1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvEmgStop2
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvEmgStop2');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WCNV','DO','CnvEmgStop2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvEmgStop2'));
		add_line(subsystem_LN,'Ground_CnvEmgStop2/1', 'wttl_set_CnvEmgStop2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvGridDisconOk
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvGridDisconOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WCNV','DO','ConvGridDisconOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvGridDisconOk'));
		add_line(subsystem_LN,'Ground_ConvGridDisconOk/1', 'wttl_set_ConvGridDisconOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvCCtBrOk
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvCCtBrOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WCNV','DO','ConvCCtBrOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvCCtBrOk'));
		add_line(subsystem_LN,'Ground_ConvCCtBrOk/1', 'wttl_set_ConvCCtBrOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvGridConn
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvGridConn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WCNV','DO','ConvGridConn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvGridConn'));
		add_line(subsystem_LN,'Ground_ConvGridConn/1', 'wttl_set_ConvGridConn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvSpareProt
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvSpareProt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WCNV','DO','ConvSpareProt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvSpareProt'));
		add_line(subsystem_LN,'Ground_ConvSpareProt/1', 'wttl_set_ConvSpareProt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/SLCEStopCnvOk
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopCnvOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WCNV','DO','SLCEStopCnvOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopCnvOk'));
		add_line(subsystem_LN,'Ground_SLCEStopCnvOk/1', 'wttl_set_SLCEStopCnvOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/SLCConvRequest
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_SLCConvRequest');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WCNV','DO','SLCConvRequest');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCConvRequest'));
		add_line(subsystem_LN,'Ground_SLCConvRequest/1', 'wttl_set_SLCConvRequest/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/SLCConvCircBrkOn
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_SLCConvCircBrkOn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WCNV','DO','SLCConvCircBrkOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCConvCircBrkOn'));
		add_line(subsystem_LN,'Ground_SLCConvCircBrkOn/1', 'wttl_set_SLCConvCircBrkOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvEmgStop1Frc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvEmgStop1Frc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','CnvEmgStop1Frc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvEmgStop1Frc'));
		add_line(subsystem_LN,'Ground_CnvEmgStop1Frc/1', 'wttl_set_CnvEmgStop1Frc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/CnvEmgStop2Frc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_CnvEmgStop2Frc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','CnvEmgStop2Frc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CnvEmgStop2Frc'));
		add_line(subsystem_LN,'Ground_CnvEmgStop2Frc/1', 'wttl_set_CnvEmgStop2Frc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvGridDisconOkFrc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvGridDisconOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','ConvGridDisconOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvGridDisconOkFrc'));
		add_line(subsystem_LN,'Ground_ConvGridDisconOkFrc/1', 'wttl_set_ConvGridDisconOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvCCtBrOkFrc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvCCtBrOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','ConvCCtBrOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvCCtBrOkFrc'));
		add_line(subsystem_LN,'Ground_ConvCCtBrOkFrc/1', 'wttl_set_ConvCCtBrOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvGridConnFrc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvGridConnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','ConvGridConnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvGridConnFrc'));
		add_line(subsystem_LN,'Ground_ConvGridConnFrc/1', 'wttl_set_ConvGridConnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/ConvSpareProtFrc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_ConvSpareProtFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','ConvSpareProtFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ConvSpareProtFrc'));
		add_line(subsystem_LN,'Ground_ConvSpareProtFrc/1', 'wttl_set_ConvSpareProtFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/SLCEStopCnvOkFrc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopCnvOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','SLCEStopCnvOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopCnvOkFrc'));
		add_line(subsystem_LN,'Ground_SLCEStopCnvOkFrc/1', 'wttl_set_SLCEStopCnvOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/SLCConvRequestFrc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_SLCConvRequestFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','SLCConvRequestFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCConvRequestFrc'));
		add_line(subsystem_LN,'Ground_SLCConvRequestFrc/1', 'wttl_set_SLCConvRequestFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/SLCConvCircBrkOnFrc
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_SLCConvCircBrkOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','SLCConvCircBrkOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCConvCircBrkOnFrc'));
		add_line(subsystem_LN,'Ground_SLCConvCircBrkOnFrc/1', 'wttl_set_SLCConvCircBrkOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ0
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ0');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ0');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ0'));
		add_line(subsystem_LN,'Ground_P_VQProQ0/1', 'wttl_set_P_VQProQ0/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ1
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ1');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ1'));
		add_line(subsystem_LN,'Ground_P_VQProQ1/1', 'wttl_set_P_VQProQ1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ2
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ2');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ2'));
		add_line(subsystem_LN,'Ground_P_VQProQ2/1', 'wttl_set_P_VQProQ2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ3
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ3');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ3');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ3'));
		add_line(subsystem_LN,'Ground_P_VQProQ3/1', 'wttl_set_P_VQProQ3/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ4
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ4');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ4');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ4'));
		add_line(subsystem_LN,'Ground_P_VQProQ4/1', 'wttl_set_P_VQProQ4/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ5
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ5');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ5');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ5'));
		add_line(subsystem_LN,'Ground_P_VQProQ5/1', 'wttl_set_P_VQProQ5/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ6
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ6');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ6');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ6'));
		add_line(subsystem_LN,'Ground_P_VQProQ6/1', 'wttl_set_P_VQProQ6/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ7
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ7');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ7');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ7'));
		add_line(subsystem_LN,'Ground_P_VQProQ7/1', 'wttl_set_P_VQProQ7/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ8
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ8');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ8');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ8'));
		add_line(subsystem_LN,'Ground_P_VQProQ8/1', 'wttl_set_P_VQProQ8/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ9
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ9');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ9');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ9'));
		add_line(subsystem_LN,'Ground_P_VQProQ9/1', 'wttl_set_P_VQProQ9/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ10
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ10');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ10');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ10'));
		add_line(subsystem_LN,'Ground_P_VQProQ10/1', 'wttl_set_P_VQProQ10/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProQ11
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProQ11');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProQ11');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProQ11'));
		add_line(subsystem_LN,'Ground_P_VQProQ11/1', 'wttl_set_P_VQProQ11/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV0
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV0');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV0');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV0'));
		add_line(subsystem_LN,'Ground_P_VQProV0/1', 'wttl_set_P_VQProV0/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV1
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV1');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV1'));
		add_line(subsystem_LN,'Ground_P_VQProV1/1', 'wttl_set_P_VQProV1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV2
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV2');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV2'));
		add_line(subsystem_LN,'Ground_P_VQProV2/1', 'wttl_set_P_VQProV2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV3
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV3');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV3');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV3'));
		add_line(subsystem_LN,'Ground_P_VQProV3/1', 'wttl_set_P_VQProV3/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV4
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV4');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV4');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV4'));
		add_line(subsystem_LN,'Ground_P_VQProV4/1', 'wttl_set_P_VQProV4/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV5
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV5');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV5');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV5'));
		add_line(subsystem_LN,'Ground_P_VQProV5/1', 'wttl_set_P_VQProV5/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV6
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV6');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV6');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV6'));
		add_line(subsystem_LN,'Ground_P_VQProV6/1', 'wttl_set_P_VQProV6/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV7
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV7');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV7');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV7'));
		add_line(subsystem_LN,'Ground_P_VQProV7/1', 'wttl_set_P_VQProV7/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV8
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV8');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV8');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV8'));
		add_line(subsystem_LN,'Ground_P_VQProV8/1', 'wttl_set_P_VQProV8/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV9
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV9');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV9');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV9'));
		add_line(subsystem_LN,'Ground_P_VQProV9/1', 'wttl_set_P_VQProV9/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV10
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV10');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV10');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV10'));
		add_line(subsystem_LN,'Ground_P_VQProV10/1', 'wttl_set_P_VQProV10/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_VQProV11
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_VQProV11');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_VQProV11');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_VQProV11'));
		add_line(subsystem_LN,'Ground_P_VQProV11/1', 'wttl_set_P_VQProV11/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_Evt3630SetDl
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_Evt3630SetDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_Evt3630SetDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Evt3630SetDl'));
		add_line(subsystem_LN,'Ground_P_Evt3630SetDl/1', 'wttl_set_P_Evt3630SetDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_Evt3500SetDl
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_Evt3500SetDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_Evt3500SetDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Evt3500SetDl'));
		add_line(subsystem_LN,'Ground_P_Evt3500SetDl/1', 'wttl_set_P_Evt3500SetDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_Evt3632SetDl
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_Evt3632SetDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_Evt3632SetDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Evt3632SetDl'));
		add_line(subsystem_LN,'Ground_P_Evt3632SetDl/1', 'wttl_set_P_Evt3632SetDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_CabNomCur
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_CabNomCur');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_CabNomCur');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CabNomCur'));
		add_line(subsystem_LN,'Ground_P_CabNomCur/1', 'wttl_set_P_CabNomCur/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_CabNomTau
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_CabNomTau');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_CabNomTau');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CabNomTau'));
		add_line(subsystem_LN,'Ground_P_CabNomTau/1', 'wttl_set_P_CabNomTau/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_CabLodCnvConvFact
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_CabLodCnvConvFact');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_CabLodCnvConvFact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CabLodCnvConvFact'));
		add_line(subsystem_LN,'Ground_P_CabLodCnvConvFact/1', 'wttl_set_P_CabLodCnvConvFact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_CabLodStaConvFact
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_CabLodStaConvFact');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_CabLodStaConvFact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CabLodStaConvFact'));
		add_line(subsystem_LN,'Ground_P_CabLodStaConvFact/1', 'wttl_set_P_CabLodStaConvFact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_TorqEstCnvActTau
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_TorqEstCnvActTau');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_TorqEstCnvActTau');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TorqEstCnvActTau'));
		add_line(subsystem_LN,'Ground_P_TorqEstCnvActTau/1', 'wttl_set_P_TorqEstCnvActTau/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_TorqEstCnvSpTau
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_TorqEstCnvSpTau');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_TorqEstCnvSpTau');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TorqEstCnvSpTau'));
		add_line(subsystem_LN,'Ground_P_TorqEstCnvSpTau/1', 'wttl_set_P_TorqEstCnvSpTau/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_CnvSendTrigAct
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_CnvSendTrigAct');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WCNV','DO','P_CnvSendTrigAct');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CnvSendTrigAct'));
		add_line(subsystem_LN,'Ground_P_CnvSendTrigAct/1', 'wttl_set_P_CnvSendTrigAct/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_CnvSendTrigSnapAct
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_CnvSendTrigSnapAct');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WCNV','DO','P_CnvSendTrigSnapAct');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CnvSendTrigSnapAct'));
		add_line(subsystem_LN,'Ground_P_CnvSendTrigSnapAct/1', 'wttl_set_P_CnvSendTrigSnapAct/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_CnvSendTrigEvtAct
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_CnvSendTrigEvtAct');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WCNV','DO','P_CnvSendTrigEvtAct');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_CnvSendTrigEvtAct'));
		add_line(subsystem_LN,'Ground_P_CnvSendTrigEvtAct/1', 'wttl_set_P_CnvSendTrigEvtAct/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WCNV/P_PtMotCurMaxLim10mAvg
		subsystem_LN = strcat(subsystem_out,'/WCNV');
		block        = strcat(subsystem_LN,'/wttl_set_P_PtMotCurMaxLim10mAvg');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WCNV','DO','P_PtMotCurMaxLim10mAvg');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_PtMotCurMaxLim10mAvg'));
		add_line(subsystem_LN,'Ground_P_PtMotCurMaxLim10mAvg/1', 'wttl_set_P_PtMotCurMaxLim10mAvg/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WCNV')
	
	
		% WTRF/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WTRF','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
		% WTRF/AuxTrfTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_AuxTrfTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','AuxTrfTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxTrfTmpSensFlt'));
		add_line(subsystem_LN,'Ground_AuxTrfTmpSensFlt/1', 'wttl_set_AuxTrfTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/AuxPwrCtlAct
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_AuxPwrCtlAct');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','AuxPwrCtlAct');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxPwrCtlAct'));
		add_line(subsystem_LN,'Ground_AuxPwrCtlAct/1', 'wttl_set_AuxPwrCtlAct/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/AuxPwrCtlSwOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_AuxPwrCtlSwOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','AuxPwrCtlSwOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxPwrCtlSwOn'));
		add_line(subsystem_LN,'Ground_AuxPwrCtlSwOn/1', 'wttl_set_AuxPwrCtlSwOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilTmpOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilTmpOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfOilTmpOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilTmpOk'));
		add_line(subsystem_LN,'Ground_TrfOilTmpOk/1', 'wttl_set_TrfOilTmpOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilTmpFuOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilTmpFuOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfOilTmpFuOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilTmpFuOk'));
		add_line(subsystem_LN,'Ground_TrfOilTmpFuOk/1', 'wttl_set_TrfOilTmpFuOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOvVOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOvVOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfOvVOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOvVOk'));
		add_line(subsystem_LN,'Ground_TrfOvVOk/1', 'wttl_set_TrfOvVOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfCCtBrOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfCCtBrOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSTrfCCtBrOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfCCtBrOn'));
		add_line(subsystem_LN,'Ground_MVSTrfCCtBrOn/1', 'wttl_set_MVSTrfCCtBrOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfCCtBrTripped
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfCCtBrTripped');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSTrfCCtBrTripped');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfCCtBrTripped'));
		add_line(subsystem_LN,'Ground_MVSTrfCCtBrTripped/1', 'wttl_set_MVSTrfCCtBrTripped/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/ExtProtDev
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_ExtProtDev');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','ExtProtDev');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ExtProtDev'));
		add_line(subsystem_LN,'Ground_ExtProtDev/1', 'wttl_set_ExtProtDev/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfDiscon
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfDiscon');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSTrfDiscon');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfDiscon'));
		add_line(subsystem_LN,'Ground_MVSTrfDiscon/1', 'wttl_set_MVSTrfDiscon/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfEarthed
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfEarthed');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSTrfEarthed');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfEarthed'));
		add_line(subsystem_LN,'Ground_MVSTrfEarthed/1', 'wttl_set_MVSTrfEarthed/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfPmpOvlOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfPmpOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfPmpOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfPmpOvlOk'));
		add_line(subsystem_LN,'Ground_TrfPmpOvlOk/1', 'wttl_set_TrfPmpOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfLiquidLvlOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfLiquidLvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfLiquidLvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfLiquidLvlOk'));
		add_line(subsystem_LN,'Ground_TrfLiquidLvlOk/1', 'wttl_set_TrfLiquidLvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfPmpThermistorOK
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfPmpThermistorOK');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfPmpThermistorOK');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfPmpThermistorOK'));
		add_line(subsystem_LN,'Ground_TrfPmpThermistorOK/1', 'wttl_set_TrfPmpThermistorOK/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl1DisconOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl1DisconOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSOutl1DisconOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl1DisconOn'));
		add_line(subsystem_LN,'Ground_MVSOutl1DisconOn/1', 'wttl_set_MVSOutl1DisconOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl1EarthingSwOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl1EarthingSwOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSOutl1EarthingSwOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl1EarthingSwOn'));
		add_line(subsystem_LN,'Ground_MVSOutl1EarthingSwOn/1', 'wttl_set_MVSOutl1EarthingSwOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl2DisconOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl2DisconOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSOutl2DisconOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl2DisconOn'));
		add_line(subsystem_LN,'Ground_MVSOutl2DisconOn/1', 'wttl_set_MVSOutl2DisconOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl2EarthingSwOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl2EarthingSwOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSOutl2EarthingSwOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl2EarthingSwOn'));
		add_line(subsystem_LN,'Ground_MVSOutl2EarthingSwOn/1', 'wttl_set_MVSOutl2EarthingSwOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilTmpFltOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilTmpFltOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfOilTmpFltOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilTmpFltOk'));
		add_line(subsystem_LN,'Ground_TrfOilTmpFltOk/1', 'wttl_set_TrfOilTmpFltOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSGridDisconOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSGridDisconOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSGridDisconOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSGridDisconOn'));
		add_line(subsystem_LN,'Ground_MVSGridDisconOn/1', 'wttl_set_MVSGridDisconOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSGridEarthingSwOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSGridEarthingSwOn');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSGridEarthingSwOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSGridEarthingSwOn'));
		add_line(subsystem_LN,'Ground_MVSGridEarthingSwOn/1', 'wttl_set_MVSGridEarthingSwOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfProtFailureOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfProtFailureOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','MVSTrfProtFailureOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfProtFailureOk'));
		add_line(subsystem_LN,'Ground_MVSTrfProtFailureOk/1', 'wttl_set_MVSTrfProtFailureOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilPresOk
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilPresOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTRF','DO','TrfOilPresOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilPresOk'));
		add_line(subsystem_LN,'Ground_TrfOilPresOk/1', 'wttl_set_TrfOilPresOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfPmpOn
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfPmpOn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTRF','DO','TrfPmpOn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfPmpOn'));
		add_line(subsystem_LN,'Ground_TrfPmpOn/1', 'wttl_set_TrfPmpOn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/SLCMVSTrfRemOff
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_SLCMVSTrfRemOff');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTRF','DO','SLCMVSTrfRemOff');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCMVSTrfRemOff'));
		add_line(subsystem_LN,'Ground_SLCMVSTrfRemOff/1', 'wttl_set_SLCMVSTrfRemOff/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfInnerSpaceTmp
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfInnerSpaceTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRF','DO','TrfInnerSpaceTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfInnerSpaceTmp'));
		add_line(subsystem_LN,'Ground_TrfInnerSpaceTmp/1', 'wttl_set_TrfInnerSpaceTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/AuxTrfTmp
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_AuxTrfTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTRF','DO','AuxTrfTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxTrfTmp'));
		add_line(subsystem_LN,'Ground_AuxTrfTmp/1', 'wttl_set_AuxTrfTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfInnerSpaceTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfInnerSpaceTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRF','DO','TrfInnerSpaceTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfInnerSpaceTmpRaw'));
		add_line(subsystem_LN,'Ground_TrfInnerSpaceTmpRaw/1', 'wttl_set_TrfInnerSpaceTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/AuxTrfTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_AuxTrfTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTRF','DO','AuxTrfTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxTrfTmpRaw'));
		add_line(subsystem_LN,'Ground_AuxTrfTmpRaw/1', 'wttl_set_AuxTrfTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/AuxPwrCtlActFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_AuxPwrCtlActFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','AuxPwrCtlActFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxPwrCtlActFrc'));
		add_line(subsystem_LN,'Ground_AuxPwrCtlActFrc/1', 'wttl_set_AuxPwrCtlActFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/AuxPwrCtlSwOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_AuxPwrCtlSwOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','AuxPwrCtlSwOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AuxPwrCtlSwOnFrc'));
		add_line(subsystem_LN,'Ground_AuxPwrCtlSwOnFrc/1', 'wttl_set_AuxPwrCtlSwOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilTmpOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilTmpOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfOilTmpOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilTmpOkFrc'));
		add_line(subsystem_LN,'Ground_TrfOilTmpOkFrc/1', 'wttl_set_TrfOilTmpOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilTmpFuOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilTmpFuOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfOilTmpFuOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilTmpFuOkFrc'));
		add_line(subsystem_LN,'Ground_TrfOilTmpFuOkFrc/1', 'wttl_set_TrfOilTmpFuOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOvVOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOvVOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfOvVOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOvVOkFrc'));
		add_line(subsystem_LN,'Ground_TrfOvVOkFrc/1', 'wttl_set_TrfOvVOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfCCtBrOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfCCtBrOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSTrfCCtBrOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfCCtBrOnFrc'));
		add_line(subsystem_LN,'Ground_MVSTrfCCtBrOnFrc/1', 'wttl_set_MVSTrfCCtBrOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfCCtBrTrippedFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfCCtBrTrippedFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSTrfCCtBrTrippedFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfCCtBrTrippedFrc'));
		add_line(subsystem_LN,'Ground_MVSTrfCCtBrTrippedFrc/1', 'wttl_set_MVSTrfCCtBrTrippedFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/ExtProtDevFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_ExtProtDevFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','ExtProtDevFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ExtProtDevFrc'));
		add_line(subsystem_LN,'Ground_ExtProtDevFrc/1', 'wttl_set_ExtProtDevFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfDisconFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfDisconFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSTrfDisconFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfDisconFrc'));
		add_line(subsystem_LN,'Ground_MVSTrfDisconFrc/1', 'wttl_set_MVSTrfDisconFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfEarthedFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfEarthedFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSTrfEarthedFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfEarthedFrc'));
		add_line(subsystem_LN,'Ground_MVSTrfEarthedFrc/1', 'wttl_set_MVSTrfEarthedFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfPmpOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfPmpOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfPmpOvlOkFrc'));
		add_line(subsystem_LN,'Ground_TrfPmpOvlOkFrc/1', 'wttl_set_TrfPmpOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfLiquidLvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfLiquidLvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfLiquidLvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfLiquidLvlOkFrc'));
		add_line(subsystem_LN,'Ground_TrfLiquidLvlOkFrc/1', 'wttl_set_TrfLiquidLvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfPmpThermistorOKFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfPmpThermistorOKFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfPmpThermistorOKFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfPmpThermistorOKFrc'));
		add_line(subsystem_LN,'Ground_TrfPmpThermistorOKFrc/1', 'wttl_set_TrfPmpThermistorOKFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl1DisconOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl1DisconOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSOutl1DisconOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl1DisconOnFrc'));
		add_line(subsystem_LN,'Ground_MVSOutl1DisconOnFrc/1', 'wttl_set_MVSOutl1DisconOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl1EarthingSwOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl1EarthingSwOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSOutl1EarthingSwOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl1EarthingSwOnFrc'));
		add_line(subsystem_LN,'Ground_MVSOutl1EarthingSwOnFrc/1', 'wttl_set_MVSOutl1EarthingSwOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl2DisconOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl2DisconOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSOutl2DisconOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl2DisconOnFrc'));
		add_line(subsystem_LN,'Ground_MVSOutl2DisconOnFrc/1', 'wttl_set_MVSOutl2DisconOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSOutl2EarthingSwOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSOutl2EarthingSwOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSOutl2EarthingSwOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSOutl2EarthingSwOnFrc'));
		add_line(subsystem_LN,'Ground_MVSOutl2EarthingSwOnFrc/1', 'wttl_set_MVSOutl2EarthingSwOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilTmpFltOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilTmpFltOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfOilTmpFltOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilTmpFltOkFrc'));
		add_line(subsystem_LN,'Ground_TrfOilTmpFltOkFrc/1', 'wttl_set_TrfOilTmpFltOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSGridDisconOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSGridDisconOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSGridDisconOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSGridDisconOnFrc'));
		add_line(subsystem_LN,'Ground_MVSGridDisconOnFrc/1', 'wttl_set_MVSGridDisconOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSGridEarthingSwOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSGridEarthingSwOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSGridEarthingSwOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSGridEarthingSwOnFrc'));
		add_line(subsystem_LN,'Ground_MVSGridEarthingSwOnFrc/1', 'wttl_set_MVSGridEarthingSwOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfPmpOnFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfPmpOnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfPmpOnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfPmpOnFrc'));
		add_line(subsystem_LN,'Ground_TrfPmpOnFrc/1', 'wttl_set_TrfPmpOnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/MVSTrfProtFailureOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_MVSTrfProtFailureOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','MVSTrfProtFailureOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MVSTrfProtFailureOkFrc'));
		add_line(subsystem_LN,'Ground_MVSTrfProtFailureOkFrc/1', 'wttl_set_MVSTrfProtFailureOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/TrfOilPresOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_TrfOilPresOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','TrfOilPresOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TrfOilPresOkFrc'));
		add_line(subsystem_LN,'Ground_TrfOilPresOkFrc/1', 'wttl_set_TrfOilPresOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WTRF/SLCMVSTrfRemOffFrc
		subsystem_LN = strcat(subsystem_out,'/WTRF');
		block        = strcat(subsystem_LN,'/wttl_set_SLCMVSTrfRemOffFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTRF','DO','SLCMVSTrfRemOffFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCMVSTrfRemOffFrc'));
		add_line(subsystem_LN,'Ground_SLCMVSTrfRemOffFrc/1', 'wttl_set_SLCMVSTrfRemOffFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTRF')
	
	
		% WNAC/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WNAC','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
		% WNAC/Dir
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Dir');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Dir');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Dir'));
		add_line(subsystem_LN,'Ground_Dir/1', 'wttl_set_Dir/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/WdSpd
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_WdSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','WdSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WdSpd'));
		add_line(subsystem_LN,'Ground_WdSpd/1', 'wttl_set_WdSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/WdDir
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_WdDir');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','WdDir');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WdDir'));
		add_line(subsystem_LN,'Ground_WdDir/1', 'wttl_set_WdDir/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ExTmp
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ExTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','ExTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ExTmp'));
		add_line(subsystem_LN,'Ground_ExTmp/1', 'wttl_set_ExTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/IntlTmp
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_IntlTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','IntlTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_IntlTmp'));
		add_line(subsystem_LN,'Ground_IntlTmp/1', 'wttl_set_IntlTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/WdSpdCal
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_WdSpdCal');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','WdSpdCal');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_WdSpdCal'));
		add_line(subsystem_LN,'Ground_WdSpdCal/1', 'wttl_set_WdSpdCal/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/AneIceDetWdSpdCal
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_AneIceDetWdSpdCal');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','AneIceDetWdSpdCal');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AneIceDetWdSpdCal'));
		add_line(subsystem_LN,'Ground_AneIceDetWdSpdCal/1', 'wttl_set_AneIceDetWdSpdCal/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1WdSpdCal
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1WdSpdCal');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane1WdSpdCal');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1WdSpdCal'));
		add_line(subsystem_LN,'Ground_Ane1WdSpdCal/1', 'wttl_set_Ane1WdSpdCal/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane2WdSpdCal
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane2WdSpdCal');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane2WdSpdCal');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane2WdSpdCal'));
		add_line(subsystem_LN,'Ground_Ane2WdSpdCal/1', 'wttl_set_Ane2WdSpdCal/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1WdDirCorr
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1WdDirCorr');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane1WdDirCorr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1WdDirCorr'));
		add_line(subsystem_LN,'Ground_Ane1WdDirCorr/1', 'wttl_set_Ane1WdDirCorr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane2WdDirCorr
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane2WdDirCorr');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane2WdDirCorr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane2WdDirCorr'));
		add_line(subsystem_LN,'Ground_Ane2WdDirCorr/1', 'wttl_set_Ane2WdDirCorr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1a2WdDirCorr
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1a2WdDirCorr');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane1a2WdDirCorr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1a2WdDirCorr'));
		add_line(subsystem_LN,'Ground_Ane1a2WdDirCorr/1', 'wttl_set_Ane1a2WdDirCorr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1a2WdDir
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1a2WdDir');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane1a2WdDir');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1a2WdDir'));
		add_line(subsystem_LN,'Ground_Ane1a2WdDir/1', 'wttl_set_Ane1a2WdDir/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacExTmp1a2Av
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacExTmp1a2Av');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','NacExTmp1a2Av');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacExTmp1a2Av'));
		add_line(subsystem_LN,'Ground_NacExTmp1a2Av/1', 'wttl_set_NacExTmp1a2Av/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacCoolTmpSensFlt
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacCoolTmpSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacCoolTmpSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacCoolTmpSensFlt'));
		add_line(subsystem_LN,'Ground_NacCoolTmpSensFlt/1', 'wttl_set_NacCoolTmpSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacCoolPresSensFlt
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacCoolPresSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacCoolPresSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacCoolPresSensFlt'));
		add_line(subsystem_LN,'Ground_NacCoolPresSensFlt/1', 'wttl_set_NacCoolPresSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacCoolPmpInletPresSensFlt
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacCoolPmpInletPresSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacCoolPmpInletPresSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacCoolPmpInletPresSensFlt'));
		add_line(subsystem_LN,'Ground_NacCoolPmpInletPresSensFlt/1', 'wttl_set_NacCoolPmpInletPresSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/CoolInletPmpPResSensFlt
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_CoolInletPmpPResSensFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','CoolInletPmpPResSensFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CoolInletPmpPResSensFlt'));
		add_line(subsystem_LN,'Ground_CoolInletPmpPResSensFlt/1', 'wttl_set_CoolInletPmpPResSensFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacExtTmp1a2Av
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacExtTmp1a2Av');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','NacExtTmp1a2Av');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacExtTmp1a2Av'));
		add_line(subsystem_LN,'Ground_NacExtTmp1a2Av/1', 'wttl_set_NacExtTmp1a2Av/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/IceWrn
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_IceWrn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WNAC','DO','IceWrn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_IceWrn'));
		add_line(subsystem_LN,'Ground_IceWrn/1', 'wttl_set_IceWrn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/SLCNacSysState
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_SLCNacSysState');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WNAC','DO','SLCNacSysState');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCNacSysState'));
		add_line(subsystem_LN,'Ground_SLCNacSysState/1', 'wttl_set_SLCNacSysState/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacFanEn
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacFanEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WNAC','DO','NacFanEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacFanEn'));
		add_line(subsystem_LN,'Ground_NacFanEn/1', 'wttl_set_NacFanEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/MetHtEn
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_MetHtEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WNAC','DO','MetHtEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MetHtEn'));
		add_line(subsystem_LN,'Ground_MetHtEn/1', 'wttl_set_MetHtEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/LghtRedLvl1
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_LghtRedLvl1');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WNAC','DO','LghtRedLvl1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_LghtRedLvl1'));
		add_line(subsystem_LN,'Ground_LghtRedLvl1/1', 'wttl_set_LghtRedLvl1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/LghtRedLvl2
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_LghtRedLvl2');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WNAC','DO','LghtRedLvl2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_LghtRedLvl2'));
		add_line(subsystem_LN,'Ground_LghtRedLvl2/1', 'wttl_set_LghtRedLvl2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/SLCNacRs
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_SLCNacRs');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','SLCNacRs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCNacRs'));
		add_line(subsystem_LN,'Ground_SLCNacRs/1', 'wttl_set_SLCNacRs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ByVlvOvlOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ByVlvOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','ByVlvOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ByVlvOvlOk'));
		add_line(subsystem_LN,'Ground_ByVlvOvlOk/1', 'wttl_set_ByVlvOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacEStop
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacEStop');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacEStop');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacEStop'));
		add_line(subsystem_LN,'Ground_NacEStop/1', 'wttl_set_NacEStop/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacSmkDetectOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacSmkDetectOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacSmkDetectOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacSmkDetectOk'));
		add_line(subsystem_LN,'Ground_NacSmkDetectOk/1', 'wttl_set_NacSmkDetectOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacNoSmkAlm
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacNoSmkAlm');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacNoSmkAlm');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacNoSmkAlm'));
		add_line(subsystem_LN,'Ground_NacNoSmkAlm/1', 'wttl_set_NacNoSmkAlm/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacVisSensOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacVisSensOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacVisSensOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacVisSensOk'));
		add_line(subsystem_LN,'Ground_NacVisSensOk/1', 'wttl_set_NacVisSensOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacVisLvl1
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacVisLvl1');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacVisLvl1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacVisLvl1'));
		add_line(subsystem_LN,'Ground_NacVisLvl1/1', 'wttl_set_NacVisLvl1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacVisLvl2
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacVisLvl2');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacVisLvl2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacVisLvl2'));
		add_line(subsystem_LN,'Ground_NacVisLvl2/1', 'wttl_set_NacVisLvl2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacFanOvlOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacFanOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacFanOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacFanOvlOk'));
		add_line(subsystem_LN,'Ground_NacFanOvlOk/1', 'wttl_set_NacFanOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacFanOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacFanOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NacFanOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacFanOk'));
		add_line(subsystem_LN,'Ground_NacFanOk/1', 'wttl_set_NacFanOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ObstacleLghtOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ObstacleLghtOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','ObstacleLghtOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ObstacleLghtOk'));
		add_line(subsystem_LN,'Ground_ObstacleLghtOk/1', 'wttl_set_ObstacleLghtOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ObstacleLghtMaintOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ObstacleLghtMaintOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','ObstacleLghtMaintOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ObstacleLghtMaintOk'));
		add_line(subsystem_LN,'Ground_ObstacleLghtMaintOk/1', 'wttl_set_ObstacleLghtMaintOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ObstacleLghtFltOk
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ObstacleLghtFltOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','ObstacleLghtFltOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ObstacleLghtFltOk'));
		add_line(subsystem_LN,'Ground_ObstacleLghtFltOk/1', 'wttl_set_ObstacleLghtFltOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NoIceDet
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NoIceDet');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WNAC','DO','NoIceDet');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NoIceDet'));
		add_line(subsystem_LN,'Ground_NoIceDet/1', 'wttl_set_NoIceDet/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacTmp
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','NacTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacTmp'));
		add_line(subsystem_LN,'Ground_NacTmp/1', 'wttl_set_NacTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacInsideRelHum
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacInsideRelHum');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','NacInsideRelHum');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacInsideRelHum'));
		add_line(subsystem_LN,'Ground_NacInsideRelHum/1', 'wttl_set_NacInsideRelHum/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane2WdSpd
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane2WdSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane2WdSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane2WdSpd'));
		add_line(subsystem_LN,'Ground_Ane2WdSpd/1', 'wttl_set_Ane2WdSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane2WdDir
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane2WdDir');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane2WdDir');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane2WdDir'));
		add_line(subsystem_LN,'Ground_Ane2WdDir/1', 'wttl_set_Ane2WdDir/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/AneIceDetWdSpd
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_AneIceDetWdSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','AneIceDetWdSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AneIceDetWdSpd'));
		add_line(subsystem_LN,'Ground_AneIceDetWdSpd/1', 'wttl_set_AneIceDetWdSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacExTmp
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacExTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','NacExTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacExTmp'));
		add_line(subsystem_LN,'Ground_NacExTmp/1', 'wttl_set_NacExTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1WdDir
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1WdDir');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane1WdDir');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1WdDir'));
		add_line(subsystem_LN,'Ground_Ane1WdDir/1', 'wttl_set_Ane1WdDir/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1WdSpd
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1WdSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','Ane1WdSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1WdSpd'));
		add_line(subsystem_LN,'Ground_Ane1WdSpd/1', 'wttl_set_Ane1WdSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacExTmp2
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacExTmp2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WNAC','DO','NacExTmp2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacExTmp2'));
		add_line(subsystem_LN,'Ground_NacExTmp2/1', 'wttl_set_NacExTmp2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','NacTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacTmpRaw'));
		add_line(subsystem_LN,'Ground_NacTmpRaw/1', 'wttl_set_NacTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacInsideRelHumRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacInsideRelHumRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','NacInsideRelHumRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacInsideRelHumRaw'));
		add_line(subsystem_LN,'Ground_NacInsideRelHumRaw/1', 'wttl_set_NacInsideRelHumRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane2WdSpdRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane2WdSpdRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','Ane2WdSpdRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane2WdSpdRaw'));
		add_line(subsystem_LN,'Ground_Ane2WdSpdRaw/1', 'wttl_set_Ane2WdSpdRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane2WdDirRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane2WdDirRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','Ane2WdDirRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane2WdDirRaw'));
		add_line(subsystem_LN,'Ground_Ane2WdDirRaw/1', 'wttl_set_Ane2WdDirRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/AneIceDetWdSpdRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_AneIceDetWdSpdRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','AneIceDetWdSpdRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_AneIceDetWdSpdRaw'));
		add_line(subsystem_LN,'Ground_AneIceDetWdSpdRaw/1', 'wttl_set_AneIceDetWdSpdRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacExTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacExTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','NacExTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacExTmpRaw'));
		add_line(subsystem_LN,'Ground_NacExTmpRaw/1', 'wttl_set_NacExTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1WdDirRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1WdDirRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','Ane1WdDirRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1WdDirRaw'));
		add_line(subsystem_LN,'Ground_Ane1WdDirRaw/1', 'wttl_set_Ane1WdDirRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/Ane1WdSpdRaw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_Ane1WdSpdRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','Ane1WdSpdRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_Ane1WdSpdRaw'));
		add_line(subsystem_LN,'Ground_Ane1WdSpdRaw/1', 'wttl_set_Ane1WdSpdRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacExTmp2Raw
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacExTmp2Raw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WNAC','DO','NacExTmp2Raw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacExTmp2Raw'));
		add_line(subsystem_LN,'Ground_NacExTmp2Raw/1', 'wttl_set_NacExTmp2Raw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacFanSp
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacFanSp');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacFanSp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacFanSp'));
		add_line(subsystem_LN,'Ground_NacFanSp/1', 'wttl_set_NacFanSp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/IceWrnFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_IceWrnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','IceWrnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_IceWrnFrc'));
		add_line(subsystem_LN,'Ground_IceWrnFrc/1', 'wttl_set_IceWrnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/SLCNacRsFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_SLCNacRsFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','SLCNacRsFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCNacRsFrc'));
		add_line(subsystem_LN,'Ground_SLCNacRsFrc/1', 'wttl_set_SLCNacRsFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/SLCNacSysStateFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_SLCNacSysStateFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','SLCNacSysStateFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCNacSysStateFrc'));
		add_line(subsystem_LN,'Ground_SLCNacSysStateFrc/1', 'wttl_set_SLCNacSysStateFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ByVlvOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ByVlvOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','ByVlvOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ByVlvOvlOkFrc'));
		add_line(subsystem_LN,'Ground_ByVlvOvlOkFrc/1', 'wttl_set_ByVlvOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacEStopFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacEStopFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacEStopFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacEStopFrc'));
		add_line(subsystem_LN,'Ground_NacEStopFrc/1', 'wttl_set_NacEStopFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacSmkDetectOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacSmkDetectOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacSmkDetectOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacSmkDetectOkFrc'));
		add_line(subsystem_LN,'Ground_NacSmkDetectOkFrc/1', 'wttl_set_NacSmkDetectOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacNoSmkAlmFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacNoSmkAlmFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacNoSmkAlmFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacNoSmkAlmFrc'));
		add_line(subsystem_LN,'Ground_NacNoSmkAlmFrc/1', 'wttl_set_NacNoSmkAlmFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacFanEnFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacFanEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacFanEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacFanEnFrc'));
		add_line(subsystem_LN,'Ground_NacFanEnFrc/1', 'wttl_set_NacFanEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacVisSensOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacVisSensOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacVisSensOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacVisSensOkFrc'));
		add_line(subsystem_LN,'Ground_NacVisSensOkFrc/1', 'wttl_set_NacVisSensOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacVisLvl1Frc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacVisLvl1Frc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacVisLvl1Frc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacVisLvl1Frc'));
		add_line(subsystem_LN,'Ground_NacVisLvl1Frc/1', 'wttl_set_NacVisLvl1Frc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacVisLvl2Frc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacVisLvl2Frc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacVisLvl2Frc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacVisLvl2Frc'));
		add_line(subsystem_LN,'Ground_NacVisLvl2Frc/1', 'wttl_set_NacVisLvl2Frc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacFanOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacFanOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacFanOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacFanOvlOkFrc'));
		add_line(subsystem_LN,'Ground_NacFanOvlOkFrc/1', 'wttl_set_NacFanOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NacFanOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NacFanOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NacFanOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacFanOkFrc'));
		add_line(subsystem_LN,'Ground_NacFanOkFrc/1', 'wttl_set_NacFanOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ObstacleLghtOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ObstacleLghtOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','ObstacleLghtOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ObstacleLghtOkFrc'));
		add_line(subsystem_LN,'Ground_ObstacleLghtOkFrc/1', 'wttl_set_ObstacleLghtOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ObstacleLghtMaintOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ObstacleLghtMaintOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','ObstacleLghtMaintOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ObstacleLghtMaintOkFrc'));
		add_line(subsystem_LN,'Ground_ObstacleLghtMaintOkFrc/1', 'wttl_set_ObstacleLghtMaintOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/ObstacleLghtFltOkFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_ObstacleLghtFltOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','ObstacleLghtFltOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_ObstacleLghtFltOkFrc'));
		add_line(subsystem_LN,'Ground_ObstacleLghtFltOkFrc/1', 'wttl_set_ObstacleLghtFltOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/NoIceDetFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_NoIceDetFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','NoIceDetFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NoIceDetFrc'));
		add_line(subsystem_LN,'Ground_NoIceDetFrc/1', 'wttl_set_NoIceDetFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/MetHtEnFrc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_MetHtEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','MetHtEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_MetHtEnFrc'));
		add_line(subsystem_LN,'Ground_MetHtEnFrc/1', 'wttl_set_MetHtEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/LghtRedLvl1Frc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_LghtRedLvl1Frc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','LghtRedLvl1Frc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_LghtRedLvl1Frc'));
		add_line(subsystem_LN,'Ground_LghtRedLvl1Frc/1', 'wttl_set_LghtRedLvl1Frc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/LghtRedLvl2Frc
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_LghtRedLvl2Frc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','LghtRedLvl2Frc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_LghtRedLvl2Frc'));
		add_line(subsystem_LN,'Ground_LghtRedLvl2Frc/1', 'wttl_set_LghtRedLvl2Frc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacIceDetAne
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacIceDetAne');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WNAC','DO','P_NacIceDetAne');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacIceDetAne'));
		add_line(subsystem_LN,'Ground_P_NacIceDetAne/1', 'wttl_set_P_NacIceDetAne/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacIceDetAneSlope
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacIceDetAneSlope');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacIceDetAneSlope');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacIceDetAneSlope'));
		add_line(subsystem_LN,'Ground_P_NacIceDetAneSlope/1', 'wttl_set_P_NacIceDetAneSlope/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacIceDetAneBias
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacIceDetAneBias');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacIceDetAneBias');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacIceDetAneBias'));
		add_line(subsystem_LN,'Ground_P_NacIceDetAneBias/1', 'wttl_set_P_NacIceDetAneBias/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Ane1Slope
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Ane1Slope');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Ane1Slope');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Ane1Slope'));
		add_line(subsystem_LN,'Ground_P_Ane1Slope/1', 'wttl_set_P_Ane1Slope/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Ane1Bias
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Ane1Bias');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Ane1Bias');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Ane1Bias'));
		add_line(subsystem_LN,'Ground_P_Ane1Bias/1', 'wttl_set_P_Ane1Bias/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Ane1a
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Ane1a');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Ane1a');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Ane1a'));
		add_line(subsystem_LN,'Ground_P_Ane1a/1', 'wttl_set_P_Ane1a/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Ane1b
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Ane1b');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Ane1b');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Ane1b'));
		add_line(subsystem_LN,'Ground_P_Ane1b/1', 'wttl_set_P_Ane1b/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Ane2Slope
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Ane2Slope');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Ane2Slope');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Ane2Slope'));
		add_line(subsystem_LN,'Ground_P_Ane2Slope/1', 'wttl_set_P_Ane2Slope/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Ane2Bias
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Ane2Bias');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Ane2Bias');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Ane2Bias'));
		add_line(subsystem_LN,'Ground_P_Ane2Bias/1', 'wttl_set_P_Ane2Bias/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Ane2a
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Ane2a');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Ane2a');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Ane2a'));
		add_line(subsystem_LN,'Ground_P_Ane2a/1', 'wttl_set_P_Ane2a/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_MinGbxSpdWdSpdCal
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_MinGbxSpdWdSpdCal');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_MinGbxSpdWdSpdCal');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_MinGbxSpdWdSpdCal'));
		add_line(subsystem_LN,'Ground_P_MinGbxSpdWdSpdCal/1', 'wttl_set_P_MinGbxSpdWdSpdCal/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Van1Ofs
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Van1Ofs');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Van1Ofs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Van1Ofs'));
		add_line(subsystem_LN,'Ground_P_Van1Ofs/1', 'wttl_set_P_Van1Ofs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Van1RotOfs
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Van1RotOfs');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Van1RotOfs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Van1RotOfs'));
		add_line(subsystem_LN,'Ground_P_Van1RotOfs/1', 'wttl_set_P_Van1RotOfs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Van2Ofs
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Van2Ofs');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Van2Ofs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Van2Ofs'));
		add_line(subsystem_LN,'Ground_P_Van2Ofs/1', 'wttl_set_P_Van2Ofs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_Van2RotOfs
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_Van2RotOfs');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_Van2RotOfs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_Van2RotOfs'));
		add_line(subsystem_LN,'Ground_P_Van2RotOfs/1', 'wttl_set_P_Van2RotOfs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacExTmp1SensUpLim
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacExTmp1SensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp1SensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacExTmp1SensUpLim'));
		add_line(subsystem_LN,'Ground_P_NacExTmp1SensUpLim/1', 'wttl_set_P_NacExTmp1SensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacExTmp1SensLoLim
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacExTmp1SensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp1SensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacExTmp1SensLoLim'));
		add_line(subsystem_LN,'Ground_P_NacExTmp1SensLoLim/1', 'wttl_set_P_NacExTmp1SensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacExTmp2SensUpLim
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacExTmp2SensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp2SensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacExTmp2SensUpLim'));
		add_line(subsystem_LN,'Ground_P_NacExTmp2SensUpLim/1', 'wttl_set_P_NacExTmp2SensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacExTmp2SensLoLim
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacExTmp2SensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacExTmp2SensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacExTmp2SensLoLim'));
		add_line(subsystem_LN,'Ground_P_NacExTmp2SensLoLim/1', 'wttl_set_P_NacExTmp2SensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacTmpSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacTmpSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacTmpSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacTmpSensUpLim'));
		add_line(subsystem_LN,'Ground_P_NacTmpSensUpLim/1', 'wttl_set_P_NacTmpSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_NacTmpSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_NacTmpSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_NacTmpSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NacTmpSensLoLim'));
		add_line(subsystem_LN,'Ground_P_NacTmpSensLoLim/1', 'wttl_set_P_NacTmpSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WNAC/P_WdSpdChgSpdEvt60
		subsystem_LN = strcat(subsystem_out,'/WNAC');
		block        = strcat(subsystem_LN,'/wttl_set_P_WdSpdChgSpdEvt60');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WNAC','DO','P_WdSpdChgSpdEvt60');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_WdSpdChgSpdEvt60'));
		add_line(subsystem_LN,'Ground_P_WdSpdChgSpdEvt60/1', 'wttl_set_P_WdSpdChgSpdEvt60/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WNAC')
	
	
		% WYAW/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WYAW','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
		% WYAW/YwSt
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwSt');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WYAW','DO','YwSt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwSt'));
		add_line(subsystem_LN,'Ground_YwSt/1', 'wttl_set_YwSt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwBrakeSt
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwBrakeSt');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WYAW','DO','YwBrakeSt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwBrakeSt'));
		add_line(subsystem_LN,'Ground_YwBrakeSt/1', 'wttl_set_YwBrakeSt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwSpd
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwSpd');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WYAW','DO','YwSpd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwSpd'));
		add_line(subsystem_LN,'Ground_YwSpd/1', 'wttl_set_YwSpd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YawAng
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YawAng');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WYAW','DO','YawAng');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YawAng'));
		add_line(subsystem_LN,'Ground_YawAng/1', 'wttl_set_YawAng/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/CabWup
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_CabWup');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WYAW','DO','CabWup');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabWup'));
		add_line(subsystem_LN,'Ground_CabWup/1', 'wttl_set_CabWup/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwErr
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwErr');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WYAW','DO','YwErr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwErr'));
		add_line(subsystem_LN,'Ground_YwErr/1', 'wttl_set_YwErr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TwrBaseYwManCCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseYwManCCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','TwrBaseYwManCCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseYwManCCW'));
		add_line(subsystem_LN,'Ground_TwrBaseYwManCCW/1', 'wttl_set_TwrBaseYwManCCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TwrBaseYwManCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseYwManCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','TwrBaseYwManCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseYwManCW'));
		add_line(subsystem_LN,'Ground_TwrBaseYwManCW/1', 'wttl_set_TwrBaseYwManCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCEStopNacOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopNacOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','SLCEStopNacOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopNacOk'));
		add_line(subsystem_LN,'Ground_SLCEStopNacOk/1', 'wttl_set_SLCEStopNacOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCCabTwistedCWOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCCabTwistedCWOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','SLCCabTwistedCWOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCCabTwistedCWOk'));
		add_line(subsystem_LN,'Ground_SLCCabTwistedCWOk/1', 'wttl_set_SLCCabTwistedCWOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCCabTwistedCCWOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCCabTwistedCCWOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','SLCCabTwistedCCWOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCCabTwistedCCWOk'));
		add_line(subsystem_LN,'Ground_SLCCabTwistedCCWOk/1', 'wttl_set_SLCCabTwistedCCWOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwEnFdbk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwEnFdbk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','SLCYwEnFdbk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwEnFdbk'));
		add_line(subsystem_LN,'Ground_SLCYwEnFdbk/1', 'wttl_set_SLCYwEnFdbk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TopBoxYwManCCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxYwManCCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','TopBoxYwManCCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxYwManCCW'));
		add_line(subsystem_LN,'Ground_TopBoxYwManCCW/1', 'wttl_set_TopBoxYwManCCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TopBoxYwManCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxYwManCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','TopBoxYwManCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxYwManCW'));
		add_line(subsystem_LN,'Ground_TopBoxYwManCW/1', 'wttl_set_TopBoxYwManCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwDrvOff
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwDrvOff');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwDrvOff');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwDrvOff'));
		add_line(subsystem_LN,'Ground_YwDrvOff/1', 'wttl_set_YwDrvOff/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwEncCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwEncCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwEncCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwEncCW'));
		add_line(subsystem_LN,'Ground_YwEncCW/1', 'wttl_set_YwEncCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwEncCCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwEncCCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwEncCCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwEncCCW'));
		add_line(subsystem_LN,'Ground_YwEncCCW/1', 'wttl_set_YwEncCCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/NacPosNorth
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_NacPosNorth');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','NacPosNorth');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacPosNorth'));
		add_line(subsystem_LN,'Ground_NacPosNorth/1', 'wttl_set_NacPosNorth/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/CabTwistCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_CabTwistCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','CabTwistCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabTwistCW'));
		add_line(subsystem_LN,'Ground_CabTwistCW/1', 'wttl_set_CabTwistCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/CabTwistCCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_CabTwistCCW');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','CabTwistCCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabTwistCCW'));
		add_line(subsystem_LN,'Ground_CabTwistCCW/1', 'wttl_set_CabTwistCCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpOvlOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwLuPmpOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpOvlOk'));
		add_line(subsystem_LN,'Ground_YwLuPmpOvlOk/1', 'wttl_set_YwLuPmpOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwLuPmpOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpOk'));
		add_line(subsystem_LN,'Ground_YwLuPmpOk/1', 'wttl_set_YwLuPmpOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwMot1t2OvlOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwMot1t2OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwMot1t2OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwMot1t2OvlOk'));
		add_line(subsystem_LN,'Ground_YwMot1t2OvlOk/1', 'wttl_set_YwMot1t2OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwMot3t4OvlOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwMot3t4OvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwMot3t4OvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwMot3t4OvlOk'));
		add_line(subsystem_LN,'Ground_YwMot3t4OvlOk/1', 'wttl_set_YwMot3t4OvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwElecBrkOvlOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwElecBrkOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwElecBrkOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwElecBrkOvlOk'));
		add_line(subsystem_LN,'Ground_YwElecBrkOvlOk/1', 'wttl_set_YwElecBrkOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwBrkTmpOk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwBrkTmpOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwBrkTmpOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwBrkTmpOk'));
		add_line(subsystem_LN,'Ground_YwBrkTmpOk/1', 'wttl_set_YwBrkTmpOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpCysSw
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpCysSw');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WYAW','DO','YwLuPmpCysSw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpCysSw'));
		add_line(subsystem_LN,'Ground_YwLuPmpCysSw/1', 'wttl_set_YwLuPmpCysSw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwEn
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WYAW','DO','SLCYwEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwEn'));
		add_line(subsystem_LN,'Ground_SLCYwEn/1', 'wttl_set_SLCYwEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwDrvCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwDrvCW');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WYAW','DO','SLCYwDrvCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwDrvCW'));
		add_line(subsystem_LN,'Ground_SLCYwDrvCW/1', 'wttl_set_SLCYwDrvCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwDrvCCW
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwDrvCCW');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WYAW','DO','SLCYwDrvCCW');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwDrvCCW'));
		add_line(subsystem_LN,'Ground_SLCYwDrvCCW/1', 'wttl_set_SLCYwDrvCCW/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwElecBrk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwElecBrk');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WYAW','DO','SLCYwElecBrk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwElecBrk'));
		add_line(subsystem_LN,'Ground_SLCYwElecBrk/1', 'wttl_set_SLCYwElecBrk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwBrk
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwBrk');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WYAW','DO','SLCYwBrk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwBrk'));
		add_line(subsystem_LN,'Ground_SLCYwBrk/1', 'wttl_set_SLCYwBrk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwBrkResPres
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwBrkResPres');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WYAW','DO','SLCYwBrkResPres');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwBrkResPres'));
		add_line(subsystem_LN,'Ground_SLCYwBrkResPres/1', 'wttl_set_SLCYwBrkResPres/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpEn
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpEn');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WYAW','DO','YwLuPmpEn');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpEn'));
		add_line(subsystem_LN,'Ground_YwLuPmpEn/1', 'wttl_set_YwLuPmpEn/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwMotCur
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwMotCur');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WYAW','DO','YwMotCur');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwMotCur'));
		add_line(subsystem_LN,'Ground_YwMotCur/1', 'wttl_set_YwMotCur/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwMotCurRaw
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwMotCurRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WYAW','DO','YwMotCurRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwMotCurRaw'));
		add_line(subsystem_LN,'Ground_YwMotCurRaw/1', 'wttl_set_YwMotCurRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TwrBaseYwManCCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseYwManCCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','TwrBaseYwManCCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseYwManCCWFrc'));
		add_line(subsystem_LN,'Ground_TwrBaseYwManCCWFrc/1', 'wttl_set_TwrBaseYwManCCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TwrBaseYwManCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseYwManCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','TwrBaseYwManCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseYwManCWFrc'));
		add_line(subsystem_LN,'Ground_TwrBaseYwManCWFrc/1', 'wttl_set_TwrBaseYwManCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCEStopNacOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCEStopNacOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCEStopNacOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCEStopNacOkFrc'));
		add_line(subsystem_LN,'Ground_SLCEStopNacOkFrc/1', 'wttl_set_SLCEStopNacOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCCabTwistedCWOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCCabTwistedCWOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCCabTwistedCWOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCCabTwistedCWOkFrc'));
		add_line(subsystem_LN,'Ground_SLCCabTwistedCWOkFrc/1', 'wttl_set_SLCCabTwistedCWOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCCabTwistedCCWOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCCabTwistedCCWOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCCabTwistedCCWOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCCabTwistedCCWOkFrc'));
		add_line(subsystem_LN,'Ground_SLCCabTwistedCCWOkFrc/1', 'wttl_set_SLCCabTwistedCCWOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwEnFdbkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwEnFdbkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCYwEnFdbkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwEnFdbkFrc'));
		add_line(subsystem_LN,'Ground_SLCYwEnFdbkFrc/1', 'wttl_set_SLCYwEnFdbkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwEnFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCYwEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwEnFrc'));
		add_line(subsystem_LN,'Ground_SLCYwEnFrc/1', 'wttl_set_SLCYwEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwDrvCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwDrvCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCYwDrvCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwDrvCWFrc'));
		add_line(subsystem_LN,'Ground_SLCYwDrvCWFrc/1', 'wttl_set_SLCYwDrvCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwDrvCCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwDrvCCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCYwDrvCCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwDrvCCWFrc'));
		add_line(subsystem_LN,'Ground_SLCYwDrvCCWFrc/1', 'wttl_set_SLCYwDrvCCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwElecBrkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwElecBrkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCYwElecBrkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwElecBrkFrc'));
		add_line(subsystem_LN,'Ground_SLCYwElecBrkFrc/1', 'wttl_set_SLCYwElecBrkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwBrkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwBrkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCYwBrkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwBrkFrc'));
		add_line(subsystem_LN,'Ground_SLCYwBrkFrc/1', 'wttl_set_SLCYwBrkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/SLCYwBrkResPresFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_SLCYwBrkResPresFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','SLCYwBrkResPresFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_SLCYwBrkResPresFrc'));
		add_line(subsystem_LN,'Ground_SLCYwBrkResPresFrc/1', 'wttl_set_SLCYwBrkResPresFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TopBoxYwManCCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxYwManCCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','TopBoxYwManCCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxYwManCCWFrc'));
		add_line(subsystem_LN,'Ground_TopBoxYwManCCWFrc/1', 'wttl_set_TopBoxYwManCCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/TopBoxYwManCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_TopBoxYwManCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','TopBoxYwManCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TopBoxYwManCWFrc'));
		add_line(subsystem_LN,'Ground_TopBoxYwManCWFrc/1', 'wttl_set_TopBoxYwManCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwDrvOffFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwDrvOffFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwDrvOffFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwDrvOffFrc'));
		add_line(subsystem_LN,'Ground_YwDrvOffFrc/1', 'wttl_set_YwDrvOffFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwEncCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwEncCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwEncCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwEncCWFrc'));
		add_line(subsystem_LN,'Ground_YwEncCWFrc/1', 'wttl_set_YwEncCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwEncCCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwEncCCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwEncCCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwEncCCWFrc'));
		add_line(subsystem_LN,'Ground_YwEncCCWFrc/1', 'wttl_set_YwEncCCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/NacPosNorthFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_NacPosNorthFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','NacPosNorthFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NacPosNorthFrc'));
		add_line(subsystem_LN,'Ground_NacPosNorthFrc/1', 'wttl_set_NacPosNorthFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/CabTwistCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_CabTwistCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','CabTwistCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabTwistCWFrc'));
		add_line(subsystem_LN,'Ground_CabTwistCWFrc/1', 'wttl_set_CabTwistCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/CabTwistCCWFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_CabTwistCCWFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','CabTwistCCWFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_CabTwistCCWFrc'));
		add_line(subsystem_LN,'Ground_CabTwistCCWFrc/1', 'wttl_set_CabTwistCCWFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpOvlOkFrc'));
		add_line(subsystem_LN,'Ground_YwLuPmpOvlOkFrc/1', 'wttl_set_YwLuPmpOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpOkFrc'));
		add_line(subsystem_LN,'Ground_YwLuPmpOkFrc/1', 'wttl_set_YwLuPmpOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwMot1t2OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwMot1t2OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwMot1t2OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwMot1t2OvlOkFrc'));
		add_line(subsystem_LN,'Ground_YwMot1t2OvlOkFrc/1', 'wttl_set_YwMot1t2OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwMot3t4OvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwMot3t4OvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwMot3t4OvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwMot3t4OvlOkFrc'));
		add_line(subsystem_LN,'Ground_YwMot3t4OvlOkFrc/1', 'wttl_set_YwMot3t4OvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwElecBrkOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwElecBrkOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwElecBrkOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwElecBrkOvlOkFrc'));
		add_line(subsystem_LN,'Ground_YwElecBrkOvlOkFrc/1', 'wttl_set_YwElecBrkOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwBrkTmpOkFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwBrkTmpOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwBrkTmpOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwBrkTmpOkFrc'));
		add_line(subsystem_LN,'Ground_YwBrkTmpOkFrc/1', 'wttl_set_YwBrkTmpOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpCysSwFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpCysSwFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpCysSwFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpCysSwFrc'));
		add_line(subsystem_LN,'Ground_YwLuPmpCysSwFrc/1', 'wttl_set_YwLuPmpCysSwFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLuPmpEnFrc
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLuPmpEnFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','YwLuPmpEnFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLuPmpEnFrc'));
		add_line(subsystem_LN,'Ground_YwLuPmpEnFrc/1', 'wttl_set_YwLuPmpEnFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/P_YwMaxCntFlt
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_P_YwMaxCntFlt');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','P_YwMaxCntFlt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_YwMaxCntFlt'));
		add_line(subsystem_LN,'Ground_P_YwMaxCntFlt/1', 'wttl_set_P_YwMaxCntFlt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/P_YwCogNum
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_P_YwCogNum');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','P_YwCogNum');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_YwCogNum'));
		add_line(subsystem_LN,'Ground_P_YwCogNum/1', 'wttl_set_P_YwCogNum/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/P_YwZeroOfs
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_P_YwZeroOfs');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','P_YwZeroOfs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_YwZeroOfs'));
		add_line(subsystem_LN,'Ground_P_YwZeroOfs/1', 'wttl_set_P_YwZeroOfs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/P_NoYwSpdDl
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_P_NoYwSpdDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','P_NoYwSpdDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_NoYwSpdDl'));
		add_line(subsystem_LN,'Ground_P_NoYwSpdDl/1', 'wttl_set_P_NoYwSpdDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/P_SensFltDl
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_P_SensFltDl');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WYAW','DO','P_SensFltDl');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_SensFltDl'));
		add_line(subsystem_LN,'Ground_P_SensFltDl/1', 'wttl_set_P_SensFltDl/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WYAW/YwLev
		subsystem_LN = strcat(subsystem_out,'/WYAW');
		block        = strcat(subsystem_LN,'/wttl_set_YwLev');
		
		add_block(lib_wttl_set,block,'CDC','STV','LN','WYAW','DO','YwLev');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_YwLev'));
		add_line(subsystem_LN,'Ground_YwLev/1', 'wttl_set_YwLev/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WYAW')
	
	
		% WTOW/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WTOW','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
		% WTOW/TwrAcc2EFX
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAcc2EFX');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFX');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAcc2EFX'));
		add_line(subsystem_LN,'Ground_TwrAcc2EFX/1', 'wttl_set_TwrAcc2EFX/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAcc2EFXAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAcc2EFXAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFXAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAcc2EFXAbs'));
		add_line(subsystem_LN,'Ground_TwrAcc2EFXAbs/1', 'wttl_set_TwrAcc2EFXAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAcc2EFY
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAcc2EFY');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFY');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAcc2EFY'));
		add_line(subsystem_LN,'Ground_TwrAcc2EFY/1', 'wttl_set_TwrAcc2EFY/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAcc2EFYAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAcc2EFYAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFYAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAcc2EFYAbs'));
		add_line(subsystem_LN,'Ground_TwrAcc2EFYAbs/1', 'wttl_set_TwrAcc2EFYAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX1Abs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX1Abs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX1Abs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX1Abs'));
		add_line(subsystem_LN,'Ground_TwrAccX1Abs/1', 'wttl_set_TwrAccX1Abs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX1HiPassFilt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX1HiPassFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX1HiPassFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX1HiPassFilt'));
		add_line(subsystem_LN,'Ground_TwrAccX1HiPassFilt/1', 'wttl_set_TwrAccX1HiPassFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX1LoPassFilt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX1LoPassFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX1LoPassFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX1LoPassFilt'));
		add_line(subsystem_LN,'Ground_TwrAccX1LoPassFilt/1', 'wttl_set_TwrAccX1LoPassFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX1LoPassFiltAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX1LoPassFiltAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX1LoPassFiltAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX1LoPassFiltAbs'));
		add_line(subsystem_LN,'Ground_TwrAccX1LoPassFiltAbs/1', 'wttl_set_TwrAccX1LoPassFiltAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX1Pk
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX1Pk');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX1Pk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX1Pk'));
		add_line(subsystem_LN,'Ground_TwrAccX1Pk/1', 'wttl_set_TwrAccX1Pk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX2Abs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX2Abs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX2Abs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX2Abs'));
		add_line(subsystem_LN,'Ground_TwrAccX2Abs/1', 'wttl_set_TwrAccX2Abs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX2HiPassFilt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX2HiPassFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX2HiPassFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX2HiPassFilt'));
		add_line(subsystem_LN,'Ground_TwrAccX2HiPassFilt/1', 'wttl_set_TwrAccX2HiPassFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrHiPassFiltAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrHiPassFiltAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrHiPassFiltAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrHiPassFiltAbs'));
		add_line(subsystem_LN,'Ground_TwrHiPassFiltAbs/1', 'wttl_set_TwrHiPassFiltAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrLoPassFilt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrLoPassFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrLoPassFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrLoPassFilt'));
		add_line(subsystem_LN,'Ground_TwrLoPassFilt/1', 'wttl_set_TwrLoPassFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrLoPassFiltAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrLoPassFiltAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrLoPassFiltAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrLoPassFiltAbs'));
		add_line(subsystem_LN,'Ground_TwrLoPassFiltAbs/1', 'wttl_set_TwrLoPassFiltAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX23P
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX23P');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX23P');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX23P'));
		add_line(subsystem_LN,'Ground_TwrAccX23P/1', 'wttl_set_TwrAccX23P/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX23PAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX23PAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX23PAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX23PAbs'));
		add_line(subsystem_LN,'Ground_TwrAccX23PAbs/1', 'wttl_set_TwrAccX23PAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX2nP
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX2nP');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX2nP');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX2nP'));
		add_line(subsystem_LN,'Ground_TwrAccX2nP/1', 'wttl_set_TwrAccX2nP/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX2nPAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX2nPAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX2nPAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX2nPAbs'));
		add_line(subsystem_LN,'Ground_TwrAccX2nPAbs/1', 'wttl_set_TwrAccX2nPAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY1Abs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY1Abs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY1Abs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY1Abs'));
		add_line(subsystem_LN,'Ground_TwrAccY1Abs/1', 'wttl_set_TwrAccY1Abs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY1HiPassFilt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY1HiPassFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY1HiPassFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY1HiPassFilt'));
		add_line(subsystem_LN,'Ground_TwrAccY1HiPassFilt/1', 'wttl_set_TwrAccY1HiPassFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY1LoPassFilt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY1LoPassFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY1LoPassFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY1LoPassFilt'));
		add_line(subsystem_LN,'Ground_TwrAccY1LoPassFilt/1', 'wttl_set_TwrAccY1LoPassFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY1LoPassFiltAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY1LoPassFiltAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY1LoPassFiltAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY1LoPassFiltAbs'));
		add_line(subsystem_LN,'Ground_TwrAccY1LoPassFiltAbs/1', 'wttl_set_TwrAccY1LoPassFiltAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY1Pk
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY1Pk');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY1Pk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY1Pk'));
		add_line(subsystem_LN,'Ground_TwrAccY1Pk/1', 'wttl_set_TwrAccY1Pk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY2Abs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY2Abs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY2Abs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY2Abs'));
		add_line(subsystem_LN,'Ground_TwrAccY2Abs/1', 'wttl_set_TwrAccY2Abs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY2HiPassFilt
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY2HiPassFilt');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY2HiPassFilt');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY2HiPassFilt'));
		add_line(subsystem_LN,'Ground_TwrAccY2HiPassFilt/1', 'wttl_set_TwrAccY2HiPassFilt/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY23P
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY23P');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY23P');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY23P'));
		add_line(subsystem_LN,'Ground_TwrAccY23P/1', 'wttl_set_TwrAccY23P/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY23PAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY23PAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY23PAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY23PAbs'));
		add_line(subsystem_LN,'Ground_TwrAccY23PAbs/1', 'wttl_set_TwrAccY23PAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY2nP
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY2nP');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY2nP');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY2nP'));
		add_line(subsystem_LN,'Ground_TwrAccY2nP/1', 'wttl_set_TwrAccY2nP/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY2nPAbs
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY2nPAbs');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY2nPAbs');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY2nPAbs'));
		add_line(subsystem_LN,'Ground_TwrAccY2nPAbs/1', 'wttl_set_TwrAccY2nPAbs/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAcc2EFXRaw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAcc2EFXRaw');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFXRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAcc2EFXRaw'));
		add_line(subsystem_LN,'Ground_TwrAcc2EFXRaw/1', 'wttl_set_TwrAcc2EFXRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAcc2EFYRaw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAcc2EFYRaw');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAcc2EFYRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAcc2EFYRaw'));
		add_line(subsystem_LN,'Ground_TwrAcc2EFYRaw/1', 'wttl_set_TwrAcc2EFYRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrFanOk
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrFanOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','TwrFanOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrFanOk'));
		add_line(subsystem_LN,'Ground_TwrFanOk/1', 'wttl_set_TwrFanOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/NoPersTwrBase
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_NoPersTwrBase');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','NoPersTwrBase');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NoPersTwrBase'));
		add_line(subsystem_LN,'Ground_NoPersTwrBase/1', 'wttl_set_NoPersTwrBase/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrDoorClsd
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrDoorClsd');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','TwrDoorClsd');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrDoorClsd'));
		add_line(subsystem_LN,'Ground_TwrDoorClsd/1', 'wttl_set_TwrDoorClsd/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrFanOvlOk
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrFanOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','TwrFanOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrFanOvlOk'));
		add_line(subsystem_LN,'Ground_TwrFanOvlOk/1', 'wttl_set_TwrFanOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseNoSmkAlm
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseNoSmkAlm');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','TwrBaseNoSmkAlm');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseNoSmkAlm'));
		add_line(subsystem_LN,'Ground_TwrBaseNoSmkAlm/1', 'wttl_set_TwrBaseNoSmkAlm/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrExtrFanOk
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrExtrFanOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','TwrExtrFanOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrExtrFanOk'));
		add_line(subsystem_LN,'Ground_TwrExtrFanOk/1', 'wttl_set_TwrExtrFanOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrExtrFanOvlOk
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrExtrFanOvlOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','TwrExtrFanOvlOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrExtrFanOvlOk'));
		add_line(subsystem_LN,'Ground_TwrExtrFanOvlOk/1', 'wttl_set_TwrExtrFanOvlOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/OscillSensOk
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_OscillSensOk');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','OscillSensOk');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_OscillSensOk'));
		add_line(subsystem_LN,'Ground_OscillSensOk/1', 'wttl_set_OscillSensOk/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrVbr
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrVbr');
		
		add_block(lib_wttl_set,block,'CDC','SPS','LN','WTOW','DO','TwrVbr');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrVbr'));
		add_line(subsystem_LN,'Ground_TwrVbr/1', 'wttl_set_TwrVbr/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseTmpEx
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseTmpEx');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrBaseTmpEx');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseTmpEx'));
		add_line(subsystem_LN,'Ground_TwrBaseTmpEx/1', 'wttl_set_TwrBaseTmpEx/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseTmp
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseTmp');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrBaseTmp');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseTmp'));
		add_line(subsystem_LN,'Ground_TwrBaseTmp/1', 'wttl_set_TwrBaseTmp/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseRelHum
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseRelHum');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrBaseRelHum');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseRelHum'));
		add_line(subsystem_LN,'Ground_TwrBaseRelHum/1', 'wttl_set_TwrBaseRelHum/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY1
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY1');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY1'));
		add_line(subsystem_LN,'Ground_TwrAccY1/1', 'wttl_set_TwrAccY1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX1
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX1');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX1');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX1'));
		add_line(subsystem_LN,'Ground_TwrAccX1/1', 'wttl_set_TwrAccX1/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY2
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccY2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY2'));
		add_line(subsystem_LN,'Ground_TwrAccY2/1', 'wttl_set_TwrAccY2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX2
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX2');
		
		add_block(lib_wttl_set,block,'CDC','MV','LN','WTOW','DO','TwrAccX2');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX2'));
		add_line(subsystem_LN,'Ground_TwrAccX2/1', 'wttl_set_TwrAccX2/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseTmpExRaw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseTmpExRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTOW','DO','TwrBaseTmpExRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseTmpExRaw'));
		add_line(subsystem_LN,'Ground_TwrBaseTmpExRaw/1', 'wttl_set_TwrBaseTmpExRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseTmpRaw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseTmpRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTOW','DO','TwrBaseTmpRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseTmpRaw'));
		add_line(subsystem_LN,'Ground_TwrBaseTmpRaw/1', 'wttl_set_TwrBaseTmpRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseRelHumRaw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseRelHumRaw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTOW','DO','TwrBaseRelHumRaw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseRelHumRaw'));
		add_line(subsystem_LN,'Ground_TwrBaseRelHumRaw/1', 'wttl_set_TwrBaseRelHumRaw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY1Raw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY1Raw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTOW','DO','TwrAccY1Raw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY1Raw'));
		add_line(subsystem_LN,'Ground_TwrAccY1Raw/1', 'wttl_set_TwrAccY1Raw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX1Raw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX1Raw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTOW','DO','TwrAccX1Raw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX1Raw'));
		add_line(subsystem_LN,'Ground_TwrAccX1Raw/1', 'wttl_set_TwrAccX1Raw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccY2Raw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccY2Raw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTOW','DO','TwrAccY2Raw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccY2Raw'));
		add_line(subsystem_LN,'Ground_TwrAccY2Raw/1', 'wttl_set_TwrAccY2Raw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrAccX2Raw
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrAccX2Raw');
		
		add_block(lib_wttl_set,block,'CDC','INS','LN','WTOW','DO','TwrAccX2Raw');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrAccX2Raw'));
		add_line(subsystem_LN,'Ground_TwrAccX2Raw/1', 'wttl_set_TwrAccX2Raw/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TestVibrSens
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TestVibrSens');
		
		add_block(lib_wttl_set,block,'CDC','SPC','LN','WTOW','DO','TestVibrSens');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TestVibrSens'));
		add_line(subsystem_LN,'Ground_TestVibrSens/1', 'wttl_set_TestVibrSens/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrFanOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrFanOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TwrFanOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrFanOkFrc'));
		add_line(subsystem_LN,'Ground_TwrFanOkFrc/1', 'wttl_set_TwrFanOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/NoPersTwrBaseFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_NoPersTwrBaseFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','NoPersTwrBaseFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_NoPersTwrBaseFrc'));
		add_line(subsystem_LN,'Ground_NoPersTwrBaseFrc/1', 'wttl_set_NoPersTwrBaseFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrDoorClsdFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrDoorClsdFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TwrDoorClsdFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrDoorClsdFrc'));
		add_line(subsystem_LN,'Ground_TwrDoorClsdFrc/1', 'wttl_set_TwrDoorClsdFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrFanOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrFanOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TwrFanOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrFanOvlOkFrc'));
		add_line(subsystem_LN,'Ground_TwrFanOvlOkFrc/1', 'wttl_set_TwrFanOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrBaseNoSmkAlmFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrBaseNoSmkAlmFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TwrBaseNoSmkAlmFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrBaseNoSmkAlmFrc'));
		add_line(subsystem_LN,'Ground_TwrBaseNoSmkAlmFrc/1', 'wttl_set_TwrBaseNoSmkAlmFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrExtrFanOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrExtrFanOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TwrExtrFanOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrExtrFanOkFrc'));
		add_line(subsystem_LN,'Ground_TwrExtrFanOkFrc/1', 'wttl_set_TwrExtrFanOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrExtrFanOvlOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrExtrFanOvlOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TwrExtrFanOvlOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrExtrFanOvlOkFrc'));
		add_line(subsystem_LN,'Ground_TwrExtrFanOvlOkFrc/1', 'wttl_set_TwrExtrFanOvlOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TestVibrSensFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TestVibrSensFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TestVibrSensFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TestVibrSensFrc'));
		add_line(subsystem_LN,'Ground_TestVibrSensFrc/1', 'wttl_set_TestVibrSensFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/OscillSensOkFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_OscillSensOkFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','OscillSensOkFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_OscillSensOkFrc'));
		add_line(subsystem_LN,'Ground_OscillSensOkFrc/1', 'wttl_set_OscillSensOkFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/TwrVbrFrc
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_TwrVbrFrc');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','TwrVbrFrc');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_TwrVbrFrc'));
		add_line(subsystem_LN,'Ground_TwrVbrFrc/1', 'wttl_set_TwrVbrFrc/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrBaseTmpSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrBaseTmpSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrBaseTmpSensUpLim'));
		add_line(subsystem_LN,'Ground_P_TwrBaseTmpSensUpLim/1', 'wttl_set_P_TwrBaseTmpSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrBaseTmpSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrBaseTmpSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrBaseTmpSensLoLim'));
		add_line(subsystem_LN,'Ground_P_TwrBaseTmpSensLoLim/1', 'wttl_set_P_TwrBaseTmpSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_RotBrkPresSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_RotBrkPresSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_RotBrkPresSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_RotBrkPresSensUpLim'));
		add_line(subsystem_LN,'Ground_P_RotBrkPresSensUpLim/1', 'wttl_set_P_RotBrkPresSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_RotBrkPresSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_RotBrkPresSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_RotBrkPresSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_RotBrkPresSensLoLim'));
		add_line(subsystem_LN,'Ground_P_RotBrkPresSensLoLim/1', 'wttl_set_P_RotBrkPresSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrBaseTmpExSensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrBaseTmpExSensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpExSensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrBaseTmpExSensUpLim'));
		add_line(subsystem_LN,'Ground_P_TwrBaseTmpExSensUpLim/1', 'wttl_set_P_TwrBaseTmpExSensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrBaseTmpExSensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrBaseTmpExSensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrBaseTmpExSensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrBaseTmpExSensLoLim'));
		add_line(subsystem_LN,'Ground_P_TwrBaseTmpExSensLoLim/1', 'wttl_set_P_TwrBaseTmpExSensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrEigFreq
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrEigFreq');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrEigFreq');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrEigFreq'));
		add_line(subsystem_LN,'Ground_P_TwrEigFreq/1', 'wttl_set_P_TwrEigFreq/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccBandPassFiltGain
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccBandPassFiltGain');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccBandPassFiltGain');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccBandPassFiltGain'));
		add_line(subsystem_LN,'Ground_P_TwrAccBandPassFiltGain/1', 'wttl_set_P_TwrAccBandPassFiltGain/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccBandPassFiltCutOffFrq
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccBandPassFiltCutOffFrq');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccBandPassFiltCutOffFrq');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccBandPassFiltCutOffFrq'));
		add_line(subsystem_LN,'Ground_P_TwrAccBandPassFiltCutOffFrq/1', 'wttl_set_P_TwrAccBandPassFiltCutOffFrq/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccBandPassFiltShapeFact
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccBandPassFiltShapeFact');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccBandPassFiltShapeFact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccBandPassFiltShapeFact'));
		add_line(subsystem_LN,'Ground_P_TwrAccBandPassFiltShapeFact/1', 'wttl_set_P_TwrAccBandPassFiltShapeFact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccX1SensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccX1SensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX1SensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccX1SensUpLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccX1SensUpLim/1', 'wttl_set_P_TwrAccX1SensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccX1SensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccX1SensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX1SensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccX1SensLoLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccX1SensLoLim/1', 'wttl_set_P_TwrAccX1SensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccX2SensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccX2SensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX2SensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccX2SensUpLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccX2SensUpLim/1', 'wttl_set_P_TwrAccX2SensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccX2SensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccX2SensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccX2SensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccX2SensLoLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccX2SensLoLim/1', 'wttl_set_P_TwrAccX2SensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccY1SensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccY1SensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY1SensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccY1SensUpLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccY1SensUpLim/1', 'wttl_set_P_TwrAccY1SensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccY1SensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccY1SensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY1SensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccY1SensLoLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccY1SensLoLim/1', 'wttl_set_P_TwrAccY1SensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccY2SensUpLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccY2SensUpLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY2SensUpLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccY2SensUpLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccY2SensUpLim/1', 'wttl_set_P_TwrAccY2SensUpLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_TwrAccY2SensLoLim
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_TwrAccY2SensLoLim');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_TwrAccY2SensLoLim');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_TwrAccY2SensLoLim'));
		add_line(subsystem_LN,'Ground_P_TwrAccY2SensLoLim/1', 'wttl_set_P_TwrAccY2SensLoLim/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_nPFiltShapeFact
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_nPFiltShapeFact');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_nPFiltShapeFact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_nPFiltShapeFact'));
		add_line(subsystem_LN,'Ground_P_nPFiltShapeFact/1', 'wttl_set_P_nPFiltShapeFact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_nPFiltFact
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_nPFiltFact');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_nPFiltFact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_nPFiltFact'));
		add_line(subsystem_LN,'Ground_P_nPFiltFact/1', 'wttl_set_P_nPFiltFact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WTOW/P_3PFiltShapeFact
		subsystem_LN = strcat(subsystem_out,'/WTOW');
		block        = strcat(subsystem_LN,'/wttl_set_P_3PFiltShapeFact');
		
		add_block(lib_wttl_set,block,'CDC','SPV','LN','WTOW','DO','P_3PFiltShapeFact');
		
		add_block('simulink/Sources/Ground',strcat(subsystem_LN,'/Ground_P_3PFiltShapeFact'));
		add_line(subsystem_LN,'Ground_P_3PFiltShapeFact/1', 'wttl_set_P_3PFiltShapeFact/1');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WTOW')
	
	
		% WALM/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WALM');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WALM','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WALM')
	
		% WSLG/NamPlt
		subsystem_LN = strcat(subsystem_out,'/WSLG');
		block        = strcat(subsystem_LN,'/wttl_set_NamPlt');
		
		add_block(lib_wttl_set,block,'CDC','LPL','LN','WSLG','DO','NamPlt');
		
		Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output/WSLG')

	%% Sort model
	Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic')
	Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/input')
	Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/simulation')
	Simulink.BlockDiagram.arrangeSystem('wtt_test_automatic/output')
