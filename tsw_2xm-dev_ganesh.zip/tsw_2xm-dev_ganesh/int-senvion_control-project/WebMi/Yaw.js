var variables = [
	["Max Count for Azimuth Error",	pre + "WYAW1.P_YwMaxCntFlt.actVal.mxVal.f",	pre + "WYAW1.P_YwMaxCntFlt.actVal.ctlVal.f",	pre + "WYAW1.P_YwMaxCntFlt.maxVal.f",	pre + "WYAW1.P_YwMaxCntFlt.minVal.f","","",""],
	["Number of cogs of azimuth rim",	pre + "WYAW1.P_YwCogNum.actVal.mxVal.f",	pre + "WYAW1.P_YwCogNum.actVal.ctlVal.f",	pre + "WYAW1.P_YwCogNum.maxVal.f",	pre + "WYAW1.P_YwCogNum.minVal.f","","",""],
	["Yaw Zero Position Offset",	pre + "WYAW1.P_YwZeroOfs.actVal.mxVal.f",	pre + "WYAW1.P_YwZeroOfs.actVal.ctlVal.f",	pre + "WYAW1.P_YwZeroOfs.maxVal.f",	pre + "WYAW1.P_YwZeroOfs.minVal.f","","",""],
	["Delay Time Set Yaw Speed to Zero",	pre + "WYAW1.P_NoYwSpdDl.actVal.mxVal.f",	pre + "WYAW1.P_NoYwSpdDl.actVal.ctlVal.f",	pre + "WYAW1.P_NoYwSpdDl.maxVal.f",	pre + "WYAW1.P_NoYwSpdDl.minVal.f","","",""],
	["Delay for Temperature Sensor Fault",	pre + "WYAW1.P_SensFltDl.actVal.mxVal.f",	pre + "WYAW1.P_SensFltDl.actVal.ctlVal.f",	pre + "WYAW1.P_SensFltDl.maxVal.f",	pre + "WYAW1.P_SensFltDl.minVal.f","","","s"],
];