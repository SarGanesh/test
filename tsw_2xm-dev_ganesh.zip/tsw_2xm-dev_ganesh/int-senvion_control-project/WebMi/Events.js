var EVENT_CONFIGURATION = [
	[
		"WCNV Frequency converter not ready",
		"1000",
		"ERROR"
	],
	[
		"WTRM Conv fuse tripped",
		"1001",
		"WARNING"
	],
	[
		"WCNV Conv comm error",
		"1002",
		"ERROR"
	],
	[
		"WCNV Conv SDO transm error",
		"1003",
		"WARNING"
	],
	[
		"WCNV Chopper util incr",
		"1004",
		"WARNING"
	],
	[
		"WTRM Max chopper util",
		"1005",
		"ERROR"
	],
	[
		"WCNV Conv warning",
		"1006",
		"WARNING"
	],
	[
		"WCNV Conv reset after grid restoration",
		"1007",
		"INFO"
	],
	[
		"WCNV Freq conv speed window",
		"1008",
		"ERROR"
	],
	[
		"WCNV Conv emerg off type A",
		"1009",
		"ERROR"
	],
	[
		"WCNV Conv emerg off type B",
		"1010",
		"ERROR"
	],
	[
		"WCNV Conv emerg off type C",
		"1011",
		"ERROR"
	],
	[
		"WCNV Conv emerg off type D",
		"1012",
		"ERROR"
	],
	[
		"WCNV Conv emerg off type E",
		"1013",
		"ERROR"
	],
	[
		"WCNV Conv emerg off type F",
		"1014",
		"ERROR"
	],
	[
		"WTRM Frequency converter spare protection",
		"1015",
		"ERROR"
	],
	[
		"WCNV Error converter disconnection",
		"1016",
		"ERROR"
	],
	[
		"WCNV Converter disconnection implausible",
		"1017",
		"ERROR"
	],
	[
		"WCNV Max negative active power",
		"1018",
		"ERROR"
	],
	[
		"WCNV Frequency converter error",
		"1019",
		"ERROR"
	],
	[
		"WCNV Frequency converter overspeed",
		"1020",
		"ERROR"
	],
	[
		"WCNV Conv underspeed",
		"1021",
		"ERROR"
	],
	[
		"WCNV Timeout ready for connection",
		"1022",
		"ERROR"
	],
	[
		"WCNV Timeout grid synchronisation",
		"1023",
		"ERROR"
	],
	[
		"WCNV Frequency converter operation range",
		"1024",
		"ERROR"
	],
	[
		"WCNV Cable overload",
		"1025",
		"WARNING"
	],
	[
		"WCNV P reduction power cord overl",
		"1026",
		"INFO"
	],
	[
		"WCNV Cable overload stop",
		"1027",
		"ERROR"
	],
	[
		"WCNV P reduction stator cable overl",
		"1028",
		"INFO"
	],
	[
		"WCNV Frequency converter temp low",
		"1029",
		"INFO"
	],
	[
		"WCNV Bypass conv heating mode",
		"1030",
		"INFO"
	],
	[
		"WCNV Timeout converter temp low",
		"1031",
		"ERROR"
	],
	[
		"WCNV Frequency converter load rejection",
		"1032",
		"ERROR"
	],
	[
		"WCNV Conv load shedding CAN ",
		"1033",
		"ERROR"
	],
	[
		"WCNV Reduced power converter",
		"1034",
		"WARNING"
	],
	[
		"WCNV Timeout reduced power conv",
		"1035",
		"ERROR"
	],
	[
		"WCNV Limit reactive power converter",
		"1036",
		"WARNING"
	],
	[
		"WCNV Timeout Q limit converter",
		"1037",
		"WARNING"
	],
	[
		"WCNV No power",
		"1038",
		"ERROR"
	],
	[
		"WCNV Converter power too high",
		"1039",
		"WARNING"
	],
	[
		"WCNV Converter power too low",
		"1040",
		"WARNING"
	],
	[
		"WCNV Converter torque setpoint",
		"1041",
		"WARNING"
	],
	[
		"WCNV Calculated torque implausible",
		"1042",
		"ERROR"
	],
	[
		"WCNV Converter torque monitor level 0",
		"1043",
		"INFO"
	],
	[
		"WCNV Converter torque monitor level 1",
		"1044",
		"ERROR"
	],
	[
		"WCNV Conv COM mode active",
		"1045",
		"INFO"
	],
	[
		"WCNV Conv COM mode stop",
		"1046",
		"INFO"
	],
	[
		"WCNV No pressure increase following pump start up",
		"1047",
		"WARNING"
	],
	[
		"WCNV Timeout no pressure increase following pump start up",
		"1048",
		"WARNING"
	],
	[
		"WCNV No temp rise after heat coolant on",
		"1049",
		"WARNING"
	],
	[
		"WTRM Pump cooling sys tower base diff press low",
		"1050",
		"WARNING"
	],
	[
		"WCNV Pump cooling sys tower base diff press too low",
		"1051",
		"ERROR"
	],
	[
		"WCNV Pump cooling sys tower base diff press high",
		"1052",
		"WARNING"
	],
	[
		"WCNV Pump cooling sys tower base diff press too high",
		"1053",
		"ERROR"
	],
	[
		"WCNV Implaus act in conv cooling system",
		"1054",
		"WARNING"
	],
	[
		"WTRM Fan 1 cool sys error",
		"1055",
		"WARNING"
	],
	[
		"WCNV Fan 2 cool sys error",
		"1056",
		"WARNING"
	],
	[
		"WCNV Fan 3 cool sys error",
		"1057",
		"WARNING"
	],
	[
		"WCNV Fan 4 cool sys error",
		"1058",
		"WARNING"
	],
	[
		"WCNV Coolant press low",
		"1059",
		"WARNING"
	],
	[
		"WCNV Coolant press too low",
		"1060",
		"WARNING"
	],
	[
		"WCNV Cool sys press switch tripped",
		"1061",
		"WARNING"
	],
	[
		"WCNV Coolant press high with pump on ",
		"1062",
		"WARNING"
	],
	[
		"WCNV Coolant pressure too high with pump on ",
		"1063",
		"WARNING"
	],
	[
		"WCNV Coolant press high with pump off ",
		"1064",
		"WARNING"
	],
	[
		"WTRM Coolant press too high with pump off ",
		"1065",
		"WARNING"
	],
	[
		"WCNV 4 20mA coolant press",
		"1066",
		"WARNING"
	],
	[
		"WCNV Pump coolant inlet press 4 20mA",
		"1067",
		"WARNING"
	],
	[
		"WCNV Coolant temp high",
		"1068",
		"WARNING"
	],
	[
		"WCNV P red incr conv coolant temp",
		"1069",
		"WARNING"
	],
	[
		"WTRM Coolant temp too high",
		"1070",
		"WARNING"
	],
	[
		"WCNV Conv max coolant temp",
		"1071",
		"ERROR"
	],
	[
		"WCNV 4 20mA coolant temp",
		"1072",
		"WARNING"
	],
	[
		"WCNV Pump cooling sys overload",
		"1073",
		"ERROR"
	],
	[
		"WCNV Coolant heating 1 2 overload",
		"1074",
		"WARNING"
	],
	[
		"WCNV Heating overload fans 1 4 cooling sys",
		"1075",
		"WARNING"
	],
	[
		"WTRM Grid loss auxiliary power",
		"1200",
		"INFO"
	],
	[
		"WCNV Grid loss auxiliary power without grid loss net",
		"1201",
		"ERROR"
	],
	[
		"WCNV Grid loss without grid loss auxiliary power",
		"1202",
		"WARNING"
	],
	[
		"WCNV Grid loss",
		"1203",
		"INFO"
	],
	[
		"WCNV Grid disconnection for self protection",
		"1204",
		"INFO"
	],
	[
		"WCNV Timeout grid error",
		"1205",
		"ERROR"
	],
	[
		"WCNV Zero seq syst volt high",
		"1206",
		"INFO"
	],
	[
		"WCNV High voltage level 1",
		"1207",
		"INFO"
	],
	[
		"WCNV High voltage level 2",
		"1208",
		"INFO"
	],
	[
		"WCNV Min voltage cut in",
		"1209",
		"INFO"
	],
	[
		"WTRM Max voltage cut in",
		"1210",
		"INFO"
	],
	[
		"WCNV Repeat voltage dip",
		"1211",
		"INFO"
	],
	[
		"WCNV Low voltage level 1",
		"1212",
		"INFO"
	],
	[
		"WCNV Low voltage level 2",
		"1213",
		"INFO"
	],
	[
		"WCNV Transient fault",
		"1214",
		"INFO"
	],
	[
		"WTRM High frequency level 1",
		"1215",
		"INFO"
	],
	[
		"WTRM High frequency level 2",
		"1216",
		"INFO"
	],
	[
		"WCNV Max frequency cut in",
		"1217",
		"INFO"
	],
	[
		"WCNV High frequency P reduction",
		"1218",
		"INFO"
	],
	[
		"WCNV Time limit high freq P red",
		"1219",
		"INFO"
	],
	[
		"WCNV Low frequency Level 1",
		"1220",
		"INFO"
	],
	[
		"WCNV Low frequency level 2",
		"1221",
		"INFO"
	],
	[
		"WCNV Overfrequency",
		"1222",
		"INFO"
	],
	[
		"WCNV Phase anglee",
		"1223",
		"INFO"
	],
	[
		"WCNV Left rotating electrical field",
		"1224",
		"INFO"
	],
	[
		"WCNV Current asymmetry",
		"1225",
		"ERROR"
	],
	[
		"WCNV Voltage asymmetry",
		"1226",
		"ERROR"
	],
	[
		"WCNV Timeout max freq cut in",
		"1227",
		"INFO"
	],
	[
		"WCNV Grid error",
		"1228",
		"INFO"
	],
	[
		"WCNV Low frequency level 3",
		"1229",
		"INFO"
	],
	[
		"WCNV Low frequency level 4",
		"1230",
		"INFO"
	],
	[
		"WCNV Low frequency level 5",
		"1231",
		"INFO"
	],
	[
		"WCNV Low frequency level 6",
		"1232",
		"INFO"
	],
	[
		"WCNV Minimum grid frequency",
		"1233",
		"INFO"
	],
	[
		"WCNV Min frequency cut in",
		"1234",
		"INFO"
	],
	[
		"WCNV Underfrequency",
		"1235",
		"INFO"
	],
	[
		"WCNV High frequency level 3",
		"1236",
		"INFO"
	],
	[
		"WCNV High frequency level 4",
		"1237",
		"INFO"
	],
	[
		"WCNV High frequency level 5",
		"1238",
		"INFO"
	],
	[
		"WCNV High frequency level 6",
		"1239",
		"INFO"
	],
	[
		"WCNV Maximum grid frequency",
		"1240",
		"INFO"
	],
	[
		"WCNV P reduction frequency prot",
		"1241",
		"INFO"
	],
	[
		"WCNV Overvoltage",
		"1242",
		"INFO"
	],
	[
		"WCNV Transient voltage peak",
		"1243",
		"INFO"
	],
	[
		"WCNV Repeat transient voltage peak",
		"1244",
		"INFO"
	],
	[
		"WCNV Grid recovery",
		"1245",
		"INFO"
	],
	[
		"WCNV No Connection permission",
		"1246",
		"INFO"
	],
	[
		"WCNV Grid parameters implausible",
		"1247",
		"ERROR"
	],
	[
		"WCNV VQ protection",
		"1248",
		"WARNING"
	],
	[
		"WCNV VQ protection stop",
		"1249",
		"ERROR"
	],
	[
		"WCNV Dynamic frequency control",
		"1250",
		"INFO"
	],
	[
		"WCNV End additional power",
		"1251",
		"INFO"
	],
	[
		"WCNV Grid measurement error",
		"1252",
		"ERROR"
	],
	[
		"WCNV Initialization grid meas",
		"1253",
		"INFO"
	],
	[
		"WCNV LV HRC fuses triggered",
		"1254",
		"ERROR"
	],
	[
		"WCNV Lightning protect transf Defect",
		"1255",
		"WARNING"
	],
	[
		"WCNV Max transformer temp PT100",
		"1256",
		"ERROR"
	],
	[
		"WCNV Timeout max transf temp",
		"1257",
		"ERROR"
	],
	[
		"WGEN Implausible gen speed leap",
		"2000",
		"ERROR"
	],
	[
		"WGEN Gen speed analog gear speed",
		"2001",
		"ERROR"
	],
	[
		"WGEN Gen sp analog gearb sp",
		"2002",
		"ERROR"
	],
	[
		"WGEN Gen speed pulse error",
		"2003",
		"ERROR"
	],
	[
		"WGEN Gen speed voltage error",
		"2004",
		"ERROR"
	],
	[
		"WTRM Overload generator fan 1",
		"2005",
		"WARNING"
	],
	[
		"WGEN High temp gen bearing 1",
		"2006",
		"WARNING"
	],
	[
		"WTRM Max temp gen bearing 1",
		"2007",
		"ERROR"
	],
	[
		"WGEN PT100 gen bearing 1 defect",
		"2008",
		"ERROR"
	],
	[
		"WGEN Error measuring temp gen bearing 1",
		"2009",
		"ERROR"
	],
	[
		"WGEN High temp gen bearing 2",
		"2010",
		"WARNING"
	],
	[
		"WGEN Max temp gen bearing 2",
		"2011",
		"ERROR"
	],
	[
		"WGEN PT100 gen bearing 2 defect",
		"2012",
		"ERROR"
	],
	[
		"WGEN Error measuring temp gen bearing 2",
		"2013",
		"ERROR"
	],
	[
		"WGEN Overload generator fan 2",
		"2014",
		"WARNING"
	],
	[
		"WGEN Overload generator fan 3",
		"2015",
		"WARNING"
	],
	[
		"WGEN Thermistor generator",
		"2016",
		"ERROR"
	],
	[
		"WGEN PT100 stator temp 2 defect",
		"2017",
		"ERROR"
	],
	[
		"WGEN Error measuring temp 2 stator",
		"2018",
		"ERROR"
	],
	[
		"WGEN High stator temperature",
		"2019",
		"WARNING"
	],
	[
		"WGEN High stator temperature 2",
		"2020",
		"WARNING"
	],
	[
		"WGEN Max temp stator",
		"2021",
		"ERROR"
	],
	[
		"WGEN Max temp stator 2",
		"2022",
		"ERROR"
	],
	[
		"WGEN PT100 stator temp defect",
		"2023",
		"ERROR"
	],
	[
		"WGEN Error measuring temp stator",
		"2024",
		"ERROR"
	],
	[
		"WGEN Overload generator heating",
		"2025",
		"WARNING"
	],
	[
		"WGEN Overload gen heating stop",
		"2026",
		"ERROR"
	],
	[
		"WGEN Slipring cell temp high",
		"2027",
		"WARNING"
	],
	[
		"WGEN Max slip ring cell temp",
		"2028",
		"ERROR"
	],
	[
		"WGEN PT100 slipring temp defect",
		"2029",
		"ERROR"
	],
	[
		"WGEN Error meas slip ring temp",
		"2030",
		"ERROR"
	],
	[
		"WGEN P red incr gen coolant temp",
		"2031",
		"WARNING"
	],
	[
		"WGEN Gen max coolant temp",
		"2032",
		"ERROR"
	],
	[
		"WGEN Generator power too high",
		"2033",
		"ERROR"
	],
	[
		"WGEN Max power peak",
		"2034",
		"ERROR"
	],
	[
		"WGEN Service generator brushes",
		"2035",
		"WARNING"
	],
	[
		"WGEN Fault generator brushes",
		"2036",
		"ERROR"
	],
	[
		"WGEN Overload lubrication generator",
		"2037",
		"WARNING"
	],
	[
		"WGEN Fault gen bearing lubrication",
		"2038",
		"WARNING"
	],
	[
		"WGEN Man oper gen lubrication",
		"2039",
		"INFO"
	],
	[
		"WGEN Timeout fault gen lubrication",
		"2040",
		"ERROR"
	],
	[
		"WGEN Max time generator bear lubr",
		"2041",
		"WARNING"
	],
	[
		"WGEN Generator bearing lubr container empty",
		"2042",
		"WARNING"
	],
	[
		"WGEN Manual operation generator heating",
		"2043",
		"INFO"
	],
	[
		"WGEN Manual operation generator fan 1",
		"2044",
		"INFO"
	],
	[
		"WGEN Manual operation generator fan 2",
		"2045",
		"INFO"
	],
	[
		"WGEN Manual operation generator fan 3",
		"2046",
		"INFO"
	],
	[
		"WGEN Lightning protection defect",
		"2047",
		"WARNING"
	],
	[
		"WGEN Cool sys pump man oper",
		"2048",
		"INFO"
	],
	[
		"WGEN Heating coolant 1 2 man oper",
		"2049",
		"INFO"
	],
	[
		"WTRM Fans group 1 2 cool sys man oper",
		"2050",
		"INFO"
	],
	[
		"WGEN Heating fans 1 4 cool sys man oper",
		"2051",
		"INFO"
	],
	[
		"WTRM Gen power derating act",
		"2200",
		"INFO"
	],
	[
		"WGEN Gen lubr self protect active",
		"2201",
		"INFO"
	],
	[
		"WGEN Limit conv output act power",
		"2202",
		"INFO"
	],
	[
		"WCNV 4 20mA outside temp nacelle 1",
		"3000",
		"ERROR"
	],
	[
		"WNAC 4 20mA outside temp nacelle 2",
		"3001",
		"ERROR"
	],
	[
		"WNAC Outs temp nacelle implaus",
		"3002",
		"ERROR"
	],
	[
		"WNAC Nacelle outs inside temp comp implausible",
		"3003",
		"WARNING"
	],
	[
		"WNAC Light icing rotor bl ice sensor ",
		"3004",
		"INFO"
	],
	[
		"WCNV Icing Rotor bl ice sensor ",
		"3005",
		"INFO"
	],
	[
		"WNAC Icing rotor bl ice sens no eval ",
		"3006",
		"INFO"
	],
	[
		"WNAC Rotor blade ice sensor error",
		"3007",
		"WARNING"
	],
	[
		"WNAC Rot bl ice sens com err",
		"3008",
		"INFO"
	],
	[
		"WNAC Rot bl ice s eval not pos",
		"3009",
		"INFO"
	],
	[
		"WCNV Rot bl ice sens not ready",
		"3010",
		"INFO"
	],
	[
		"WCNV Rotor blade ice sensor bypass active",
		"3011",
		"INFO"
	],
	[
		"WNAC Wind sp diff level 1",
		"3012",
		"WARNING"
	],
	[
		"WNAC Wind sp diff level 2",
		"3013",
		"ERROR"
	],
	[
		"WNAC Dev wind meas est",
		"3014",
		"WARNING"
	],
	[
		"WNAC Anemometer 1 defect",
		"3015",
		"WARNING"
	],
	[
		"WNAC Reboot anemometer 1",
		"3016",
		"WARNING"
	],
	[
		"WNAC 4 20mA anemometer 1",
		"3017",
		"WARNING"
	],
	[
		"WNAC Anemometer 2 defect",
		"3018",
		"WARNING"
	],
	[
		"WNAC Reboot anemometer 2",
		"3019",
		"WARNING"
	],
	[
		"WCNV 4 20mA anemometer 2",
		"3020",
		"WARNING"
	],
	[
		"WCNV Anemometer 3 defect",
		"3021",
		"WARNING"
	],
	[
		"WNAC 4 20mA anemometer 3",
		"3022",
		"WARNING"
	],
	[
		"WNAC Anemometer defect",
		"3023",
		"ERROR"
	],
	[
		"WNAC Icing anemometer ",
		"3024",
		"INFO"
	],
	[
		"WNAC No ice detection available",
		"3025",
		"ERROR"
	],
	[
		"WNAC Reset of icing st cd possible",
		"3026",
		"INFO"
	],
	[
		"WNAC Ice anemometer de icing",
		"3027",
		"INFO"
	],
	[
		"WNAC Wind dir diff level 1",
		"3028",
		"WARNING"
	],
	[
		"WNAC Wind dir diff level 2",
		"3029",
		"ERROR"
	],
	[
		"WCNV Vane defect",
		"3030",
		"ERROR"
	],
	[
		"WNAC Vane 1 defect",
		"3031",
		"WARNING"
	],
	[
		"WNAC Vane 2 defect",
		"3032",
		"WARNING"
	],
	[
		"WNAC Check vane ",
		"3033",
		"ERROR"
	],
	[
		"WNAC 4 20 mA vane 1",
		"3034",
		"WARNING"
	],
	[
		"WNAC 4 20 mA vane 2",
		"3035",
		"WARNING"
	],
	[
		"WNAC Light icing red operation ",
		"3036",
		"INFO"
	],
	[
		"WNAC Icing red operation ",
		"3037",
		"INFO"
	],
	[
		"WNAC Light icing dev electr power ",
		"3038",
		"INFO"
	],
	[
		"WNAC Icing dev electr power ",
		"3039",
		"INFO"
	],
	[
		"WCNV Extreme icing wind power ",
		"3040",
		"WARNING"
	],
	[
		"WNAC Icing stop ",
		"3041",
		"INFO"
	],
	[
		"WNAC Timed red icing operation act",
		"3042",
		"INFO"
	],
	[
		"WNAC Stop in case of ice det act",
		"3043",
		"INFO"
	],
	[
		"WNAC Test start during potential icing",
		"3044",
		"INFO"
	],
	[
		"WNAC Max starts during icing",
		"3045",
		"INFO"
	],
	[
		"WNAC Shadow casting",
		"3046",
		"INFO"
	],
	[
		"WNAC Shadow Management Unit defect",
		"3047",
		"INFO"
	],
	[
		"WNAC Shadow Management Unit out of service",
		"3048",
		"ERROR"
	],
	[
		"WNAC Shadow Management Unit warning",
		"3049",
		"WARNING"
	],
	[
		"WCNV Comm err IEC client Shadow Mgmt Unit",
		"3050",
		"WARNING"
	],
	[
		"WNAC Comm err IEC server Shadow Mgmt Unit",
		"3051",
		"WARNING"
	],
	[
		"WNAC Man oper meteorology heating",
		"3052",
		"INFO"
	],
	[
		"WCNV High temperature nacelle",
		"3200",
		"WARNING"
	],
	[
		"WCNV Max temperature nacelle",
		"3201",
		"ERROR"
	],
	[
		"WCNV 4 20mA inside temp nacelle",
		"3202",
		"WARNING"
	],
	[
		"WNAC Rel air hum nacelle inside high in operation ",
		"3203",
		"WARNING"
	],
	[
		"WNAC Rel air hum nacelle inside too high in operation ",
		"3204",
		"ERROR"
	],
	[
		"WNAC Rel air hum nacelle inside too high",
		"3205",
		"INFO"
	],
	[
		"WNAC 4 20mA rel air humidity nacelle int",
		"3206",
		"WARNING"
	],
	[
		"WNAC 4 20mA rel air humidity tower base int",
		"3207",
		"WARNING"
	],
	[
		"WNAC Rel air hum tower base inside high in operation ",
		"3208",
		"WARNING"
	],
	[
		"WNAC Rel air hum tower base inside too high",
		"3209",
		"INFO"
	],
	[
		"WCNV Rel air hum tower base inside too high in operation ",
		"3210",
		"ERROR"
	],
	[
		"WCNV Vibration",
		"3211",
		"ERROR"
	],
	[
		"WNAC Vibration sensor error",
		"3212",
		"INFO"
	],
	[
		"WNAC Fault fire alarm system",
		"3213",
		"ERROR"
	],
	[
		"WNAC Fire warning",
		"3214",
		"ERROR"
	],
	[
		"WNAC Fire alarm",
		"3215",
		"ERROR"
	],
	[
		"WNAC Fire shut down",
		"3216",
		"ERROR"
	],
	[
		"WNAC Service fire alarm system",
		"3217",
		"INFO"
	],
	[
		"WNAC Fire alarm system inactive",
		"3218",
		"ERROR"
	],
	[
		"WNAC Smoke warning nacelle",
		"3219",
		"WARNING"
	],
	[
		"WCNV Smoke warning nacelle stop",
		"3220",
		"ERROR"
	],
	[
		"WNAC Smoke warning tower base",
		"3221",
		"WARNING"
	],
	[
		"WCNV Smoke warning tow base stop",
		"3222",
		"ERROR"
	],
	[
		"WNAC Grid disc smoke warning",
		"3223",
		"ERROR"
	],
	[
		"WNAC Manual operation nacelle fan",
		"3224",
		"INFO"
	],
	[
		"WCNV Failure nacelle fan",
		"3225",
		"WARNING"
	],
	[
		"WNAC Overload nacelle fan",
		"3226",
		"WARNING"
	],
	[
		"WCNV Dry mode nacelle",
		"3227",
		"INFO"
	],
	[
		"WNAC Manual operation rotor hub fan",
		"3228",
		"INFO"
	],
	[
		"WNAC Failure rotor hub fan",
		"3229",
		"WARNING"
	],
	[
		"WNAC Overload rotor hub fan",
		"3230",
		"WARNING"
	],
	[
		"WNAC Manual operation cooling pump",
		"3231",
		"INFO"
	],
	[
		"WNAC Failure cooling pump",
		"3232",
		"WARNING"
	],
	[
		"WNAC Overload cooling pump",
		"3233",
		"WARNING"
	],
	[
		"WNAC Pressure coolant nacelle high",
		"3234",
		"WARNING"
	],
	[
		"WNAC Pressure difference cooling pump nacelle low",
		"3235",
		"WARNING"
	],
	[
		"WNAC Coolant pump diff press nacelle too low",
		"3236",
		"WARNING"
	],
	[
		"WNAC Coolant pump diff press nacelle high",
		"3237",
		"WARNING"
	],
	[
		"WNAC Coolant pump diff press nacelle too high",
		"3238",
		"WARNING"
	],
	[
		"WNAC Error meas pressure coolant nacelle",
		"3239",
		"WARNING"
	],
	[
		"WNAC Signal Pressure coolant nacelle disturbed",
		"3240",
		"WARNING"
	],
	[
		"WNAC Error meas coolant press nacelle pump inlet",
		"3241",
		"WARNING"
	],
	[
		"WNAC Signal Pressure coolant nacelle pump inlet disturbed",
		"3242",
		"WARNING"
	],
	[
		"WNAC Error meas temperature coolant nacelle cooler",
		"3243",
		"WARNING"
	],
	[
		"WNAC Signal Temperature coolant nacelle cooler disturbed",
		"3244",
		"WARNING"
	],
	[
		"WNAC Error meas temperature coolant generator",
		"3245",
		"WARNING"
	],
	[
		"WNAC Signal Temperature coolant generator disturbed",
		"3246",
		"WARNING"
	],
	[
		"WNAC Error meas temperature coolant gearbox",
		"3247",
		"WARNING"
	],
	[
		"WNAC Signal Temperature coolant gearbox disturbed",
		"3248",
		"WARNING"
	],
	[
		"WNAC Drying mode tower base",
		"3249",
		"INFO"
	],
	[
		"WNAC Timeout bridging limit switches",
		"4000",
		"ERROR"
	],
	[
		"WROT Pitch limit switches",
		"4001",
		"ERROR"
	],
	[
		"WROT Pitch limit switch 1",
		"4002",
		"ERROR"
	],
	[
		"WROT Pitch limit switch 2",
		"4003",
		"ERROR"
	],
	[
		"WROT Pitch limit switch 3",
		"4004",
		"ERROR"
	],
	[
		"WROT Overload axis 1",
		"4005",
		"ERROR"
	],
	[
		"WROT Overload axis 2",
		"4006",
		"ERROR"
	],
	[
		"WROT Overload axis 3",
		"4007",
		"ERROR"
	],
	[
		"WROT Pitch current asymmetry",
		"4008",
		"ERROR"
	],
	[
		"WROT Pitch motor current too high",
		"4009",
		"ERROR"
	],
	[
		"WROT Blade pitch deviation test",
		"4010",
		"ERROR"
	],
	[
		"WROT Pitch angle deviation",
		"4011",
		"ERROR"
	],
	[
		"WROT Pitch deviation BP170",
		"4012",
		"ERROR"
	],
	[
		"WROT Pitch deviation Pitch Back",
		"4013",
		"ERROR"
	],
	[
		"WROT 563 Pitch too fast during fast pitch back",
		"4014",
		"ERROR"
	],
	[
		"WROT Bladeangle implausible",
		"4015",
		"ERROR"
	],
	[
		"WROT Max windspeed bladeangle",
		"4016",
		"ERROR"
	],
	[
		"WROT Pitch too slow BP50",
		"4017",
		"ERROR"
	],
	[
		"WROT Pitch too slow BP52",
		"4018",
		"ERROR"
	],
	[
		"WROT Pitch too slow BP60",
		"4019",
		"ERROR"
	],
	[
		"WNAC Pitch too slow BP75",
		"4020",
		"ERROR"
	],
	[
		"WROT Pitch too slow BP180",
		"4021",
		"ERROR"
	],
	[
		"WROT Pitch too slow BP190",
		"4022",
		"ERROR"
	],
	[
		"WROT Pitch too slow BP170",
		"4023",
		"ERROR"
	],
	[
		"WNAC Pitch too fast BP170",
		"4024",
		"ERROR"
	],
	[
		"WROT Pitch set point slow hold time BP75",
		"4025",
		"ERROR"
	],
	[
		"WROT Pitch too fast BP75",
		"4026",
		"ERROR"
	],
	[
		"WROT Set point actual value axis 1",
		"4027",
		"ERROR"
	],
	[
		"WROT Set point actual value axis 2",
		"4028",
		"ERROR"
	],
	[
		"WROT Set point actual value axis 3",
		"4029",
		"ERROR"
	],
	[
		"WROT Target act coll pitch angle",
		"4030",
		"ERROR"
	],
	[
		"WROT Great deviation blade pitches",
		"4031",
		"ERROR"
	],
	[
		"WROT Blade pitch check running",
		"4032",
		"INFO"
	],
	[
		"WROT Max temp motor axis 1",
		"4033",
		"ERROR"
	],
	[
		"WROT Max temp motor axis 2",
		"4034",
		"ERROR"
	],
	[
		"WROT Max temp motor axis 3",
		"4035",
		"ERROR"
	],
	[
		"WROT Max temp pitch motor PTC",
		"4036",
		"ERROR"
	],
	[
		"WROT 630 Overload fan pitch motor",
		"4037",
		"ERROR"
	],
	[
		"WROT Sim angle E enc act angle 1",
		"4038",
		"ERROR"
	],
	[
		"WROT Sim angle E enc act angle 2",
		"4039",
		"ERROR"
	],
	[
		"WROT Sim angle E enc act angle 3",
		"4040",
		"ERROR"
	],
	[
		"WROT Sim angle D E enc",
		"4041",
		"INFO"
	],
	[
		"WROT Pitch controller communication error",
		"4042",
		"ERROR"
	],
	[
		"WROT Pitch controller initialisation error",
		"4043",
		"ERROR"
	],
	[
		"WROT Error pitch converter 1",
		"4044",
		"ERROR"
	],
	[
		"WROT Error pitch converter 2",
		"4045",
		"ERROR"
	],
	[
		"WROT Error pitch converter 3",
		"4046",
		"ERROR"
	],
	[
		"WROT Limit switches error 91 ",
		"4047",
		"ERROR"
	],
	[
		"WROT Pitch system temperature low",
		"4048",
		"INFO"
	],
	[
		"WROT Pitch error",
		"4049",
		"ERROR"
	],
	[
		"WROT Pitch box temp too low",
		"4050",
		"ERROR"
	],
	[
		"WROT Pitch box temp implaus",
		"4051",
		"WARNING"
	],
	[
		"WROT Battery boxes overtemp",
		"4052",
		"ERROR"
	],
	[
		"WROT Battery boxes heating sys fault",
		"4053",
		"ERROR"
	],
	[
		"WROT Max pitch speed encoder A",
		"4054",
		"ERROR"
	],
	[
		"WROT Max pitch speed encoder B",
		"4055",
		"ERROR"
	],
	[
		"WROT Pitch measuring system 1 2",
		"4056",
		"ERROR"
	],
	[
		"WROT Pitch system temperature high",
		"4057",
		"ERROR"
	],
	[
		"WROT Limit switch error 95 axis 1",
		"4058",
		"WARNING"
	],
	[
		"WROT Limit switch error 95 axis 2",
		"4059",
		"WARNING"
	],
	[
		"WROT Limit switch error 95 axis 3",
		"4060",
		"WARNING"
	],
	[
		"WNAC Power failure pitch",
		"4061",
		"WARNING"
	],
	[
		"WNAC Hub temperature high",
		"4062",
		"ERROR"
	],
	[
		"WROT Timeout B sensor active",
		"4063",
		"INFO"
	],
	[
		"WROT Batt undervoltage overvoltage",
		"4064",
		"ERROR"
	],
	[
		"WROT Stop battery test",
		"4065",
		"INFO"
	],
	[
		"WROT Battery test",
		"4066",
		"INFO"
	],
	[
		"WROT Battery monitoring axis 1",
		"4067",
		"WARNING"
	],
	[
		"WROT Battery monitoring axis 2",
		"4068",
		"WARNING"
	],
	[
		"WROT Battery monitoring axis 3",
		"4069",
		"WARNING"
	],
	[
		"WROT Battery monitoring test interval",
		"4070",
		"WARNING"
	],
	[
		"WROT Charging circuit pitch",
		"4071",
		"ERROR"
	],
	[
		"WNAC Battery charge cycle axis 1 error",
		"4072",
		"WARNING"
	],
	[
		"WROT Battery charge cycle axis 2 error",
		"4073",
		"WARNING"
	],
	[
		"WROT Battery charge cycle axis 3 error",
		"4074",
		"WARNING"
	],
	[
		"WNAC Pitch back trigger by HC",
		"4075",
		"ERROR"
	],
	[
		"WROT Battery drive trigger by HC",
		"4076",
		"ERROR"
	],
	[
		"WROT Pitch heating mode",
		"4077",
		"INFO"
	],
	[
		"WROT Timeout pitch heating mode",
		"4078",
		"WARNING"
	],
	[
		"WROT Error bridging start up",
		"4079",
		"ERROR"
	],
	[
		"WROT Error brake resistor CHP",
		"4080",
		"WARNING"
	],
	[
		"WROT Signal bridging start up CHP",
		"4081",
		"WARNING"
	],
	[
		"WROT High rotor speed hub",
		"4082",
		"ERROR"
	],
	[
		"WROT Maximum rotor speed hub",
		"4083",
		"ERROR"
	],
	[
		"WROT Rotor rotation direction hub",
		"4084",
		"INFO"
	],
	[
		"WROT Rotor speed hub not equal to gear speed",
		"4085",
		"ERROR"
	],
	[
		"WNAC Rotor speed hub not equal to gear speed HI",
		"4086",
		"ERROR"
	],
	[
		"WROT Rotor speed SLC gear sp",
		"4087",
		"ERROR"
	],
	[
		"WROT Calc rotor position implausible",
		"4088",
		"WARNING"
	],
	[
		"WROT Rotor position diff",
		"4089",
		"ERROR"
	],
	[
		"WROT Check determ of rotor position",
		"4090",
		"WARNING"
	],
	[
		"WNAC Rotor pos change not plausible",
		"4091",
		"ERROR"
	],
	[
		"WNAC Error lubrication pump pitch",
		"4092",
		"WARNING"
	],
	[
		"WNAC Stop after blade bear lubr dr BP50",
		"4093",
		"INFO"
	],
	[
		"WROT Stop after blade bear lubr dr 90 ",
		"4094",
		"INFO"
	],
	[
		"WROT Blade bear lubr dr timeout",
		"4095",
		"WARNING"
	],
	[
		"WROT Blade bear lubr failure",
		"4096",
		"WARNING"
	],
	[
		"WNAC Hot air de icing positioning",
		"4200",
		"INFO"
	],
	[
		"WNAC Ending hot air de icing",
		"4201",
		"INFO"
	],
	[
		"WNAC HAD man ice prevention",
		"4202",
		"INFO"
	],
	[
		"WNAC HAD ice prevention",
		"4203",
		"INFO"
	],
	[
		"WNAC Hot air de icing active",
		"4204",
		"INFO"
	],
	[
		"WNAC HAD semi aut op",
		"4205",
		"INFO"
	],
	[
		"WROT HAD motor prot fan OFF",
		"4206",
		"WARNING"
	],
	[
		"WROT HAD motor prot heat reg OFF",
		"4207",
		"WARNING"
	],
	[
		"WROT HAD motor prot heat reg A1",
		"4208",
		"WARNING"
	],
	[
		"WROT HAD motor prot heat reg A2",
		"4209",
		"WARNING"
	],
	[
		"WNAC HAD motor prot heat reg A3",
		"4210",
		"WARNING"
	],
	[
		"WROT HAD outside temp de icing too high",
		"4211",
		"WARNING"
	],
	[
		"WROT HAD outside temp de icing too low",
		"4212",
		"WARNING"
	],
	[
		"WROT HAD outside temp ice prev too high",
		"4213",
		"WARNING"
	],
	[
		"WROT HAD outside temp ice prev too low",
		"4214",
		"WARNING"
	],
	[
		"WNAC HAD overtemp relay",
		"4215",
		"WARNING"
	],
	[
		"WROT HAD overtemp flow",
		"4216",
		"WARNING"
	],
	[
		"WROT HAD overtemp control box",
		"4217",
		"WARNING"
	],
	[
		"WROT HAD overtemp heating",
		"4218",
		"WARNING"
	],
	[
		"WROT HAD temp sensor drift A1",
		"4219",
		"WARNING"
	],
	[
		"WNAC HAD temp sensor drift A2",
		"4220",
		"WARNING"
	],
	[
		"WROT HAD temp sensor drift A3",
		"4221",
		"WARNING"
	],
	[
		"WROT HAD temp sensor error",
		"4222",
		"WARNING"
	],
	[
		"WROT HAD rotor pos sensor error",
		"4223",
		"WARNING"
	],
	[
		"WROT HAD error HFU contact A1",
		"4224",
		"WARNING"
	],
	[
		"WNAC HAD error HFU contact A2",
		"4225",
		"WARNING"
	],
	[
		"WROT HAD error HFU contact A3",
		"4226",
		"WARNING"
	],
	[
		"WROT HAD error overtemp Relay",
		"4227",
		"WARNING"
	],
	[
		"WROT HAD motor prot fan A1",
		"4228",
		"WARNING"
	],
	[
		"WROT HAD motor prot fan A2",
		"4229",
		"WARNING"
	],
	[
		"WNAC HAD motor prot fan A3",
		"4230",
		"WARNING"
	],
	[
		"WROT HAD de icing implausible",
		"4231",
		"WARNING"
	],
	[
		"WROT HAD communication error",
		"4232",
		"WARNING"
	],
	[
		"WROT HAD comm version error",
		"4233",
		"WARNING"
	],
	[
		"WROT HAD rotor pos implausible",
		"4234",
		"WARNING"
	],
	[
		"WROT HAD timeout positioning",
		"4235",
		"WARNING"
	],
	[
		"WROT HAD timeout de icing A1",
		"4236",
		"WARNING"
	],
	[
		"WROT HAD timeout de icing A2",
		"4237",
		"WARNING"
	],
	[
		"WROT HAD timeout de icing A3",
		"4238",
		"WARNING"
	],
	[
		"WROT HAD max CPU temp",
		"4239",
		"WARNING"
	],
	[
		"WROT HAD CPU error RTC",
		"4240",
		"WARNING"
	],
	[
		"WROT HAD CPU NVRAM battery",
		"4241",
		"WARNING"
	],
	[
		"WROT HAD CPU memory error",
		"4242",
		"WARNING"
	],
	[
		"WROT HAD division by zero",
		"4243",
		"WARNING"
	],
	[
		"WROT HAD prog runtime error 10ms",
		"4244",
		"WARNING"
	],
	[
		"WROT HAD mconfig ini check failed",
		"4245",
		"WARNING"
	],
	[
		"WROT HAD PLC hardware error",
		"4246",
		"WARNING"
	],
	[
		"WROT Breakdown obstacle light",
		"4300",
		"WARNING"
	],
	[
		"WROT Breakdown low intensity obstacle light",
		"4301",
		"WARNING"
	],
	[
		"WROT Failure visibility measuring",
		"4302",
		"WARNING"
	],
	[
		"WROT Error no visibility meas devices",
		"4303",
		"WARNING"
	],
	[
		"WROT Service obstacle light",
		"4304",
		"WARNING"
	],
	[
		"WROT Blade load sensors comm failure",
		"4400",
		"WARNING"
	],
	[
		"WROT Blade load sensors firmware error",
		"4401",
		"WARNING"
	],
	[
		"WROT Blade load sensors not RFO",
		"4402",
		"WARNING"
	],
	[
		"WROT Blade load sensors zero offset indiv error",
		"4403",
		"WARNING"
	],
	[
		"WROT Blade load sensors gain error",
		"4404",
		"WARNING"
	],
	[
		"WROT Blade load sensors homog error",
		"4405",
		"WARNING"
	],
	[
		"WROT Blade load sensors strain diff high",
		"4406",
		"WARNING"
	],
	[
		"WROT Blade load sensors implaus meas val",
		"4407",
		"WARNING"
	],
	[
		"WROT Blade load sensors signal check",
		"4408",
		"WARNING"
	],
	[
		"WROT Blade load sensors signal check error",
		"4409",
		"WARNING"
	],
	[
		"WROT Rotor blade load sensor back up mode",
		"4410",
		"WARNING"
	],
	[
		"WROT Alarm cont blade load sensors back up mode",
		"4411",
		"WARNING"
	],
	[
		"WROT Stop blade load sensors back up mode",
		"4412",
		"INFO"
	],
	[
		"WROT Blade load sensors no signal activity",
		"4413",
		"WARNING"
	],
	[
		"WROT Check blade bend mom",
		"4414",
		"INFO"
	],
	[
		"WROT Blade load sensors zero offset error",
		"4415",
		"WARNING"
	],
	[
		"WROT Tower resonance",
		"5000",
		"INFO"
	],
	[
		"WROT Nat tower freq implausible",
		"5001",
		"WARNING"
	],
	[
		"WTOW Nat tower freq calc imp",
		"5002",
		"INFO"
	],
	[
		"WTOW Tower oscillation Y level 1",
		"5003",
		"INFO"
	],
	[
		"WTOW Tower oscillation Y level 1 standst",
		"5004",
		"INFO"
	],
	[
		"WTOW Tower oscillation X level 1",
		"5005",
		"INFO"
	],
	[
		"WTOW Tower oscillation X level 1 standst",
		"5006",
		"INFO"
	],
	[
		"WTOW Tower oscillation Y level 2",
		"5007",
		"INFO"
	],
	[
		"WTOW Tower oscillation Y level 2 standst",
		"5008",
		"INFO"
	],
	[
		"WTOW Tower oscillation Y level 3",
		"5009",
		"ERROR"
	],
	[
		"WTOW Tower oscillation X level 2",
		"5010",
		"INFO"
	],
	[
		"WTOW Tower oscillation X level 2 standst",
		"5011",
		"INFO"
	],
	[
		"WTOW Tower oscillation X level 3",
		"5012",
		"ERROR"
	],
	[
		"WTOW Tower accel difference",
		"5013",
		"ERROR"
	],
	[
		"WTOW System fault accel sensor 1",
		"5014",
		"ERROR"
	],
	[
		"WTOW Oscil sensor 1 check firmware",
		"5015",
		"ERROR"
	],
	[
		"WTOW Oscil sensor 2 check firmware",
		"5016",
		"ERROR"
	],
	[
		"WTOW Oscill encoder tower BP act ",
		"5017",
		"ERROR"
	],
	[
		"WTOW 4 20mA tower acceleration Y",
		"5018",
		"ERROR"
	],
	[
		"WTOW 4 20mA tower acceleration X",
		"5019",
		"ERROR"
	],
	[
		"WROT Oscillation encoder tower",
		"5020",
		"ERROR"
	],
	[
		"WTOW Oscillation encoder TwC",
		"5021",
		"ERROR"
	],
	[
		"WTOW PT100 base box temp defect",
		"5022",
		"WARNING"
	],
	[
		"WTOW Base box temperature high",
		"5023",
		"WARNING"
	],
	[
		"WTOW Base box temperature low",
		"5024",
		"WARNING"
	],
	[
		"WROT Error measuring temp tower base box",
		"5025",
		"WARNING"
	],
	[
		"WTOW Heating fan base box faulty",
		"5026",
		"WARNING"
	],
	[
		"WTOW Tower distrib cabinet def",
		"5027",
		"WARNING"
	],
	[
		"WTOW Max base box temp",
		"5028",
		"ERROR"
	],
	[
		"WTOW PT100 temp tower base defective",
		"5029",
		"WARNING"
	],
	[
		"WTOW 4 20mA tower accel Y2 TwC ",
		"5030",
		"ERROR"
	],
	[
		"WTOW 4 20mA tower accel X2 TwC ",
		"5031",
		"ERROR"
	],
	[
		"WTOW Failure tower fan",
		"5032",
		"WARNING"
	],
	[
		"WTOW Manual operation tower fan",
		"5033",
		"INFO"
	],
	[
		"WTOW Tower fan overload",
		"5034",
		"WARNING"
	],
	[
		"WTOW Persons in the tower base",
		"5035",
		"WARNING"
	],
	[
		"WTOW Tower door opened",
		"5036",
		"WARNING"
	],
	[
		"WTOW Accel sensor XF YF comm error",
		"5037",
		"WARNING"
	],
	[
		"WTOW Accel sensor XF YF system error",
		"5038",
		"WARNING"
	],
	[
		"WTOW Tower oscillation YF",
		"5039",
		"INFO"
	],
	[
		"WTOW Tower oscillation XF",
		"5040",
		"INFO"
	],
	[
		"WTOW 4 20mA tower base outside temperature",
		"5041",
		"WARNING"
	],
	[
		"WTOW Measurement error tower base outside temperature",
		"5042",
		"WARNING"
	],
	[
		"WYAW MVS Trafo CB tripped",
		"6000",
		"ERROR"
	],
	[
		"WTRF MVS Trafo CB remote off",
		"6001",
		"INFO"
	],
	[
		"WTRF MVS grid disconn off",
		"6002",
		"INFO"
	],
	[
		"WTRF MVS grid ES on",
		"6003",
		"INFO"
	],
	[
		"WTRF MVS cable outlet 1 disconn off",
		"6004",
		"INFO"
	],
	[
		"WTRF MVS cable outlet 1 ES on",
		"6005",
		"INFO"
	],
	[
		"WTRF MVS cable outlet 2 disconn off",
		"6006",
		"INFO"
	],
	[
		"WYAW MVS cable outlet 2 ES on",
		"6007",
		"INFO"
	],
	[
		"WYAW Circuit breaker",
		"6200",
		"ERROR"
	],
	[
		"WTRF MVS Trafo CB off",
		"6201",
		"INFO"
	],
	[
		"WTRF P reduction current limitation",
		"6202",
		"INFO"
	],
	[
		"WTRF Max transformer temp",
		"6203",
		"ERROR"
	],
	[
		"WTRF P reduction apparent power limitation",
		"6204",
		"INFO"
	],
	[
		"WTRF Medium voltage off",
		"6205",
		"ERROR"
	],
	[
		"WTRF MVS Transf Disc off",
		"6206",
		"INFO"
	],
	[
		"WTRF MVS Transf ES on",
		"6207",
		"INFO"
	],
	[
		"WTRF MSS Protection system error",
		"6208",
		"ERROR"
	],
	[
		"WTRF SF6 boiler pressure too low",
		"6209",
		"ERROR"
	],
	[
		"WYAW Spare potection inactive",
		"6210",
		"ERROR"
	],
	[
		"WTRF PT100 transf int defect",
		"6211",
		"ERROR"
	],
	[
		"WTRF Error meas temp transf int",
		"6212",
		"ERROR"
	],
	[
		"WTRF Max temp supply transformer",
		"6213",
		"ERROR"
	],
	[
		"WTRF Max temp supply transf grid disconn",
		"6214",
		"ERROR"
	],
	[
		"WTRF Transf oil pressure too high",
		"6215",
		"ERROR"
	],
	[
		"WTRF Transf fill level too low",
		"6216",
		"ERROR"
	],
	[
		"WTRF PT100 supply transformer def",
		"6217",
		"ERROR"
	],
	[
		"WTRF Error measuring PT100 supply transf",
		"6218",
		"ERROR"
	],
	[
		"WTRF Aux power operation error",
		"6219",
		"ERROR"
	],
	[
		"WTRF Max overv aux power ctrl",
		"6220",
		"ERROR"
	],
	[
		"WTRF Max temp aux transf nacelle",
		"6221",
		"ERROR"
	],
	[
		"WTRF PT100 aux transformer nacelle def",
		"6222",
		"ERROR"
	],
	[
		"WTRF Error meas nacelle aux transf",
		"6223",
		"ERROR"
	],
	[
		"WTRF Transformer pump overload",
		"6224",
		"WARNING"
	],
	[
		"WTRF Transf pump thermist tripped",
		"6225",
		"WARNING"
	],
	[
		"WTRF Transf pump man oper",
		"6226",
		"INFO"
	],
	[
		"WTRM High gearbox oil pressure",
		"7000",
		"ERROR"
	],
	[
		"WTUR Low gearbox oil pressure",
		"7001",
		"ERROR"
	],
	[
		"WTUR 4 20mA press gearbox pump",
		"7002",
		"ERROR"
	],
	[
		"WTUR 4 20mA press gearbox inlet",
		"7003",
		"ERROR"
	],
	[
		"WTUR Error measuring pressure inlet gear",
		"7004",
		"WARNING"
	],
	[
		"WTUR Missing gear oil low rpm ",
		"7005",
		"ERROR"
	],
	[
		"WTRM Missing gear oil high rpm ",
		"7006",
		"ERROR"
	],
	[
		"WTRM Gearbox warm up stage",
		"7007",
		"INFO"
	],
	[
		"WTUR Gear heating enabled",
		"7008",
		"INFO"
	],
	[
		"WTUR Gearbox warmed up idling",
		"7009",
		"INFO"
	],
	[
		"WTUR Timeout gearoil heating routine active",
		"7010",
		"WARNING"
	],
	[
		"WTUR Manual operation fan gear",
		"7011",
		"INFO"
	],
	[
		"WTUR Manual operation gear heating",
		"7012",
		"INFO"
	],
	[
		"WTUR Manual operation gear oil pump",
		"7013",
		"INFO"
	],
	[
		"WTUR High gear speed",
		"7014",
		"ERROR"
	],
	[
		"WTRM Maximum gear speed",
		"7015",
		"ERROR"
	],
	[
		"WTUR Implausible gear speed leap",
		"7016",
		"ERROR"
	],
	[
		"WTUR Disc filter adaption implausible",
		"7017",
		"ERROR"
	],
	[
		"WTUR Gearb sp SLC gearb sp",
		"7018",
		"ERROR"
	],
	[
		"WTUR Gear ratio param implaus",
		"7019",
		"ERROR"
	],
	[
		"WTRM High temp gear bearing 1",
		"7020",
		"WARNING"
	],
	[
		"WTRM Max temp gear bearing 1",
		"7021",
		"ERROR"
	],
	[
		"WTRM PT100 gear bearing 1 defect",
		"7022",
		"ERROR"
	],
	[
		"WTRM Error measuring temp gear bearing 1",
		"7023",
		"ERROR"
	],
	[
		"WTRM High temp gear bearing 2",
		"7024",
		"WARNING"
	],
	[
		"WTUR Max temp gear bearing 2",
		"7025",
		"ERROR"
	],
	[
		"WTUR PT100 gear bearing 2 defect",
		"7026",
		"ERROR"
	],
	[
		"WTUR Error measuring temp gear bearing 2",
		"7027",
		"ERROR"
	],
	[
		"WTUR Max oilsump temperature",
		"7028",
		"ERROR"
	],
	[
		"WTUR Oilsump temperature high",
		"7029",
		"WARNING"
	],
	[
		"WTUR Low gear oil temperature",
		"7030",
		"INFO"
	],
	[
		"WTUR PT100 gear oil sump defect",
		"7031",
		"ERROR"
	],
	[
		"WTRM Error measuring temp gear oil sump",
		"7032",
		"ERROR"
	],
	[
		"WTRM PT100 inlet gear defect",
		"7033",
		"WARNING"
	],
	[
		"WTRM Oil temperature gearbox input high",
		"7034",
		"WARNING"
	],
	[
		"WTUR Max oil temperature gearbox input",
		"7035",
		"ERROR"
	],
	[
		"WTUR Error measuring temp inlet gear",
		"7036",
		"WARNING"
	],
	[
		"WTRM High temp gear bearing 3",
		"7037",
		"WARNING"
	],
	[
		"WTRM Max temp gear bearing 3",
		"7038",
		"ERROR"
	],
	[
		"WTRM PT100 gear bearing 3 defect",
		"7039",
		"ERROR"
	],
	[
		"WTUR Error measuring temp gear bearing 3",
		"7040",
		"ERROR"
	],
	[
		"WTRM High temp gear bearing 4",
		"7041",
		"WARNING"
	],
	[
		"WTRM Max temp gear bearing 4",
		"7042",
		"ERROR"
	],
	[
		"WTRM PT100 gear bearing 4 defect",
		"7043",
		"ERROR"
	],
	[
		"WTRM Error measuring temp gear bearing 4",
		"7044",
		"ERROR"
	],
	[
		"WTRM Overload gear oil pump",
		"7045",
		"ERROR"
	],
	[
		"WTRM Overload gear heating",
		"7046",
		"WARNING"
	],
	[
		"WTRM Fault fan gear oil cooler 1",
		"7047",
		"WARNING"
	],
	[
		"WTRM Overload fan 1 gear oil cooler",
		"7048",
		"WARNING"
	],
	[
		"WTRM Overload fan 2 gear oil cooler",
		"7049",
		"WARNING"
	],
	[
		"WTUR Fault fan gear oil cooler 2",
		"7050",
		"WARNING"
	],
	[
		"WTRM Fault fan gear oil cooler 1 2",
		"7051",
		"WARNING"
	],
	[
		"WTUR Oil filter gear choked",
		"7052",
		"WARNING"
	],
	[
		"WTUR 4 20mA pressure diff gear oil filter",
		"7053",
		"WARNING"
	],
	[
		"WTUR Error meas press diff oil filter",
		"7054",
		"WARNING"
	],
	[
		"WTUR Particle sensor defect",
		"7055",
		"WARNING"
	],
	[
		"WTRM Particle Gear Alarm 10min",
		"7056",
		"WARNING"
	],
	[
		"WTUR Particle Gear Alarm 24h",
		"7057",
		"ERROR"
	],
	[
		"WTUR Particle Gear Alarm Total",
		"7058",
		"WARNING"
	],
	[
		"WTRM Drive train oscillation Z level 0",
		"7200",
		"WARNING"
	],
	[
		"WTRM Drive train oscillation Z level 1",
		"7201",
		"ERROR"
	],
	[
		"WTRM Drive train oscillation Z level 2",
		"7202",
		"ERROR"
	],
	[
		"WTRM Drivetrain oscillations",
		"7203",
		"WARNING"
	],
	[
		"WTRM Max drivetrain oscillations",
		"7204",
		"ERROR"
	],
	[
		"WTRM Drive train monitor level 1",
		"7205",
		"INFO"
	],
	[
		"WTRM Drive train monitor level 2",
		"7206",
		"INFO"
	],
	[
		"WTRM 4 20mA drive train acceleration Z",
		"7207",
		"ERROR"
	],
	[
		"WTRM Acceleration detector drivetrain",
		"7208",
		"ERROR"
	],
	[
		"WTRM CMS drive train system error",
		"7209",
		"WARNING"
	],
	[
		"WTRM CMS drive train meas val ev",
		"7210",
		"INFO"
	],
	[
		"WTRM Comm err IEC client CMS drive tr",
		"7211",
		"WARNING"
	],
	[
		"WTRM Comm err IEC server CMS drive tr",
		"7212",
		"WARNING"
	],
	[
		"WTRM High temp rotorbearing",
		"7213",
		"WARNING"
	],
	[
		"WTRM Max temp rotorbearing",
		"7214",
		"ERROR"
	],
	[
		"WTRM 4 20mA rotor bear temp",
		"7215",
		"WARNING"
	],
	[
		"WTRM 4 20mA rotor bear temp timeout",
		"7216",
		"ERROR"
	],
	[
		"WTRM Rotor bearing lubrication pump 1 overload",
		"7217",
		"WARNING"
	],
	[
		"WTRM Rotor bearing lubrication pump 2 overload",
		"7218",
		"WARNING"
	],
	[
		"WTRM Rotor bear lubr cont 1 empty",
		"7219",
		"WARNING"
	],
	[
		"WTRM Rotor bear lubr cont 2 empty",
		"7220",
		"WARNING"
	],
	[
		"WTRM Timeout fault rotor bear lubr",
		"7221",
		"ERROR"
	],
	[
		"WTRM Rotor bearing lubrication failure",
		"7222",
		"WARNING"
	],
	[
		"WTRM Rotor bearing lubric man op",
		"7223",
		"INFO"
	],
	[
		"WTRM Max time rotor bear lubr 1",
		"7224",
		"WARNING"
	],
	[
		"WTRM Max time rotor bear lubr 2",
		"7225",
		"WARNING"
	],
	[
		"WTRM Rotor locked Stop",
		"7226",
		"INFO"
	],
	[
		"WTRM Rotor lock wind too strong",
		"7227",
		"INFO"
	],
	[
		"WTRM Rotor lock 1 on",
		"7228",
		"INFO"
	],
	[
		"WTRM Rotor lock 2 on",
		"7229",
		"INFO"
	],
	[
		"WTRM Rotor lock no storm position",
		"7230",
		"INFO"
	],
	[
		"WTRM High hydraulic pressure",
		"7300",
		"ERROR"
	],
	[
		"WTRM High hydr press flush mode",
		"7301",
		"WARNING"
	],
	[
		"WTRM Rot br press high",
		"7302",
		"ERROR"
	],
	[
		"WTRM Max rot br press",
		"7303",
		"ERROR"
	],
	[
		"WTRM Low hydraulic pressure",
		"7304",
		"ERROR"
	],
	[
		"WTRM Rot br press low",
		"7305",
		"ERROR"
	],
	[
		"WTRM Drain valve MVB test fail",
		"7306",
		"ERROR"
	],
	[
		"WTRM 4 20mA hydraulic pressure",
		"7307",
		"ERROR"
	],
	[
		"WTRM 4 20mA rot br press",
		"7308",
		"ERROR"
	],
	[
		"WTRM Low hydraulic oil level",
		"7309",
		"ERROR"
	],
	[
		"WTRM Overload hydraulic pump",
		"7310",
		"ERROR"
	],
	[
		"WTRM Max operation time hydraulic",
		"7311",
		"ERROR"
	],
	[
		"WTRM Min operation time hydraulic",
		"7312",
		"ERROR"
	],
	[
		"WTRM Pressure drop hydraulic sys",
		"7313",
		"WARNING"
	],
	[
		"WTRM Manual operation hydraulic pump",
		"7314",
		"INFO"
	],
	[
		"WTRM Hydraulic oil flushing operation",
		"7315",
		"INFO"
	],
	[
		"WTRM Manual op hydr oil flushing",
		"7316",
		"INFO"
	],
	[
		"WTUR Check brake",
		"7400",
		"ERROR"
	],
	[
		"WTUR Brake pads warning",
		"7401",
		"WARNING"
	],
	[
		"WTUR Brake closed in operation",
		"7402",
		"ERROR"
	],
	[
		"WTUR Timeout brake closed",
		"7403",
		"WARNING"
	],
	[
		"WTUR Impulse braking",
		"7404",
		"INFO"
	],
	[
		"WTRM Permanent braking",
		"7405",
		"INFO"
	],
	[
		"WTRM Additional braking",
		"7406",
		"INFO"
	],
	[
		"WTRM Max braking energy exceeded",
		"7407",
		"ERROR"
	],
	[
		"WTRM Temp rot br pad implaus",
		"7408",
		"ERROR"
	],
	[
		"WTRM Disc brake cooling down",
		"7409",
		"INFO"
	],
	[
		"WTRM Temp rot br pad high",
		"7410",
		"INFO"
	],
	[
		"WTRM Max rot br pad temp exceed",
		"7411",
		"INFO"
	],
	[
		"WTRM Dragging brake monitoring",
		"7412",
		"INFO"
	],
	[
		"WTRM Temp rot br pad high timeout",
		"7413",
		"WARNING"
	],
	[
		"WTRM Error measuring temp rot br pad 1",
		"7414",
		"ERROR"
	],
	[
		"WTUR PT100 rot br pad 1 defect",
		"7415",
		"ERROR"
	],
	[
		"WTRM Error measuring temp rot br pad 2",
		"7416",
		"ERROR"
	],
	[
		"WTRM PT100 rot br pad 2 defect",
		"7417",
		"ERROR"
	],
	[
		"WTRM 0 10V error volt buffer rot br",
		"7418",
		"ERROR"
	],
	[
		"WTRM Brake due to sudden sys failure",
		"7419",
		"ERROR"
	],
	[
		"WTUR Overload electr yaw brake",
		"8000",
		"ERROR"
	],
	[
		"WTUR Overload yaw motors group 1",
		"8001",
		"ERROR"
	],
	[
		"WTUR Overload yaw motors group 2",
		"8002",
		"ERROR"
	],
	[
		"WYAW Max time yaw bear lubr",
		"8003",
		"WARNING"
	],
	[
		"WYAW Overload yaw lubr pump",
		"8004",
		"WARNING"
	],
	[
		"WYAW Yaw bearing lubric man op",
		"8005",
		"INFO"
	],
	[
		"WYAW Timeout fault yaw lubrication",
		"8006",
		"ERROR"
	],
	[
		"WYAW Error yaw lubr pump no ext press build up ",
		"8007",
		"WARNING"
	],
	[
		"WYAW Error yaw lubr pump no ext press red ",
		"8008",
		"WARNING"
	],
	[
		"WYAW Yaw lubr container empty",
		"8009",
		"WARNING"
	],
	[
		"WYAW High yaw motor current",
		"8010",
		"INFO"
	],
	[
		"WYAW Easy yaw",
		"8011",
		"WARNING"
	],
	[
		"WYAW High yaw load",
		"8012",
		"ERROR"
	],
	[
		"WYAW Rotating direction yaw",
		"8013",
		"ERROR"
	],
	[
		"WYAW Yaw velocity too low",
		"8014",
		"ERROR"
	],
	[
		"WYAW Yaw sensor A defect",
		"8015",
		"ERROR"
	],
	[
		"WYAW Yaw sensor B defect",
		"8016",
		"ERROR"
	],
	[
		"WYAW Uncontrolled yaw movement",
		"8017",
		"ERROR"
	],
	[
		"WYAW Yaw speed high",
		"8018",
		"ERROR"
	],
	[
		"WYAW Cable autounwind",
		"8019",
		"INFO"
	],
	[
		"WYAW Max cable twistangle",
		"8020",
		"ERROR"
	],
	[
		"WYAW Yaw error",
		"8021",
		"ERROR"
	],
	[
		"WYAW Check nacelle position ",
		"8022",
		"WARNING"
	],
	[
		"WYAW Error nacelle pos Load Man",
		"8023",
		"WARNING"
	],
	[
		"WYAW Untwisting sensor test",
		"8024",
		"INFO"
	],
	[
		"WYAW Nacelle position sensor fault",
		"8025",
		"WARNING"
	],
	[
		"WYAW Manual yaw brake",
		"8026",
		"INFO"
	],
	[
		"WYAW Manual yaw",
		"8027",
		"INFO"
	],
	[
		"WYAW Manual yaw via pushbutton",
		"8028",
		"INFO"
	],
	[
		"WYAW Tower referencing act",
		"8029",
		"INFO"
	],
	[
		"WYAW Yaw current par implausible",
		"8030",
		"WARNING"
	],
	[
		"WYAW 4 20mA yaw current sensor",
		"8031",
		"WARNING"
	],
	[
		"WYAW Yaw park pos in case of icing",
		"8032",
		"INFO"
	],
	[
		"WTUR System OK",
		"9001",
		"INFO"
	],
	[
		"WTUR Negative power too little wind",
		"9002",
		"INFO"
	],
	[
		"WTUR Negative power too little wind with icing",
		"9003",
		"INFO"
	],
	[
		"WTUR Timeout start for icing",
		"9004",
		"INFO"
	],
	[
		"WTUR Manual stop on site",
		"9005",
		"INFO"
	],
	[
		"WTUR Manual stop remote",
		"9006",
		"INFO"
	],
	[
		"WTUR Manual stop without login",
		"9007",
		"INFO"
	],
	[
		"WTUR WTG stop",
		"9008",
		"INFO"
	],
	[
		"WTUR Wind sector stop",
		"9009",
		"INFO"
	],
	[
		"WTUR Limiting wind speed exceeded",
		"9010",
		"INFO"
	],
	[
		"WTUR Max wind dir deviation high wind sp",
		"9011",
		"ERROR"
	],
	[
		"WTUR Max windspeed BP50",
		"9012",
		"INFO"
	],
	[
		"WTUR Night operation",
		"9013",
		"INFO"
	],
	[
		"WTUR Wind dir dev level 1",
		"9014",
		"ERROR"
	],
	[
		"WTUR WTG shutdown pitch angle stormp ignored",
		"9015",
		"INFO"
	],
	[
		"WTUR WTG shut down",
		"9016",
		"INFO"
	],
	[
		"WTUR Reduced power active",
		"9017",
		"INFO"
	],
	[
		"WTUR Wind dir dev level 2",
		"9018",
		"ERROR"
	],
	[
		"WTUR Max acceleration",
		"9019",
		"WARNING"
	],
	[
		"WTUR Wind higher than power",
		"9020",
		"ERROR"
	],
	[
		"WTUR Wind smaller than power",
		"9021",
		"ERROR"
	],
	[
		"WTUR Extreme gust",
		"9022",
		"INFO"
	],
	[
		"WTUR Max wind speed",
		"9023",
		"INFO"
	],
	[
		"WTUR Absence of wind during run up",
		"9024",
		"INFO"
	],
	[
		"WTUR Icing nacelle ice sensor ",
		"9025",
		"INFO"
	],
	[
		"WTUR Outdoor temperature low",
		"9026",
		"INFO"
	],
	[
		"WTUR Outdoor temperature high",
		"9027",
		"INFO"
	],
	[
		"WTUR Reduced power gearbox",
		"9028",
		"WARNING"
	],
	[
		"WTUR Reduced power generator",
		"9029",
		"WARNING"
	],
	[
		"WTUR Reduced power transformer",
		"9030",
		"WARNING"
	],
	[
		"WTUR Outdoor temp extremely low",
		"9031",
		"WARNING"
	],
	[
		"WTUR Outdoor temp working range",
		"9032",
		"INFO"
	],
	[
		"WTUR Emergency stop top box",
		"9033",
		"INFO"
	],
	[
		"WTUR Emergency stop nacelle",
		"9034",
		"INFO"
	],
	[
		"WTUR Emergency stop converter",
		"9035",
		"INFO"
	],
	[
		"WTUR Emergency stop base box",
		"9036",
		"INFO"
	],
	[
		"WTUR Conv emergency stop 2",
		"9037",
		"INFO"
	],
	[
		"WTUR Emer stop tower base",
		"9038",
		"INFO"
	],
	[
		"WTUR Release manual pitch",
		"9039",
		"INFO"
	],
	[
		"WTUR Manual pitch active",
		"9040",
		"INFO"
	],
	[
		"WTUR Pitch service mode",
		"9041",
		"INFO"
	],
	[
		"WTUR Manual brake",
		"9042",
		"INFO"
	],
	[
		"WTUR Sound characteristic A active",
		"9043",
		"INFO"
	],
	[
		"WTUR Sound characteristic C active",
		"9044",
		"INFO"
	],
	[
		"WTUR Sound characteristic B active",
		"9045",
		"INFO"
	],
	[
		"WTUR Sound characteristic D active",
		"9046",
		"INFO"
	],
	[
		"WTUR Noise reduction stop",
		"9047",
		"INFO"
	],
	[
		"WTUR Bat protection active",
		"9048",
		"INFO"
	],
	[
		"WTUR Parameterized P red",
		"9049",
		"INFO"
	],
	[
		"WTUR Parameterized speed red",
		"9050",
		"INFO"
	],
	[
		"WTUR Red op soft cut out",
		"9051",
		"INFO"
	],
	[
		"WTUR Soft cut out par implausible",
		"9052",
		"WARNING"
	],
	[
		"WTUR Update active",
		"9053",
		"INFO"
	],
	[
		"WTUR Stop for man aut reboot",
		"9054",
		"INFO"
	],
	[
		"WTUR Update failed",
		"9055",
		"WARNING"
	],
	[
		"WTUR Manual reboot",
		"9056",
		"INFO"
	],
	[
		"WTUR Man shutdown error",
		"9057",
		"ERROR"
	],
	[
		"WTUR Brake control",
		"9058",
		"ERROR"
	],
	[
		"WTUR Max braking time BP20",
		"9059",
		"ERROR"
	],
	[
		"WTUR Max braking time BP50",
		"9060",
		"ERROR"
	],
	[
		"WTUR Max braking time BP52",
		"9061",
		"ERROR"
	],
	[
		"WTUR Max braking time BP60",
		"9062",
		"ERROR"
	],
	[
		"WTUR Max braking time BP75",
		"9063",
		"ERROR"
	],
	[
		"WTUR Parameter setting BP75 implausible",
		"9064",
		"ERROR"
	],
	[
		"WTUR Max braking time BP170",
		"9065",
		"ERROR"
	],
	[
		"WTUR Max braking time BP180",
		"9066",
		"ERROR"
	],
	[
		"WTUR Max braking time BP190",
		"9067",
		"ERROR"
	],
	[
		"WTUR Timeout systemtest 1",
		"9068",
		"ERROR"
	],
	[
		"WTUR Timeout systemtest 2",
		"9069",
		"ERROR"
	],
	[
		"WTUR Timeout systemtest 3",
		"9070",
		"ERROR"
	],
	[
		"WTUR Manual operation",
		"9071",
		"INFO"
	],
	[
		"WTUR Semi automatic operation",
		"9072",
		"INFO"
	],
	[
		"WTUR Stop manual operation",
		"9073",
		"INFO"
	],
	[
		"WTUR Test brake program 190",
		"9074",
		"INFO"
	],
	[
		"WTUR Test brake program 180",
		"9075",
		"INFO"
	],
	[
		"WTUR Test brake program 170",
		"9076",
		"INFO"
	],
	[
		"WTUR Test brake program 75",
		"9077",
		"INFO"
	],
	[
		"WTUR Test brake program 60",
		"9078",
		"INFO"
	],
	[
		"WTUR Test brake program 52",
		"9079",
		"INFO"
	],
	[
		"WTUR Test brake program 50",
		"9080",
		"INFO"
	],
	[
		"WTUR Test brake program 20",
		"9081",
		"INFO"
	],
	[
		"WTUR No load rotation active",
		"9082",
		"INFO"
	],
	[
		"WTUR No speed development",
		"9083",
		"ERROR"
	],
	[
		"WTUR Repeating error BP 0",
		"9084",
		"WARNING"
	],
	[
		"WTUR Repeating error BP52",
		"9085",
		"ERROR"
	],
	[
		"WTUR Repeating error BP60",
		"9086",
		"ERROR"
	],
	[
		"WTUR Repeating error BP75",
		"9087",
		"ERROR"
	],
	[
		"WTUR Repeating error BP170",
		"9088",
		"ERROR"
	],
	[
		"WTUR Repeating error BP180",
		"9089",
		"ERROR"
	],
	[
		"WTUR Repeating error BP190",
		"9090",
		"ERROR"
	],
	[
		"WTUR Tower base temp impermissible",
		"9091",
		"INFO"
	],
	[
		"WTUR Dev single pitch angle targ",
		"9200",
		"ERROR"
	],
	[
		"WTUR Targ pitch angle coll dev",
		"9201",
		"ERROR"
	],
	[
		"WTUR Coll pitch targ rate exceed",
		"9202",
		"ERROR"
	],
	[
		"WTUR Sel pitch targ rate exceed",
		"9203",
		"ERROR"
	],
	[
		"WTUR Task runtime failure 1ms",
		"9204",
		"ERROR"
	],
	[
		"WTUR Task runtime failure 5ms",
		"9205",
		"ERROR"
	],
	[
		"WTUR Task runtime failure 10 ms",
		"9206",
		"ERROR"
	],
	[
		"WTUR Task runtime failure grid measuring",
		"9207",
		"ERROR"
	],
	[
		"WTUR Division by zero",
		"9208",
		"ERROR"
	],
	[
		"WTUR Reboot necessary after update",
		"9209",
		"INFO"
	],
	[
		"WTUR Unexpected reboot",
		"9210",
		"WARNING"
	],
	[
		"WTUR Parameter unreadable",
		"9211",
		"ERROR"
	],
	[
		"WTUR Loading parameters",
		"9212",
		"INFO"
	],
	[
		"WTUR Manual snapshot",
		"9213",
		"INFO"
	],
	[
		"WTUR Alarm call test",
		"9214",
		"INFO"
	],
	[
		"WTUR Cond snapshot",
		"9215",
		"INFO"
	],
	[
		"WTUR Parameter outside limits",
		"9216",
		"WARNING"
	],
	[
		"WTUR Parameter outside limits stop",
		"9217",
		"ERROR"
	],
	[
		"WTUR Parameter update active",
		"9218",
		"INFO"
	],
	[
		"WTUR Unsafe parametrization",
		"9219",
		"ERROR"
	],
	[
		"WTUR Configuration error",
		"9220",
		"ERROR"
	],
	[
		"WTUR License error",
		"9221",
		"INFO"
	],
	[
		"WTUR Runtime error",
		"9222",
		"INFO"
	],
	[
		"WTUR Software exception error",
		"9223",
		"INFO"
	],
	[
		"WTUR File transfer error",
		"9224",
		"INFO"
	],
	[
		"WTUR Controller flags implausible",
		"9225",
		"ERROR"
	],
	[
		"WTUR Controller parameter setting implausible",
		"9226",
		"ERROR"
	],
	[
		"WTUR Controller feed forward function reduced 50 ",
		"9227",
		"WARNING"
	],
	[
		"WTUR Controller feed forward function deactivated",
		"9228",
		"WARNING"
	],
	[
		"WTUR Set point above rated speed",
		"9229",
		"ERROR"
	],
	[
		"WTUR PT100 top box defect",
		"9230",
		"WARNING"
	],
	[
		"WTUR P red incr top box temp",
		"9231",
		"WARNING"
	],
	[
		"WTUR Top box temperature high",
		"9232",
		"WARNING"
	],
	[
		"WTUR Top box temperature low",
		"9233",
		"WARNING"
	],
	[
		"WTUR Error meas top box temp",
		"9234",
		"WARNING"
	],
	[
		"WTUR Heating fan top box faulty",
		"9235",
		"WARNING"
	],
	[
		"WTUR Fuses overload",
		"9236",
		"WARNING"
	],
	[
		"WTUR Max top box temp",
		"9237",
		"ERROR"
	],
	[
		"WTUR Comm error switch top box",
		"9238",
		"WARNING"
	],
	[
		"WTUR Comm error base box switch",
		"9239",
		"WARNING"
	],
	[
		"WTUR IEC interface read requests",
		"9240",
		"INFO"
	],
	[
		"WTUR Manual stop on site maint required",
		"9241",
		"ERROR"
	],
	[
		"WTUR 10ms task runtime high",
		"9242",
		"INFO"
	],
	[
		"WTUR HC WTC comm version conflict",
		"9243",
		"ERROR"
	],
	[
		"WTUR Check time synchronization",
		"9244",
		"WARNING"
	],
	[
		"WTUR Time sync failed SNTP error ",
		"9245",
		"WARNING"
	],
	[
		"WTUR mconfig ini check failed",
		"9246",
		"ERROR"
	],
	[
		"WTUR TwC algorithm implausible",
		"9247",
		"WARNING"
	],
	[
		"WTUR New initialization rotor pos",
		"9248",
		"INFO"
	],
	[
		"WTUR High CPU temperature",
		"9249",
		"WARNING"
	],
	[
		"WTUR Max temperature CPU",
		"9250",
		"ERROR"
	],
	[
		"WTUR CPU Failure RTC",
		"9251",
		"WARNING"
	],
	[
		"WTUR CPU NVRAM battery",
		"9252",
		"WARNING"
	],
	[
		"WTUR CPU memory error",
		"9253",
		"ERROR"
	],
	[
		"WTUR PLC hardware error",
		"9254",
		"ERROR"
	],
	[
		"WTUR CAN bus module firmware",
		"9255",
		"ERROR"
	],
	[
		"WTUR Profinet communication nacelle cool sys disrupted",
		"9256",
		"WARNING"
	],
	[
		"WTUR Firmware update required",
		"9257",
		"INFO"
	],
	[
		"WTUR Firmware update failed",
		"9258",
		"WARNING"
	],
	[
		"WTUR SLC app not running",
		"9300",
		"INFO"
	],
	[
		"WTUR SLC app not in SAFE mode",
		"9301",
		"ERROR"
	],
	[
		"WTUR SLC SF max cable winding",
		"9302",
		"ERROR"
	],
	[
		"WTUR SLC SF generator temperature",
		"9303",
		"ERROR"
	],
	[
		"WTUR SLC SF system monitoring",
		"9304",
		"ERROR"
	],
	[
		"WTUR SLC SF overspeed",
		"9305",
		"ERROR"
	],
	[
		"WTUR SLC SF max tower oscillation",
		"9306",
		"ERROR"
	],
	[
		"WTUR SLC SF max rotor brake pad temp",
		"9307",
		"ERROR"
	],
	[
		"WTUR SLC SF emergency stop",
		"9308",
		"ERROR"
	],
	[
		"WTUR SLC MF brake request HC",
		"9309",
		"ERROR"
	],
	[
		"WTUR SLC MF converter grid disconnection",
		"9310",
		"ERROR"
	],
	[
		"WTUR SLC MF torque protection",
		"9311",
		"ERROR"
	],
	[
		"WTUR SLC MF max tower oscillation analog",
		"9312",
		"ERROR"
	],
	[
		"WTUR SLC error",
		"9313",
		"ERROR"
	],
	[
		"WTUR SLC warning",
		"9314",
		"WARNING"
	],
	[
		"WTUR SLC MF blade regulation control",
		"9315",
		"ERROR"
	],
	[
		"WTUR SLC MF safe operation speed limit",
		"9316",
		"ERROR"
	],
	[
		"WTUR SLC implaus speed",
		"9317",
		"ERROR"
	],
	[
		"WTUR SLC interface error",
		"9318",
		"ERROR"
	],
	[
		"WTUR SLC run time limit active",
		"9319",
		"INFO"
	],
	[
		"WTUR P output externally reduced",
		"9900",
		"INFO"
	],
	[
		"WTUR P limit extern IEC",
		"9901",
		"INFO"
	],
	[
		"WTUR dU limit extern IEC",
		"9902",
		"INFO"
	],
	[
		"WTUR Stop ext prot dev",
		"9903",
		"INFO"
	],
	[
		"WTUR Fallback P limit failure IEC",
		"9904",
		"INFO"
	],
	[
		"WTUR IEC failure stop",
		"9905",
		"ERROR"
	],
	[
		"WTUR Fallback dU limit failure IEC",
		"9906",
		"INFO"
	],
	[
		"WTUR Externally stopped",
		"9907",
		"INFO"
	],
	[
		"WTUR External stop IEC",
		"9908",
		"INFO"
	],
	[
		"WTUR Park master stop",
		"9930",
		"INFO"
	],
	[
		"WTUR Slave tripping",
		"9931",
		"INFO"
	],
	[
		"WTUR Emer power op active",
		"9932",
		"INFO"
	],
	[
		"WTUR Comm failure FDM all clients",
		"9933",
		"WARNING"
	],
	[
		"WTUR Parkmaster operation failed",
		"9934",
		"INFO"
	],
	[
		"WTUR PMU snapshot",
		"9935",
		"INFO"
	],
	[
		"WTUR Icing farm ",
		"9936",
		"INFO"
	],
	[
		"WTUR Comm failure FPM",
		"9937",
		"WARNING"
	],
	[
		"WTUR Comm failure FPM stop",
		"9938",
		"ERROR"
	],
	[
		"WTUR No assignment to a PMU",
		"9939",
		"WARNING"
	],
	[
		"WTUR Fallback setpoints active",
		"9940",
		"INFO"
	],
	[
		"WTUR IP duplicate in WF network",
		"9941",
		"WARNING"
	],
	[
		"WTUR BCP master with same seg no",
		"9942",
		"WARNING"
	],
	[
		"WTUR Targ pitch angle implaus",
		"9960",
		"ERROR"
	],
	[
		"WTUR Indiv setp pitch ang offset incorr",
		"9961",
		"ERROR"
	],
	[
		"WTUR Client failure",
		"9970",
		"WARNING"
	],
	[
		"WTUR PMU active power semi aut op",
		"9980",
		"INFO"
	],
	[
		"WTUR PMU react power semi aut op",
		"9981",
		"INFO"
	],
	[
		"WTUR UPS warning",
		"9990",
		"WARNING"
	],
	[
		"WTUR UPS fault",
		"9991",
		"ERROR"
	],
	[
		"WTUR UPS buffer time too short",
		"9992",
		"ERROR"
	],
	[
		"WTUR UPS error",
		"9993",
		"WARNING"
	],
	[
		"WTUR UPS air conditioning faulty",
		"9994",
		"WARNING"
	]
]