# Senvion WTT PLC programming guidelines

## Average values 
Average values of 500ms and less have to be calculated manually in the PLC program by using the MovAvCalc.st function block only if they are used further in the program (except for logging or visu purposes). All other Average Values will be calculated by WTT_IO (configuration of the variable in the excel sheet). 

## Analog inputs
Analog inputs will be read by WTT_IO. Scaling of the input words has to be done with the function blocks Cur2Re.st (for 4 - 20mA signals) and P100Conv2Tmp.st (for PT100 signals). 
The scaled signals have to be written back to WTT_IO.